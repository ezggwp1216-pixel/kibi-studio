# Kibi Studio workspace

Read README.md, docs/development-contract.md and docs/progress.md. This is a real personal local development foundation, not the historical static concept. Do not choose a predetermined application for the user.

Use the user's ChatGPT-managed account through local Codex app-server. Never request an API fallback, read/copy auth.json, alter global Codex configuration or expose arbitrary app-server RPC to browsers. Local Studio history differs from ChatGPT Project history. This does not authorize a public hosted commercial auth service.

Public source: projects/kibi-base/firmware. app_view.h is design; app_core.h portable state/input/codec/tick; app_feature.h application hooks. Feature.h/project.ino and stock drivers are protected adapters. Use exact Kibi DS-02 profile/SDK/SourceSans3; preview and firmware share code.

Private settings/history/personalized binaries: .studio, never model context, public exports, distribution or Git. Do not read .studio/private or build BIN contents. Use flags and test configuration. Wi-Fi/API are optional and only required by chosen service modules. Configured compiler diagnostics never go to the model/public API.

User explicitly starts build and USB connect/prepare/write. No automatic USB actions. Production VPS/sldvkibi.ru is outside this local scope. Preserve working flasher checks and calibration/NVS/power drivers.

Start npm start. Diagnose npm run doctor. Tests npm test; KIBI_NATIVE_INTEGRATION=1 npm test adds actual host sandbox checks. Native/localhost tests in a restricted harness may need authorized host execution. Package npm run package after evidence/docs finalized; never rerun legacy setup/seed scripts to overwrite the generic project.
