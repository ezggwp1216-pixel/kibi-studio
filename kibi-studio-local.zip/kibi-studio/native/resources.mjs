import {readFile,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {sha256} from './support.mjs';
const SDK='2a984679ae86d0353c9526dbc1e6a9aafcd485bb655757dc666f74d2a2a3aa50';
const LIBRARIES='68fb2fe03744b4deef01d56efd09dd2ecba6dd7b17152a483430ad495cb931be';
export async function verifyPublicResources(root){
  const sdk=JSON.parse(await readFile(join(root,'resources/native-sdk-inventory.json'))),libraries=JSON.parse(await readFile(join(root,'resources/library-inventory.json')));
  if(sha256(sdk.files.map(f=>f.path+'\0'+f.sha256+'\0').join(''))!==SDK)throw new Error('Native SDK inventory integrity mismatch');
  if(sha256(libraries.flatMap(l=>l.files.map(f=>l.name+'/'+f.path+'\0'+f.sha256+'\0')).join(''))!==LIBRARIES)throw new Error('Stock library inventory integrity mismatch');
  const all=[...sdk.files.map(f=>({...f,path:join('native-sdk',f.path)})),...libraries.flatMap(l=>l.files.map(f=>({...f,path:join('libraries',l.name,f.path)})))];
  for(const f of all){
    if(f.path.split('/').some(p=>p==='..'||p===''||p==='.git'))throw new Error('Invalid public resource inventory path');
    const path=join(root,'resources',f.path),stat=await lstat(path);
    if(!stat.isFile()||stat.isSymbolicLink()||stat.size!==f.size||sha256(await readFile(path))!==f.sha256)throw new Error('Public resource hash mismatch: '+f.path);
  }
  return true;
}
