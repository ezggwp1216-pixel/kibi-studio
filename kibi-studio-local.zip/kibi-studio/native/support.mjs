import {constants} from 'node:fs';
import {open,readdir,lstat,realpath,mkdir,chmod,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,relative,join,sep} from 'node:path';
export const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
export async function privateDirectory(path){await mkdir(path,{recursive:true,mode:0o700});const stat=await lstat(path);if(stat.isSymbolicLink()||!stat.isDirectory())throw new Error('Private directory must not be symbolic');await chmod(path,0o700);return path;}
export async function privateFile(path,bytes){const handle=await open(path,constants.O_WRONLY|constants.O_CREAT|constants.O_TRUNC|constants.O_NOFOLLOW,0o600);try{await handle.writeFile(bytes);await handle.chmod(0o600);}finally{await handle.close();}}
export async function readSource({root,sourceDir}){
  const requestedRoot=resolve(root),requestedRelative=relative(requestedRoot,resolve(sourceDir));
  root=await realpath(root);sourceDir=resolve(root,requestedRelative);
  const rel=relative(join(root,'projects'),sourceDir);
  if(!/^[A-Za-z0-9_-]+\/firmware$/.test(rel.split(sep).join('/')))throw new Error('Source must be a public project firmware directory');
  if(await realpath(sourceDir)!==sourceDir)throw new Error('Symbolic source directories are forbidden');
  const files=[];let total=0;
  async function walk(directory,prefix=''){
    for(const name of (await readdir(directory)).sort()){
      if(!/^[A-Za-z0-9_][A-Za-z0-9_.-]{0,99}$/.test(name))throw new Error('Unsupported source path');
      const path=join(directory,name),pathRel=prefix+name,stat=await lstat(path);
      if(stat.isSymbolicLink())throw new Error('Symbolic source links are forbidden');
      if(pathRel.split('/').length>4)throw new Error('Source nesting limit');
      if(stat.isDirectory()){await walk(path,pathRel+'/');continue;}
      if(!stat.isFile())throw new Error('Unsupported source file');
      if(/^(build_opt\.h|sdkconfig\.h|platform\.local\.txt|boards\.local\.txt|partitions\.csv|kibi_project_config\.h)$/i.test(name))throw new Error('Build configuration overrides are forbidden');
      if(!/\.(ino|h|hpp|c|cpp|s)$/i.test(name)&&name!=='README.md'&&name!=='kibi-dependencies.json')throw new Error('Unsupported source file');
      if(stat.size>2*1024*1024)throw new Error('Source file exceeds limit');
      const handle=await open(path,constants.O_RDONLY|constants.O_NOFOLLOW);let bytes;
      try{bytes=await handle.readFile();}finally{await handle.close();}
      total+=bytes.length;files.push({path:pathRel,bytes});
      if(files.length>63||total>4*1024*1024)throw new Error('Public source exceeds 63-file / 4MiB limit');
    }
  }
  await walk(sourceDir);files.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
  if(!files.some(f=>f.path==='project.ino'))throw new Error('Missing project.ino');
  const hash=createHash('sha256');for(const f of files)hash.update(f.path).update('\0').update(f.bytes).update('\0');
  return {files,sourceHash:hash.digest('hex'),total};
}
export async function hashSource(sourceDir,root){return (await readSource({sourceDir,root})).sourceHash;}
export async function stageSource(snapshot,directory,{build=false}={}){
  await privateDirectory(directory);
  for(const file of snapshot.files){
    // Dependency metadata stays in the public snapshot hash, outside Arduino's source input.
    if(build&&file.path==='kibi-dependencies.json')continue;
    const path=join(directory,file.path);await privateDirectory(resolve(path,'..'));await privateFile(path,file.bytes);
  }
}
