// Explicit local acceptance command: generic offline base, empty private config, no USB.
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {lstat} from 'node:fs/promises';
import {createBuildService} from '../src/build-service.mjs';
import {hashSource} from './support.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),sourceDir=join(root,'projects/kibi-base/firmware');
const service=createBuildService({root});
console.log(JSON.stringify(await service.environment()));
const sourceHash=await hashSource(sourceDir,root);
const job=await service.start({projectId:'kibi-base',sourceDir,sourceRevision:1,sourceHash,configuration:{wifi_ssid:'',wifi_password:''},onProgress:({id,status})=>console.log(JSON.stringify({id,status}))});
const {id,status,createdAt,finishedAt,sourceRevision,artifacts}=job;
const sourceUnmodified=await hashSource(sourceDir,root)===sourceHash;
const jobDirectoryPrivate=((await lstat(join(root,'.studio/jobs',id))).mode&0o777)===0o700;
const artifactModes=await Promise.all(artifacts.map(async file=>((await lstat(file.path)).mode&0o777)===0o600));
const programBytes=Number(job.log.match(/Sketch uses (\d+) bytes/)?.[1])||undefined;
const staticRamBytes=Number(job.log.match(/Global variables use (\d+) bytes/)?.[1])||undefined;
console.log(JSON.stringify({id,status,createdAt,finishedAt,sourceRevision,sourceHash,sourceUnmodified,jobDirectoryPrivate,artifactsPrivate:artifactModes.every(Boolean),programBytes,staticRamBytes,artifacts:artifacts.map(({name,size,sha256,offset})=>({name,size,sha256,offset}))},null,2));
if(job.status!=='succeeded'||!sourceUnmodified||!jobDirectoryPrivate||!artifactModes.every(Boolean)){console.error('Generic offline acceptance verification failed. Inspect the private job log locally.');process.exitCode=1;}
