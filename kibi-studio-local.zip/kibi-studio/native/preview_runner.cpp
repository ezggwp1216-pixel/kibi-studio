#include "app_view.h"
#include "app_feature.h"
#include "display_touch.h"
#include <ArduinoJson.h>
#include <cassert>
#include <iostream>
#include <string>
#include <vector>
#include <sys/resource.h>
using namespace KibiApp;

static void check(){
 static_assert(kScreenCount>=1&&kScreenCount<=16,"Declare between 1 and 16 application screens");
 const auto codec=[](const Model& model){
  JsonDocument encoded;encodeState(model,encoded.to<JsonObject>());assert(measureJson(encoded)<=32768);
  Model decoded;View::Context context;KibiApp::Feature::begin(decoded,context);assert(decodeState(decoded,encoded.as<JsonObjectConst>()));normalize(decoded);
  JsonDocument repeated;encodeState(decoded,repeated.to<JsonObject>());std::string before,after;serializeJson(encoded,before);serializeJson(repeated,after);assert(before==after);
 };
 const Input probes[]={Input{InputKind::Plus},Input{InputKind::Minus},Input{InputKind::Tap,-1,-1},Input{InputKind::Tap,120,148},Input{InputKind::Tap,24,132,1,0,1201},Input{InputKind::Swipe,-1,-1,-60,0,200},Input{InputKind::Swipe,-1,-1,60,0,200},Input{InputKind::Swipe,-1,-1,-27,70,200},Input{InputKind::Swipe,-1,-1,-60,0,1201}};
 constexpr size_t n=240*296,g=32;std::vector<uint16_t> pixels(n+g*2,0x1234);
 for(unsigned screen=0;screen<kScreenCount;++screen){
  Model base;View::Context initial;KibiApp::Feature::begin(base,initial);base.screenIndex=uint8_t(screen);normalize(base);assert(base.screenIndex<kScreenCount);codec(base);
  for(const auto& input:probes){Model changed=base;const Action action=reduceInput(changed,input);KibiApp::Feature::input(changed,input,action);KibiApp::tick(changed,100);KibiApp::Feature::tick(changed,initial,100);normalize(changed);assert(changed.screenIndex<kScreenCount);codec(changed);
   const char* name=actionName(action);assert(name&&name[0]>='a'&&name[0]<='z');size_t length=0;for(;name[length]&&length<64;++length)assert((name[length]>='a'&&name[length]<='z')||(name[length]>='A'&&name[length]<='Z')||(name[length]>='0'&&name[length]<='9'));assert(length<64);
  }
  for(int scenario=0;scenario<4;++scenario){auto model=base;View::Context context;context.nowMs=100;context.loading=scenario==1;context.online=scenario!=2;context.stale=scenario==3;
   KibiApp::tick(model,context.nowMs);KibiApp::Feature::tick(model,context,context.nowMs);normalize(model);std::fill(pixels.begin(),pixels.end(),0x1234);View::render(pixels.data()+g,n,model,context);
   for(size_t i=0;i<g;++i)assert(pixels[i]==0x1234&&pixels[g+n+i]==0x1234);Tamagotchi::DisplayTouchDetail::maskRoundedCorners(pixels.data()+g);assert(pixels[g]==0&&pixels[g+239]==0&&pixels[g+n-1]==0);
  }
 }
 std::cout<<"native_same_source_render_guard PASS\nnative_public_state_codec_roundtrip PASS\nshared_input_and_tick_contract_robustness PASS\ndeclared_screen_and_scenario_render_guards PASS\nstock_rounded_corner_mask PASS\n";
}

int main(int argc,char**argv){
 rlimit cpu{10,10};setrlimit(RLIMIT_CPU,&cpu);rlimit file{1048576,1048576};setrlimit(RLIMIT_FSIZE,&file);rlimit files{32,32};setrlimit(RLIMIT_NOFILE,&files);
 if(argc==2&&std::string(argv[1])=="--check"){check();return 0;}if(argc!=1)return 64;
 std::string input;char ch;while(std::cin.get(ch)){if(input.size()>=65536)return 65;input+=ch;}
 JsonDocument document;if(deserializeJson(document,input)||!document.is<JsonObject>())return 65;
 const std::string scenario=document["scenario"]|"ready";
 Model model;View::Context context;
 if(document["nowMs"].is<uint32_t>())context.nowMs=document["nowMs"].as<uint32_t>();
 if(scenario=="loading")context.loading=true;else if(scenario=="offline")context.online=false;else if(scenario=="stale")context.stale=true;else if(scenario!="ready")return 65;
 // Hooks see the same current clock/scenario as the following input and tick.
 KibiApp::Feature::begin(model,context);bool stateReset=false;
 if(document["state"].is<JsonObject>()&&!decodeState(model,document["state"].as<JsonObjectConst>())){
  // A changed module codec may reject an older schema after partially decoding.
  // Discard it completely, retain the current context, and report the reset.
  model=Model{};KibiApp::Feature::begin(model,context);stateReset=true;
 }
 Action action=Action::None;
 if(document["input"].is<JsonObject>()){
  const std::string type=document["input"]["type"]|"";
  Input event;if(type=="plus")event.kind=InputKind::Plus;else if(type=="minus")event.kind=InputKind::Minus;else if(type=="tap")event.kind=InputKind::Tap;else if(type=="swipe")event.kind=InputKind::Swipe;else return 65;
  event.x=document["input"]["x"]|-1;event.y=document["input"]["y"]|-1;event.dx=document["input"]["dx"]|0;event.dy=document["input"]["dy"]|0;event.durationMs=document["input"]["durationMs"]|200;
  action=reduceInput(model,event);KibiApp::Feature::input(model,event,action);
 }
 KibiApp::tick(model,context.nowMs);KibiApp::Feature::tick(model,context,context.nowMs);normalize(model);
 constexpr size_t n=240*296,g=32;std::vector<uint16_t> pixels(n+g*2,0x1234);View::render(pixels.data()+g,n,model,context);
 for(size_t i=0;i<g;++i)if(pixels[i]!=0x1234||pixels[n+g+i]!=0x1234)return 66;
 Tamagotchi::DisplayTouchDetail::maskRoundedCorners(pixels.data()+g);
 std::vector<char> rgb;rgb.reserve(n*3);for(size_t i=g;i<n+g;++i){const auto p=pixels[i];rgb.push_back(char(((p>>11)&31)*255/31));rgb.push_back(char(((p>>5)&63)*255/63));rgb.push_back(char((p&31)*255/31));}
 std::cout.write(rgb.data(),rgb.size());
 JsonDocument result;result["action"]=actionName(action);encodeState(model,result["state"].to<JsonObject>());if(stateReset)result["stateReset"]=true;
 if(measureJson(result["state"])>32768)return 67;serializeJson(result,std::cerr);return 0;
}
