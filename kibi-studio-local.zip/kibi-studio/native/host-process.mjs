import {spawn,execFile} from 'node:child_process';
import {realpath} from 'node:fs/promises';
// Private user trees and mutable temporary trees are unreadable except for the
// explicit public snapshot/library roots and this subprocess's output directory.
// macOS needs its platform's ordinary loader/system reads; writes are denied globally.
export function sandboxProfile({read=[],write=[],executable}={}){
  const quote=p=>JSON.stringify(p);
  const privateRoots=['/Users','/home','/root','/Volumes','/private/tmp','/tmp','/private/var/folders','/private/var/root','/private/var/tmp','/opt','/Library/Keychains','/Library/Application Support'];
  return `(version 1) (allow default) (deny network*)
    (deny file-read-data ${privateRoots.map(p=>`(subpath ${quote(p)})`).join(' ')})
    (deny file-write*) (allow file-write* (literal "/dev/null"))
    ${[...read,...write].map(p=>`(allow file-read-data (subpath ${quote(p)}))`).join('\n')}
    ${write.map(p=>`(allow file-write* (subpath ${quote(p)}))`).join('\n')}
    ${executable?`(deny process-fork) (deny process-exec) (allow process-exec ${(Array.isArray(executable)?executable:[executable]).map(p=>`(literal ${quote(p)})`).join(' ')}) (deny signal) (deny mach-lookup) (deny appleevent-send)`:''}`;
}
export async function runBounded(command,args,{cwd,read=[],write=[],timeout=30000,maxOutput=1024*1024,input,env={},onOutput,restrictExecution=false,executionAllowlist=[],maxRssBytes}={}){
  if(process.platform!=='darwin')throw new Error('Native sandbox requires macOS sandbox-exec; refusing unsandboxed execution');
  read=await Promise.all(read.map(p=>realpath(p)));write=await Promise.all(write.map(p=>realpath(p)));
  const executable=restrictExecution?await Promise.all([command,...executionAllowlist].map(p=>realpath(p))):undefined;
  return new Promise((resolve,reject)=>{
    const child=spawn('/usr/bin/sandbox-exec',['-p',sandboxProfile({read,write,executable}),command,...args],{
      cwd,detached:true,stdio:['pipe','pipe','pipe'],env:{PATH:'/Library/Developer/CommandLineTools/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin',LANG:'en_US.UTF-8',LC_ALL:'en_US.UTF-8',...env}
    });
    const out=[],err=[];let total=0,reason;
    const kill=()=>{try{process.kill(-child.pid,'SIGKILL');}catch{child.kill('SIGKILL');}};
    const timer=setTimeout(()=>{reason='Native subprocess exceeded time limit';kill();},timeout);
    let sampling=false;
    const memoryTimer=maxRssBytes?setInterval(()=>{
      if(sampling||!child.pid)return;sampling=true;
      execFile('/bin/ps',['-o','rss=','-p',String(child.pid)],{timeout:1000,maxBuffer:1024},(error,stdout)=>{
        sampling=false;if(!error&&Number(stdout.trim())*1024>maxRssBytes){reason='Native subprocess exceeded resident-memory budget';kill();}
      });
    },250):undefined;
    for(const[stream,chunks]of[[child.stdout,out],[child.stderr,err]])stream.on('data',chunk=>{
      total+=chunk.length;if(total>maxOutput){reason='Native subprocess exceeded output limit';kill();return;}
      chunks.push(chunk);onOutput?.(chunk.toString('utf8'));
    });
    child.on('error',error=>{clearTimeout(timer);clearInterval(memoryTimer);reject(error);});
    child.on('close',(code,signal)=>{clearTimeout(timer);clearInterval(memoryTimer);const stdout=Buffer.concat(out),stderr=Buffer.concat(err).toString('utf8');
      if(reason||code!==0){const error=new Error(reason||stderr.trim()||`Native subprocess failed (${signal||code}); sandbox required`);error.stdout=stdout;error.stderr=stderr;error.code=code;reject(error);}
      else resolve({stdout,stderr});
    });
    child.stdin.on('error',()=>{});child.stdin.end(input);
  });
}
