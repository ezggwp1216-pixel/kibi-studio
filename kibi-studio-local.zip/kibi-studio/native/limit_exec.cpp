// Trusted bootstrap: establish limits BEFORE loading project-controlled code.
#include <sys/resource.h>
#include <unistd.h>
#include <cstring>
#include <cstdio>
int main(int argc,char**argv){
  if(argc<3||std::strcmp(argv[1],"--render"))return 64;
  rlimit cpu{8,8},file{1048576,1048576},files{32,32};
  if(setrlimit(RLIMIT_CPU,&cpu)){std::perror("native CPU limit");return 70;}
  if(setrlimit(RLIMIT_FSIZE,&file)){std::perror("native file limit");return 70;}
  if(setrlimit(RLIMIT_NOFILE,&files)){std::perror("native descriptor limit");return 70;}
  // Darwin rejects finite RLIMIT_AS/RLIMIT_DATA on this host. The parent also
  // monitors resident bytes and kills the isolated process when over budget.
  execv(argv[2],argv+2);return 71;
}
