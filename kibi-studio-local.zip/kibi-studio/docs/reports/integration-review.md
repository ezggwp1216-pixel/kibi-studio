# Independent integration review — 2026-11-05

Scope: `src/project-store.mjs`, `src/server.mjs`, `src/codex-bridge.mjs`, `src/native-preview.mjs`, `src/build-service.mjs`, and `native/host-process.mjs`, against `docs/integration-spec.md`. Supporting source, test fixtures, browser revision gates, and the existing native/chat evidence reports were read where necessary. This reviewed the new implementation directly; there was no applicable commit diff.

No real settings/auth files or firmware binaries were read. No model inference, USB/serial operation, SSH, production change, or full test suite was run. Reproductions used disposable directories and dummy values only. Root owns the final combined tests and real chat/browser acceptance evidence.

Follow-up source review: all five historical findings below are corrected in the current generic Kibi Base implementation. The controller canonicalizes roots, withholds configured compiler diagnostics, revokes stale artifacts, repairs interrupted work and validates public metadata. Root reports focused store/server/package tests passing; this reviewer read the implementations and regression fixtures without repeating the suites. A second independent read reviewed the generic requirements tool, private configuration scope, package allowlist and launcher.

## Historical findings — corrected

### P1 — Configured compiler diagnostics can encode credentials past exact-string redaction

Relevant paths: `src/build-service.mjs:23`, `src/build-service.mjs:71`, `src/build-service.mjs:81`, and the original `publicJob`/`getAgentContext` publication paths in `src/project-store.mjs` and `build.progress` path in `src/server.mjs`.

An allowed application source sees `KIBI_WIFI_PASSWORD` during the configured build. GCC can print the evaluated values of its characters in a normal diagnostic, so replacing the full credential and its escaped forms does not prevent disclosure. A tiny syntax-only invocation of the installed ESP32-S3 compiler with the dummy password `DUMMY-PASS` and an incomplete template produced:

```text
error: aggregate 'Encoded<68, 85, 77, 77, 89> probe' has incomplete type
```

The actual `redactLog()` left these decimal values intact. The original controller published that text in state/SSE and automatically included it in the next model's context. This crosses the explicit private-configuration boundary without reading the private header through a model tool.

Recommended correction: keep arbitrary diagnostic text from configured firmware builds private. Publish fixed success/failure summaries, and expose only job identity/revisions to the model. Native preview/check diagnostics can remain useful because their sandbox never contains the injected configuration. Exact-string redaction may remain defense in depth, but cannot establish this boundary.

Follow-up status: corrected in the public job, SSE progress, and agent-context publication paths. Regression fixtures assert encoded text is absent and model context excludes artifact measurements. Root reports focused tests passing.

### P1 — Private settings writes follow a symlink into public web assets

Relevant paths: `src/project-store.mjs:59`–`60`, `src/project-store.mjs:19`–`22`, and `privateWrite()`/`saveSettings()`; static publication is in `src/server.mjs:166`–`170`.

The store uses recursive `mkdir` and `chmod` for `.studio/private` without rejecting symlinks or checking canonical ancestors. Its atomic writer then creates its temporary file through that directory. In a disposable fixture, linking `.studio/private` to `web/` was accepted, and `saveSettings()` wrote the dummy Wi-Fi password to `web/bitcoin-monitor.json`. That extension is explicitly served by the static route. The later Codex checks validate `.studio` and `.studio/codex`, but do not reject this private-subdirectory link.

Recommended correction: validate the canonical Studio root and each private-directory ancestor before loading or writing runtime state/settings; reject directory symlinks and unsafe existing file links, and revalidate at private writes. Reuse the strict private-directory boundary rather than the permissive recursive path setup. Include a regression fixture that links private storage into `web/` and verifies refusal before any settings are copied.

Follow-up status: corrected by `privateBoundary()` before initial reads and private writes. Root reports the link-refusal regression passing.

### P2 — A crashed build leaves the UI permanently in its building state after restart

Relevant paths: persisted state loading in `src/project-store.mjs:65`, the fresh `building=false` initialization in `src/server.mjs:27`, and `web/app.js:101`–`102`.

Build progress is persisted as `queued`/`building`, but startup does not reconcile such jobs with the absence of an active build task. Reopening a disposable store containing a dummy `building` job returned that same status. The browser treats it as an active build and disables the build button indefinitely. This affects a crash/forced termination during a normal, potentially long compile; an ordinary restart does not recover the workflow.

Recommended correction: on startup mark persisted nonterminal jobs interrupted/failed, expose a safe recovery message, and permit a new explicit build. Do not infer successful artifacts merely from leftover files. A small restart fixture is sufficient coverage.

Follow-up status: corrected during store startup; unfinished builds become failed and streaming messages become interrupted. A restart fixture covers both transitions.

### P2 — Stale source/configuration does not revoke backend artifact routes

Relevant paths: `src/server.mjs:91`–`96` and the manifest route at `src/server.mjs:159`–`162`.

Artifact and manifest responses check the stored job's `succeeded` status, but never compare its source hash/revision and configuration revision with current project state. Consequently an old artifact URL and its flash manifest remain valid after a source edit or Wi-Fi replacement/removal. The current browser's `FlashApprovalGate` does compare these identities, which protects its normal write flow, but the backend still presents stale artifacts as usable. This is contrary to the specified source/configuration invalidation boundary and retains a download path for an old configured binary.

Recommended correction: require a current job identity at all personalized artifact/manifest endpoints and return a conflict for stale jobs. Retain private historical metadata if useful, but do not make it an active configurator result. Cover both source and settings changes with a dummy artifact fixture.

Follow-up status: corrected by `requireCurrentJob()` on manifest and artifact routes; downloads additionally verify the bytes against recorded size/SHA. The reviewed regression changes configuration and asserts refusal. The helper itself also compares source revision/hash.

### P1 — Public project metadata links still copy private settings into exports

Current path: `src/project-store.mjs:153`–`155`; related metadata loading is at `src/project-store.mjs:73`–`75`.

The strict private-directory correction does not validate public metadata reads. `exportFiles()` uses `readFile()` on fixed metadata names and follows symlinks. A fresh fixture saved dummy settings normally, linked `projects/bitcoin-monitor/AGENTS.md` to `.studio/private/bitcoin-monitor.json`, and exported the project. The returned `AGENTS.md` contained the full dummy Wi-Fi password. This is a direct private-to-export disclosure with the current fixes present. A project-level `AGENTS.md` may also be read by Codex's own instruction discovery; that secondary path was not exercised and is not needed to establish this finding.

Recommended correction: validate canonical, nonsymlink public project/source directories and the fixed metadata files before reading them; reject a metadata link instead of exporting its target. Apply the same public boundary before starting/resuming model work so instruction discovery cannot follow an unchecked project metadata link. Preserve missing optional metadata behavior, but distinguish a missing file from an unsafe one. Regression coverage should link each exported metadata name to a dummy private file and verify refusal without copying its contents.

Follow-up status: corrected by `publicBoundary()` / `publicFile()` before public source/context/export reads. Canonical project ancestors and fixed metadata links are rejected. The current regression links public metadata to a dummy private file and expects refusal for both export and agent context.

## Additional controller note

The first queued job ID and the build service's eventual job ID differ. The current explicit-map alias handling in `findJob()` correctly distinguishes an alias hit from a mismatched fallback. Root reports the queued-ID regression passing. The fast-completed-turn response now also uses authoritative bridge busy state.

## Boundaries observed

The bridge checks ChatGPT account type before turns, selects the advertised default OpenAI model without an API fallback, and normalizes protocol events. Its dynamic-tool names are controller-checked; the new requirements tool must also be present in the bridge allowlist (see follow-up notes). Source writes enforce an allowlist and expected SHA; native execution uses separate public snapshots without private settings. The browser checks source/configuration/job identities before user-approved flashing. These positive observations are source-review results, not a substitute for the outstanding real model turn and browser/device acceptance evidence.


## Generic foundation follow-up — 2026-11-05

Reviewed read-only: current generic `src/project-store.mjs`, `src/server.mjs`, new `kibi_set_requirements` tool/schema, `scripts/package.mjs`, `scripts/start.mjs`, the `.command` launcher and focused regression fixtures. No actual credential files, inference, compilation or device operations were used.

- **Required correction, then fixed by root:** `getBuildConfiguration()` initially returned all saved Wi-Fi/API values even when both generic project requirement flags were false. This unnecessarily placed unused private values within offline application compilation. Root changed injection to the explicitly required services only and reports a dummy-settings regression passing: offline builds receive empty Wi-Fi/no API values; explicit flags enable the corresponding fields.
- **Bridge integration correction:** the server gained six dynamic tools including `kibi_set_requirements` while the bridge still capped its original allowlist/count at five. The bridge owner confirmed this; the current source now includes the sixth name in its bounded allowlist. Its focused regression and restart are tracked by the bridge/root integration evidence. Before the update, real generic chat turns failed validation before inference. This is a concrete integration issue, not an authentication failure.
- The requirements tool accepts exactly boolean Wi-Fi/API flags and returns public project metadata only. It changes the configuration revision, so existing prepared binaries/plans become stale. Source write gates remain `app_view.h` during design and approved `app_core.h`/`app_feature.h` afterward; the hardware adapter and entry point remain protected.
- The package now selects only generic `projects/kibi-base` plus explicit public roots/files, includes the native renderer/runtime and verified SDK/libraries/licenses, excludes runtime state/credentials/build artifacts and strips dev/install hooks from the distributed package.json. Eligible symlinks/special files are refused; SDK/archive exceptions are inventory-verified. Root `.gitignore` is explicitly retained.
- The launcher changes to its own directory, invokes the bundled start script with Node and binds only loopback. The runtime uses no package installation step; Node and the documented macOS toolchain remain prerequisites. No new concrete packaging/launcher privacy defect was found in this read.

The generic native state/gesture work and expanded browser preview are validated separately. This source review does not claim a new physical board test or substitute for root's final full suite.
