# Generic Kibi Base: exact-board local build

Current scope: a universal offline-first Kibi development base. No application-specific market feed, Wi-Fi requirement, model inference or device flash belongs to this build step.

## Verified build service

`src/build-service.mjs` compiles a private snapshot of the current public project with the installed Arduino CLI 1.5.1, ESP32 core 3.3.12 and reviewed native IDF 5.5.5 SDK. The fixed board recipe is ESP32-S3 chip ID 9, 16MiB flash, DIO40, OPI80, native PM/tickless/IRAM-safe I2S/full TLS bundle, and two 2MiB application partitions. SDK/library integrity, source paths, symlinks, forbidden build overrides and source size limits are checked before compilation. No dependency installations, arbitrary build flags or project hooks are accepted.

The distributable SDK contains 1,853 files / 38,844,028 bytes. Its inventory digest is `2a984679ae86d0353c9526dbc1e6a9aafcd485bb655757dc666f74d2a2a3aa50`. Stock AnimatedGIF 2.2.0 and ArduinoJson 7.4.3 retain 524 files / 27,746,991 bytes and digest `68fb2fe03744b4deef01d56efd09dd2ecba6dd7b17152a483430ad495cb931be`. Their original licenses and 25 upstream ESP-IDF/Arduino-core LICENSE/NOTICE/COPYING files are included under `resources/`.

Distribution sanitation removed only nonruntime repository and automation metadata under `include/heap/tlsf/`: `.git` (30 recorded entries / 47,758 bytes) and `.github` (3 recorded entries / 1,995 bytes), totaling 33 files / 49,753 bytes. Both directories were preserved intact by directory rename under `design-archive/public-sdk-metadata/`, outside the distributable; none of their contents were read for this operation. All surviving SDK headers, libraries, public bootloader ELF and original `kibi-sdk-provenance.json` bytes remain unchanged. `resources/native-sdk-inventory.json` records the sanitation and original/current inventory identities. A complete metadata-name audit against the package exclusion policy found no additional SDK or library exclusions. The library inventory needed no sanitation. The package collector continues to exclude repository/automation metadata rather than granting an exception for it.

The offline base accepts empty Wi-Fi fields. Optional settings are limited to `wifi_ssid`, `wifi_password`, `api_key` and `api_base_url`. Wi-Fi credentials are validated when supplied; API keys are limited to 4,096 UTF-8 bytes without controls; API base URLs to 2,048 UTF-8 bytes, HTTPS, no embedded credentials, whitespace or controls. Private staging generates only these macros, with empty defaults:

```
KIBI_WIFI_SSID
KIBI_WIFI_PASSWORD
KIBI_SERVICE_API_KEY
KIBI_SERVICE_API_BASE_URL
```

Every configured value and generated header diagnostic is redacted from build logs. Source/public export is unchanged by a build. Jobs stay in `.studio/jobs/` with directories mode 0700 and files mode 0600; generated settings/header/compiler intermediates are removed after completion. macOS sandbox execution denies network and unrelated private data access. The build is bounded to 480 seconds, 4MiB process output and a 2MiB application image. A successful job returns four SHA256/size/offset records: bootloader at 0, partitions at 0x8000, boot_app0 at 0xe000 and application at 0x10000.

## Current verification

`node --test tests/build-service.test.mjs`: 7 passed, 0 failed. This covers source/symlink/override rejection, empty offline configuration, optional API bounds and URL safety, private macro escaping/redaction, fixed board arguments, stock-resource mutation rejection and concurrent-start exclusion.

The explicit acceptance command `node native/verify-build.mjs` succeeded for the frozen `projects/kibi-base/firmware` source. It read no saved settings, used empty Wi-Fi/API values, and emitted status plus public artifact metadata only.

- Job: `f493af12-a649-4bfd-af17-eef948ed4835`.
- Source SHA256: `1d5b4c7f9e1561a4556d67c123d5d6ae03c80609bfdc9a0fd07146827c26e62c` (63 public files).
- Start/end: `2026-11-05T12:02:56.490Z` → `2026-11-05T12:03:46.723Z` (~50 seconds).
- Arduino program bytes: 942,222 / 2,097,152. Static RAM: 31,480 / 327,680.
- Source remained unchanged. Job directory mode 0700 and every artifact mode 0600 were verified. Generated settings/header/intermediates were removed after the job.

| Artifact | Offset | Bytes | SHA256 |
|---|---:|---:|---|
| bootloader.bin | 0x0 | 18,720 | db22489ec2cc7e19fc46568a3f49332f7bf18ef75ff0b15e4858096fd4c4381e |
| partitions.bin | 0x8000 | 3,072 | 408987a1207e8335f3955e60d345ec7dbc521ed0989ed372311051340c6139d2 |
| boot_app0.bin | 0xe000 | 8,192 | f94c5d786a7a8fab06ac5d10e33bf37711a6697636dc037559ea19cc410a17f0 |
| app.bin | 0x10000 | 942,464 | 39933afcb3e614a38df15581bacfff3df430975a85186d6a1e834a1197b0dc2a |

The generated ESP32-S3 application passes the board chip-ID/image-size checks. This is actual native compiler evidence for the generic base, not physical hardware verification. No USB/serial device, flash, SSH, production service or model inference was accessed by this build. Optional real network/device tests require the user's own configuration and a separate explicit device action.
