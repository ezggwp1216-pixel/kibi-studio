# Chat bridge verification — 2026-11-05

Implemented `src/codex-bridge.mjs` using the installed Codex CLI 0.166.0-alpha.6 JSONL app-server protocol and the public schema generated in `/private/tmp/kibi-codex-protocol`. The bridge initializes the experimental dynamic-tool API, selects the advertised default model from the built-in OpenAI provider, checks `account/read` with `refreshToken:false` before every user turn, and refuses accounts other than `chatgpt`. It never reads auth files, credential values, or global configuration itself. No model API fallback is implemented.

Process overrides keep SQLite/log directories under private `.studio/codex/` directories (0700), replace inherited MCP/plugin/app configuration, disable shell execution, external apps/plugins, hooks, web search, multi-agent tools and memory, and retain interactive one-request approvals. All six accepted dynamic tools are controller-owned `kibi_*` functions; the bridge returns their bounded JSON as `inputText` on the original request ID. Only `kibi_preview` may supply the reserved `__kibiPreviewImage` field: a canonical `data:image/png;base64,` payload with PNG/IHDR signature, bounded to 512 KiB encoded, is stripped from JSON and appended as `inputImage`. Remote/file URLs, malformed or oversized PNG payloads, use by other tools, and oversized JSON reports return a safe failure without disclosing their content. Unknown requests and unsolicited permissions fail closed. Raw stderr, account identity, model protocol objects and callback exceptions never reach browser events.

`send` validates real project paths, binds thread/project associations, refreshes changed developer instructions through `thread/resume`, rejects simultaneous turns, streams normalized message/tool events, and supports interruption and explicit `accept`/`decline`/`cancel` decisions. The controller remains responsible for validating source writes, revisions and returned tool data.

## Evidence

- Test-first protocol tests were observed failing against an empty implementation, then passed against the bridge: `node --test tests/codex-bridge.test.mjs` — **14 passed, 0 failed**. Tests exercise actual child-process JSONL framing and lifecycle with a fixture executable, including fragmented events, exact tool reply IDs, auth/provider refusal, approval decisions, rejected permissions, invalid paths, exception sanitization, process death, protocol corruption, instruction refresh on resume, native-preview image delivery/refusal, the installed permission-profile migration, rejection of a mismatching effective profile, and the six-tool generic service-requirements contract.
- A real installed-CLI status-only check inside the managed execution sandbox could not initialize. Root repeated the same check with `require_escalated` outside that harness and verified **`{"available":true,"ready":true,"authenticated":true,"authMode":"chatgpt","planType":"prolite","busy":false}`** in approximately 0.5 seconds. This exposed only public account metadata and performed no inference.
- Reproducible status-only command, from the Studio directory:

```sh
node --input-type=module -e 'import {createCodexBridge} from "./src/codex-bridge.mjs"; const bridge=createCodexBridge({root:process.cwd()}); console.log(JSON.stringify(await bridge.start())); await bridge.close();'
```

## Remaining integration evidence

Root owns the combined test pass and the integrated generic application turn with a Kibi dynamic-tool call; neither is claimed by process fixture tests. The real minimal production-bridge turn recorded below verifies streaming only. Browser SSE, persistence and approval UI are also integrated separately.

Every thread and turn explicitly selects the process-local `kibi-studio-readonly` permission profile. Its filesystem rules permit reads for `:minimal` platform necessities and current `:workspace_roots` only; `network.enabled=false` grants no command networking and no filesystem writes are granted. The bridge refuses inference if `thread/start` or `thread/resume` reports a different effective profile. Shell, external apps/plugins, MCP, hooks and web search remain disabled.

The installed alpha rejected the former `readOnly.access` request with `-32600` and the structural cause “readOnly.access is no longer supported; use permissionProfile for restricted reads”. An isolated public protocol probe verified the new profile was selected (`activePermissionProfile.id=kibi-studio-readonly`, legacy sandbox metadata `readOnly`, networking false). The production bridge then performed one separately authorized real minimal turn on an isolated temporary public project: **completed**, text **“Kibi bridge ready.”**, **5 streamed deltas**. It used no dynamic tools, shell activation, source edits or credential reads. A regression fixture reproduces the old parser rejection and checks the migration rather than silently accepting an obsolete field. These checks verify accepted effective configuration and protocol behavior; OS-level deny/read probes remain a separate isolation test.

The generic controller tool set is `kibi_project_context`, `kibi_read_source`, `kibi_write_source`, `kibi_preview`, `kibi_check`, and `kibi_set_requirements`. The last tool handles only public Wi-Fi/API requirement flags; private values remain owned by Studio settings and compilation staging.

This is a personal local integration using Codex-managed ChatGPT authentication. Hosted or commercial distribution requires its own eligible Sign in with ChatGPT integration. App-server threads do not share the ChatGPT Project conversation or memory.

Official references: [app-server protocol](https://learn.chatgpt.com/docs/app-server), [process configuration](https://learn.chatgpt.com/docs/config-file/config-reference), [Sign in with ChatGPT token-sharing scope](https://developers.openai.com/siwc/token-sharing-open-source).
