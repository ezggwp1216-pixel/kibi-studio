# Clean Mac bootstrap — 2026-11-05

The new first stage uses macOS built-in shell/curl/tar/shasum. No Python, Node, npm, Homebrew, Arduino IDE, ESP32 compiler or Xcode installation is required beforehand. Node 24.22.2 and Codex CLI 0.166.0 are installed in a private user runtime directory. ChatGPT has a dedicated project profile; neither global Codex configuration nor auth.json is read/copied by Studio.

Verification completed on Apple Silicon macOS:

- Downloaded official Node arm64 tar.gz, checked pinned SHA-256 `aa9549349e47dffaa42dcf95d6e06ade8c4bdafc980979883b88767670df385a`, extracted and executed `v24.22.2` with `PATH=/usr/bin:/bin:/usr/sbin:/sbin`.
- Downloaded official npm Codex `0.166.0-darwin-arm64`, verified registry SHA-512 integrity from runtime-lock.json, extracted and executed `codex-cli 0.166.0`. The actual package uses `vendor/<target>/bin/codex`; this was checked against the downloaded archive.
- Ran the Node installer from the downloaded private Node with only macOS system tools on PATH. It fetched the commit-pinned public kit, checked archive/manifest/member hashes, installed 2524 files into a new isolated directory, created a private account directory, and reported `started:false` with `--install-only`. No login, chat, server, USB connection or firmware write occurred.
- New dependency-free ZIP verifier accepted the real public 2524-file kit. Tests reject corruption, symlink entries, traversal/private paths, case collisions on macOS and mismatched local ZIP filenames.
- Eight focused Node test cases pass, including existing Python downloader compatibility tests; shell syntax checks pass.

Limits of this evidence: this is a restricted PATH installation on an existing Mac, not a wiped Mac. The final published shell route needs a cold download against the new GitHub commit after publication. Intel metadata is pinned but Intel execution was not tested. Chrome was already installed here, so the private Chrome download/signature-verification branch was not executed; it verifies the app signature, Google TeamIdentifier EQHXZ8M8AV and Gatekeeper assessment before copying. A new user still completes the official browser sign-in personally. Remote renderer/build deployment and end-to-end checks are separate integration work.

Official metadata: https://nodejs.org/dist/v24.22.2/SHASUMS256.txt, https://registry.npmjs.org/@openai/codex/0.166.0-darwin-arm64, https://registry.npmjs.org/@openai/codex/0.166.0-darwin-x64. OpenAI install/auth guidance: https://learn.chatgpt.com/docs/codex/cli and https://learn.chatgpt.com/docs/auth?surface=cli.
