# Kibi Studio runtime UI

Current scope is the generic **Kibi Base** development foundation. The studio uses system typography and the approved dark, rounded, monochrome layout. Device pixels come exclusively from the shared native 240×296 RGB renderer.

## Implemented

- Real local HTTP/SSE state, persisted messages and streaming ChatGPT/Codex responses; honest authentication, busy, stop, approval and error states. No canned assistant replies or API-key fallback.
- Native frame/source revision and retained-frame compiler diagnostics. Source files use actual backend permissions and optimistic SHA writes. Conflicts preserve drafts; protected drivers are read-only.
- Generic screen/touch/module ideas fill the chat composer. Wi-Fi/API settings are optional private local data; flags only return to the browser. No saved values enter chat, browser storage or project export. Base builds do not require Wi-Fi.
- Design approval, explicit build/download and the original verified flasher workflow remain separated. Changes to source, settings, project, job or artifact invalidate prepared single-use installation approval.

## Expanded interactive preview

The expand control opens a focus dialog and moves the **same live preview pane/canvas** into it. It does not create another mockup or painter. The native framebuffer grows to fit the available area while preserving its aspect ratio and right-side hardware controls. Collapse/Escape restores the pane and its current state to the studio.

Mouse/touch pointer releases are converted to native coordinates. Taps include release coordinates, displacement and duration so the shared reducer can enforce the same target/distance/hold rules as the board. Motion over 10 native pixels is delivered as a swipe; shorter motion remains a tap. A swipe never also emits a tap. Horizontal swipe thresholds and actual page changes remain owned by firmware, not JavaScript.

The wheel/trackpad and left/right arrow keys send bounded horizontal swipe inputs for convenient desktop navigation. Input requests are queued; wheel bursts are throttled. Persistent feedback displays the backend's action, ignored gesture or error. The visible help describes actual app navigation. Power hides only the local preview.

An explicit play/pause control enables up to one native frame per second for timer/state modules. It starts paused, never overlaps a slow render or catches up with missed ticks, and skips hidden/offscreen views, another open dialog, outstanding frame/input work and disconnected/powered-off/flashing states. Expanded focus mode remains eligible. Power-off and pagehide pause it. This is bounded native frame refresh, not peripheral or full animation emulation.

## Reused flasher

`scripts/bundle-flasher.mjs` copies configurator `flasher.js` and `flash-core.js` byte-for-byte, then bundles installed esptool-js0.7.1 with Vite8.3.5 into one ESM file. Original sources, provenance and esptool-js/pako/atob-lite licenses remain in `web/vendor/`.

Bundle: 370,157 bytes; SHA-256 `e2f84119743556e5910bd9554a6767cafc5d127a228a652c12e22f5178658eae`.

The explicit sequence is Connect → Prepare original validated app/partition plan → inspect exact source/artifact hashes and ranges → checkbox approval → separate Write/readback click. The library is preloaded to keep requestPort within the direct Connect gesture. App-only installation retains existing bootloader/NVS and rejects nonstock layouts. All chip9/16MiB/security/image/partition/ROM-watchdog/MD5/SHA checks remain unchanged. No chat, build or preview event opens a chooser or writes USB.

## Verification

- Focused `node --test tests/ui*.test.mjs`: **21 passed**. Coverage includes exact approval revocation and single-use consumption, bundled validator/readback failures, CSRF/errors, RGB conversion, scaled tap coordinates, physical bounds, long tap duration, gesture threshold wheel direction and bounded optional playback.
- Original configurator frontend `npm test`: **61 passed**; unchanged upstream flasher/core sources remain the source of the bundled implementation.
- app.js/settings.js syntax checks passed.
- Root owns the complete HTTP/native/compiler suite outside the restricted harness. This report does not substitute its focused checks for that integrated run.

## Generic Chrome verification

Verified against the final main server on 2026-11-05, source prefix `0859c0bb47e8`, with the starter source/history left unchanged:

- Expanded mode displayed the full enlarged native frame without cropping. The same single canvas returned to the original pane on collapse; the native page state was retained.
- A real mouse drag navigated Home → Modules. A native tap opened the Interface example; the Back hit target returned to Modules. Wheel input opened Settings. Native taps changed the example toggle and restored it. Plus returned to Home. These are real reducer/model transitions, not browser-only screens.
- Explicit 1-frame/second playback entered the active state and paused again. Opening the source modal retained the playback selection; hidden-modal skipping and slow-render/no-backlog behavior are also covered by controller tests. The main view was left paused, on Home with the example toggle off.
- `app_view.h` was editable while the protected `Feature.h` adapter was read-only with Save disabled. No source was edited. A single canvas remained present after nested modal closure.
- The actual native Check button returned passing public-source, framebuffer, public-state-codec, input/tick, declared-screen/scenario and rounded-mask checks.
- Known native frame/action labels were localized. A true `X-Preview-State-Reset` header displays a concise state-reset notice without treating it as an error.

No inference, design approval, firmware build, credential entry, serial chooser or physical flash was performed by UI verification. Pointer/touch coordinate and duration behavior is covered by tests; this is not a physical device or touchscreen hardware test.
