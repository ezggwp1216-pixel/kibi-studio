# GitHub bootstrap publication review — 2026-11-05

Independent read-only review of START_HERE.md, distribution.json, generated launch prompt/renderer, scripts/bootstrap.py, public package allowlist, and the existing-site guide HTML/JS/metadata contract. No GitHub writes, SSH, auth/private settings, BIN inspection, inference or device actions performed.

## Disposition

No important remaining code defect found in the reviewed download/extraction path. The identified commit-pinning conflict is fixed: an exact SHA supplied by the website/caller/instruction URL is retained; main is resolved only if no SHA was supplied. The renderer now supports explicit immutable commit links and has a regression for that behavior.

The helper restricts downloads to the fixed public repository and exact commit; release/manifest/archive identities agree; archive and all member bytes are hash-checked before extraction. It bounds download/expanded size and member count, rejects traversal, forbidden private paths, links/special entries and conflicting members, creates only a fresh destination, and preserves executable mode only for the known launcher. It downloads and extracts without executing the kit or reading auth/USB data.

The guide and instructions correctly distinguish the archive distribution repository from the runtime folder, local terminal/filesystem access from an ordinary cloud chat, manual prerequisites from a universal installer, and ChatGPT login from service API keys. Current guide sourceCommit remains intentionally unfilled until actual publication; it must be replaced with the verified public commit before deployment.

## Publication requirements

- External release.json must include the actual archive SHA/bytes/expanded bytes/file count/root/platform plus bootstrapSha256, as required by START_HERE.
- Use a GitHub-root README whose links match the actual flat uploaded files; the runtime README references paths inside the ZIP and should not be reused verbatim as that external index.
- Check Python3 availability before the helper invocation on a fresh Mac; missing tools require their normal official installation flow, not a fabricated successful launch.
- Cold-test actual public raw URLs and pinned helper download/extraction after upload. Static fixture tests do not prove GitHub serving or the final metadata snapshot.

## Verification

`node --test tests/bootstrap-download.test.mjs tests/bootstrap-prompt.test.mjs`: 4 Node tests passed; the download wrapper ran 6 Python fixture tests. Tests cover pinned source identity, hash/manifest failure, overwrite/symlink/traversal/private paths and expansion limits, plus unsafe repository/ref/prompt metadata. No broad native or production tests were rerun by this review.
