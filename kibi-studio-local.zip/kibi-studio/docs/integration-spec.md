# Kibi Studio local architecture

Current scope: a reusable personal local development foundation for stock Kibi. No predetermined product/application and no production website/VPS deployment. The neutral starter demonstrates the shared UI/input contract.

## Runtime

Browser UI → localhost Node HTTP/SSE → local Codex app-server stdio with the user's ChatGPT-managed login. No OpenAI API-key fallback, token scraping, public auth proxy or arbitrary browser RPC. App-server threads have their own Studio history; they are not ChatGPT Project history/memory.

Current installed Codex rejects legacy readOnly.access. Bridge selects a process-local named read-only permission profile with :minimal plus project workspace reads and network disabled, and verifies the effective profile before inference. Built-in shell/network/tools/plugins/apps are disabled. Application operations use only the explicit dynamic tools. Account status is sanitized; tokens/email never enter UI/context.

## Public/private layout

- web: monochrome editor and prebundled unchanged tested Web Serial flasher.
- src/native: local controllers, sandboxed native runner and fixed build recipe.
- resources: board profile, partitions, inventoried native IDF5.5.5 SDK, stock libraries/licenses.
- projects/kibi-base: public project metadata and firmware; source export contains no settings/binaries.
- .studio: private mode0700 state/settings/jobs; files0600. Project state is .studio/kibi-base-state.json. Generated credential header/intermediates removed after compilation; personalized artifacts remain private.

Every source transaction validates canonical project/metadata paths; every private write validates private path boundaries. Symlinks/special files/path traversal/build overrides are rejected. Source SHA, revision, approval and configuration revision tie code to current artifacts. Configured compiler diagnostics stay private: malicious C++ can encode macro bytes, so literal redaction alone is insufficient. UI receives fixed summaries; agent receives status/source metadata only.

## Native contract

Only DS-02: ESP32-S3/chip9,16MiB,DIO40/OPI80,240×296 RGB565/radius62,Source Sans3,plus40/minus39,CST810,two2MiB app partitions. Fixed adapters preserve display/touch calibration, bounded events, wake/power and codec standby. No invented software power GPIO.

app_core.h: KibiApp::Model/Input/Action, reducer and portable tick, public state encode/decode. app_view.h: View::Context and render. app_feature.h: application lifecycle hooks. Feature.h/project.ino are protected hardware adapters.

The native runner includes the same source/font/corner-mask code, produces exactly213120 RGB888 bytes and returns bounded public state/actions. It uses the app codec rather than hardcoding module state. JS only paints those pixels and sends native coordinates/gestures. Scenarios: ready/loading/offline/stale. Expanded preview reuses the same canvas, with pointer/touch/wheel input and visible feedback.

Native subprocesses cannot read credentials, use network, fork or reach unrelated host services. Compile/render time, file/output and memory budgets apply; sandbox setup fails closed. Native checks verify shared source/input/frame properties, not I2C/radio/audio/battery/power or successful physical installation.

## Tools and authoring

kibi_project_context; kibi_read_source; kibi_write_source; kibi_set_requirements; kibi_preview (actual image, optional input); kibi_check. No model build/USB/shell/HTTP tool.

Design: app_view.h editable. After explicit approval: app_core.h and app_feature.h also editable. All writes require expected file SHA. Core/view changes revoke design approval; any source/config change revokes stale binaries. Protected drivers/adapters cannot be changed through these tools. Library versions/SDK are fixed; arbitrary missing libraries are not silently installed.

Service requirements are explicit {wifi,api} flags. Offline starter needs neither. Settings accepts private Wi-Fi and optional service key/base URL. Compilation receives only allowed values, generates KIBI_WIFI_SSID/PASSWORD and KIBI_SERVICE_API_KEY/BASE_URL in private staging. API base URLs must be HTTPS without credentials. Configured flags, never values, reach the model.

## Build/USB

Local macOS Arduino CLI1.5.1/core3.3.12/esp-x32/2601 with exact bundled SDK and libraries. Trusted compile recipe, no custom flags/partition modifications/global-install writes. App bounded to2MiB; four artifacts with sizes/offsets/SHA. No VPS/Docker required on this prepared Mac. Clean-computer prerequisites are diagnosed, not automatically installed.

Explicit user workflow: approve design → build → download/connect board → prepare plan → approve exact current artifact → write/readback. Existing flasher retained byte-for-byte behind a pinned esptool-js0.7.1 ESM bundle. Preserve chip/flash/encryption/partition checks, RTC/watchdog workaround, per-sector MD5 and full SHA readback, app-only update with NVS/filesystem retained. No automatic USB selection/write.

## HTTP

Bind127.0.0.1:4387. Host/Origin/Fetch-Metadata guards, process CSRF on mutations, no CORS. Only safe root/index top-level document navigation is allowed cross-site. Static canonical web files only.

GET state/events/source/preview/frame/export/bootstrap-prompt; POST chat/chat-interrupt/design-approve/source/settings/preview-input/check/build/approvals; DELETE selected settings. Build/artifact/manifest endpoints reject stale source/configuration and recheck bytes against hashes. SSE never forwards raw auth/protocol/private compiler data. Chat has real streaming, stop/error and explicit permission states; crashes recover interrupted jobs/messages.

## Distribution

Allowlisted public runtime ZIP under kibi-studio/, plus inventory and archive SHA. Includes exact SDK/library/legal resources. Never traverses .studio/.git/auth/node_modules/backups. One exact public SDK bootloader ELF is inventoried and needed by Arduino; personalized BINs/otherELFs are excluded. Startup prompt requires a local project with terminal/filesystem access; an ordinary cloud prompt cannot install/open local software silently.

Official auth/runtime background: https://learn.chatgpt.com/docs/app-server ; https://developers.openai.com/siwc/token-sharing-open-source . This personal/local managed-auth path is not a public commercial hosted auth service.
