# Kibi Studio local architecture

Current scope: a reusable personal development foundation for stock Kibi. The editor, project and ChatGPT bridge run locally; Kibi server services compile the preview and firmware through an automatic temporary technical session. No predetermined product/application. The neutral starter demonstrates the shared UI/input contract.

## Runtime

Browser UI → localhost Node HTTP/SSE → local Codex app-server stdio with the user's ChatGPT-managed login. No OpenAI API-key fallback, token scraping, public auth proxy or arbitrary browser RPC. App-server threads have their own Studio history; they are not ChatGPT Project history/memory.

Codex uses a process-local named read-only permission profile with :minimal plus project workspace reads and network disabled, and verifies the effective profile before inference. Automatic external AGENTS.md loading is disabled only for this process; the Kibi contract is provided explicitly. Built-in shell/network/tools/plugins/apps are disabled. Application operations use only the explicit dynamic tools. Account status is sanitized; tokens/email never enter UI/context. The installer creates a dedicated project CODEX_HOME; no global auth/config is copied or changed.

Localhost Node → HTTPS Kibi API automatically obtains a short-lived technical guest session for preview and firmware jobs. Local Studio never asks for a Kibi email, password or registration; website email authentication remains unchanged. The guest capability is limited to its own preview/build jobs and cannot access website account or server AI APIs. Cookie/CSRF/expiry live only in Node memory, never in the browser, project files, model context or exports. ChatGPT tokens never leave the local bridge. Ownership, CSRF and quotas remain enabled. Known expiry is handled before the next request; failed mutations are not automatically retried.

## Public/private layout

- web: monochrome editor and prebundled unchanged tested Web Serial flasher.
- src/native: local controllers, remote clients, shared native runner and the optional prepared-host development implementation.
- resources: board profile, partitions, inventoried native IDF5.5.5 SDK, stock libraries/licenses.
- projects/kibi-base: public project metadata and firmware; source export contains no settings/binaries.
- .studio: private mode0700 state/settings/jobs/account; files0600. Project state is .studio/kibi-base-state.json. Sources/history/settings and downloaded artifacts remain local. Only the source snapshot and required build parameters cross HTTPS to the Kibi service. Generated credential headers/intermediates are removed after compilation; remote personalized artifacts remain scoped to the creating session.

Every source transaction validates canonical project/metadata paths; every private write validates private path boundaries. Symlinks/special files/path traversal/build overrides are rejected. Source SHA, revision, approval and configuration revision tie code to current artifacts. Configured compiler diagnostics stay private: malicious C++ can encode macro bytes, so literal redaction alone is insufficient. UI receives fixed summaries; agent receives status/source metadata only.

## Native contract

Only DS-02: ESP32-S3/chip9,16MiB,DIO40/OPI80,240×296 RGB565/radius62,Source Sans3,plus40/minus39,CST810,two2MiB app partitions. Fixed adapters preserve display/touch calibration, bounded events, wake/power and codec standby. No invented software power GPIO.

app_core.h: KibiApp::Model/Input/Action, reducer and portable tick, public state encode/decode. app_view.h: View::Context and render. app_feature.h: application lifecycle hooks. Feature.h/project.ino are protected hardware adapters.

The server compiles and runs the native runner with the same source/font/corner-mask code. It produces exactly213120 RGB888 bytes and returns bounded public state/actions. Preview requests contain public source/state and never Wi-Fi/API values. It uses the app codec rather than hardcoding module state. JS only paints those pixels and sends native coordinates/gestures. Scenarios: ready/loading/offline/stale. Expanded preview reuses the same canvas, with pointer/touch/wheel input and visible feedback. A per-project queue preserves state across concurrent frame/input updates.

Isolated native subprocesses cannot read credentials or reach unrelated host services. Compile/render time, file/output and memory budgets apply; sandbox setup fails closed. Native checks verify shared source/input/frame properties, not I2C/radio/audio/battery/power or successful physical installation. The local native implementation remains available for development on a prepared host; end users do not install clang/Xcode.

## Tools and authoring

Composer photos are private local attachments: browser-normalized JPEG at most256KiB/1600px, at most4 per message. Local POST/api/attachments stores the normalized bytes under the captured project; asynchronous preparation cannot upload into another active project. Draft thumbnails/IDs stay in a per-project browser map and object URLs are revoked on removal/send/pagehide. Public state/history contain only scoped metadata URLs. Explicit message Send supplies attachment IDs; only then are image data URLs passed privately to the ChatGPT bridge. They are never firmware/source exports. The separate «Проект готов» action approves the captured revision and sends a short code-generation instruction without consuming or transmitting unsent photo/text drafts. It never invokes firmware compilation or USB.

kibi_project_context; kibi_read_source; kibi_write_source; kibi_set_requirements; kibi_preview (actual image, optional input); kibi_check. No model build/USB/shell/HTTP tool.

Design: app_view.h editable. After explicit approval: app_core.h and app_feature.h also editable. All writes require expected file SHA. Core/view changes revoke design approval; any source/config change revokes stale binaries. Protected drivers/adapters cannot be changed through these tools. Board SDK and base library versions are fixed; additional dependencies use the existing bounded server resolver and version lock. A preview cannot substitute a fake result for an unresolved dependency.

Service requirements are explicit {wifi,api} flags. Offline starter needs neither, while Studio itself needs internet for AI and compilation. Settings accepts private Wi-Fi and optional service key/base URL. Only allowed required values are uploaded for firmware compilation, which generates KIBI_WIFI_SSID/PASSWORD and KIBI_SERVICE_API_KEY/BASE_URL in private staging. The protected KIBI_CONFIG declaration identifies supported inputs. API base URLs must be HTTPS without credentials. Configured flags, never values, reach the model; preview gets no private configuration.

## Build/USB

The Kibi server worker owns Arduino/core3.3.12/esp-x32/2601 and exact IDF5.5.5 SDK/libraries. Source ZIP uploads use the existing private job queue, ownership checks and quotas. The trusted recipe rejects custom build flags and partition modifications. App bounded to2MiB; four artifacts with sizes/offsets/SHA. The local client downloads every artifact, validates the Kibi profile and content hashes, and binds the job to source/configuration revisions. Compiler diagnostics remain private because they can encode user parameters. Neither compiler, Docker nor Arduino is required on the user's Mac.

Explicit user workflow: approve design → build → download/connect board → prepare plan → approve exact current artifact → write/readback. Existing flasher retained byte-for-byte behind a pinned esptool-js0.7.1 ESM bundle. Preserve chip/flash/encryption/partition checks, RTC/watchdog workaround, per-sector MD5 and full SHA readback, app-only update with NVS/filesystem retained. No automatic USB selection/write.

## HTTP

Bind127.0.0.1:4387. Host/Origin/Fetch-Metadata guards, process CSRF on mutations, no CORS. Only safe root/index top-level document navigation is allowed cross-site. Static canonical web files only.

GET state/events/source/preview/frame/export/bootstrap-prompt; POST chat/chat-interrupt/design-approve/source/settings/preview-input/check/build/approvals plus automatic cloud-session reconnect; DELETE selected settings. Local Studio does not expose Kibi email-login or registration forms. The remote session cookie/CSRF is kept only in the server process memory. Build/artifact/manifest endpoints reject stale source/configuration and recheck bytes against hashes. SSE never forwards raw auth/protocol/private compiler data. Chat has real streaming, stop/error and explicit permission states; crashes recover interrupted jobs/messages.

## Distribution

Allowlisted public runtime ZIP under kibi-studio/, plus inventory and archive SHA. Includes exact public SDK/library/legal resources. Never traverses .studio/.git/auth/node_modules/backups. One exact public SDK bootloader ELF is inventoried; personalized BINs/otherELFs are excluded. Startup prompt requires a local project with terminal/filesystem access; an ordinary cloud prompt cannot install/open local software silently.

The commit-pinned bootstrap.sh uses only macOS shell/curl/tar/shasum, verifies and installs private Node24.22.2, then checks bootstrap.mjs/runtime-lock.json against the same release metadata. The Node helper verifies ZIP/manifest/member hashes and paths before creating a new project. Official Codex0.166.0 is integrity-pinned for arm64/x64. If Chrome/Edge is absent, the helper downloads official Chrome, verifies its signature, Google TeamIdentifier and Gatekeeper assessment, then copies it to the user's Applications directory. No sudo, Homebrew, Python, Xcode or Arduino installation is needed. User browser login remains explicit; the launcher reuses the private runtime/account. Existing projects are never overwritten.

Official auth/runtime background: https://learn.chatgpt.com/docs/app-server ; https://developers.openai.com/siwc/token-sharing-open-source . This personal/local managed-auth path is not a public commercial hosted auth service.
