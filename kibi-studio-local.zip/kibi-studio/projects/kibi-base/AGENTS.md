# Kibi Base application

Build a new application on the stock Kibi DS-02 / ESP32-S3 / 16MiB flash / OPI80 / DIO40 / native 240×296 RGB565 radius62. Preserve the protected hardware adapter, all drivers, pins, calibration, sleep/wake, audio standby and SDK. Device typography uses prepared Source Sans3 AA4 glyphs.

`firmware/app_core.h` contains portable state, input decisions, monotonic tick, and encodeState/decodeState JSON codecs. Extend these codecs when adding module state; only bounded public JSON is persisted between preview processes, never credentials. `app_view.h` renders the exact device framebuffer, also compiled by Studio's native preview. `app_feature.h` contains portable begin/tick/input extension hooks. `Feature.h` is the protected hardware adapter. `project.ino` is the entry point. The base requires no Wi-Fi or API service. Settings and module labels in this starter are working local examples, not connected hardware services or telemetry.

Use the Studio `kibi_*` tools for project context, allowed source edits, preview and checks. During design, edit `app_view.h` only; application logic requires explicit design approval. The controller enforces file hashes and revisions. Never bypass protected paths or read auth, private settings, personalized binaries or owner backups. Optional Wi-Fi/API configuration is entered privately in Studio and injected only into compilation staging; do not embed credentials.

Build, device connection, artifact approval and USB write are explicit user actions. No chat or preview action flashes automatically. Native checks verify the shared renderer and input/model logic; report physical board behavior only after a real hardware test. Local Codex app-server threads do not inherit ChatGPT Project memory.
