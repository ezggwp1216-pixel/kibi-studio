#pragma once

#include "fullscreen_page.h"
#include "audio_file.h"
#include "note_deletions.h"
#include "shopping_notes.h"
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>

namespace Tamagotchi {

inline bool validNoteText(const char* text) {
  if (!text || !*text) return false;
  bool visible=false;
  const auto* at=reinterpret_cast<const uint8_t*>(text);
  while (*at) {
    uint32_t code=*at++;
    if (code<128) {
      if (code<32 && code!='\n' && code!='\r' && code!='\t') return false;
      visible |= code>32;
      continue;
    }
    int extra=0; uint32_t minimum=0;
    if (code>=0xC2 && code<=0xDF) { extra=1; code&=31; minimum=0x80; }
    else if (code>=0xE0 && code<=0xEF) { extra=2; code&=15; minimum=0x800; }
    else if (code>=0xF0 && code<=0xF4) { extra=3; code&=7; minimum=0x10000; }
    else return false;
    for (int i=0;i<extra;++i) {
      if ((*at&0xC0)!=0x80) return false;
      code=(code<<6)|(*at++&63);
    }
    if (code<minimum || code>0x10FFFF || (code>=0xD800 && code<=0xDFFF)) return false;
    visible=true;
  }
  return visible;
}

inline void makeNoteTitle(const char* text,char* out,size_t capacity) {
  if (!out || !capacity) return;
  size_t used=0; int characters=0,words=0;
  while (*text==' ' || *text=='\n' || *text=='\r' || *text=='\t') ++text;
  while (*text && *text!='\n' && *text!='\r' && characters<36) {
    const char* start=text;
    const uint32_t code=Ui::nextTextCodepoint(text);
    const size_t bytes=size_t(text-start);
    if (used+bytes>=capacity) break;
    if (code==' ' || code=='\t') {
      if (++words>=6) break;
      if (!used || out[used-1]==' ') continue;
      out[used++]=' ';
    } else { memcpy(out+used,start,bytes); used+=bytes; }
    ++characters;
    if (code=='.' || code=='!' || code=='?') break;
  }
  while (used && out[used-1]==' ') --used;
  out[used]=0;
}

inline void makeShoppingTitle(const char* text,char* out,size_t capacity) {
  if(!out || !capacity) return;
  size_t used=0; int words=0,characters=0; bool lineStart=true;
  while(*text && words<4 && characters<36) {
    while(*text==' ' || *text=='\t' || *text=='\n' || *text=='\r') {
      if(*text=='\n' || *text=='\r') lineStart=true;
      ++text;
    }
    if(!*text) break;
    if(lineStart) {
      if((*text=='-' || *text=='*') && (text[1]==' ' || text[1]=='\t')) { text+=2; continue; }
      if(!strncmp(text,"•",3) && (text[3]==' ' || text[3]=='\t')) { text+=4; continue; }
      const char* number=text;
      while(*number>='0' && *number<='9') ++number;
      if(number>text && (*number=='.' || *number==')') && (number[1]==' ' || number[1]=='\t')) { text=number+2; continue; }
    }
    lineStart=false;
    if(used) { if(used+1>=capacity) break; out[used++]=' '; ++characters; }
    ++words;
    while(*text && *text!=' ' && *text!='\t' && *text!='\n' && *text!='\r' && characters<36) {
      const char* start=text; Ui::nextTextCodepoint(text);
      const size_t bytes=size_t(text-start);
      if(used+bytes>=capacity) { out[used]=0; return; }
      memcpy(out+used,start,bytes); used+=bytes; ++characters;
    }
  }
  while(used && out[used-1]==' ') --used;
  out[used]=0;
}
struct NoteSummary { uint32_t id=0; char title[kNoteTitleBytes]{}; bool shopping=false; };
inline void makeStoredNoteTitle(const char* text,NoteSummary& summary) {
  const char* shopping=ShoppingNotes::body(text);
  summary.shopping=shopping!=nullptr;
  if(shopping) {
    makeShoppingTitle(shopping,summary.title,sizeof summary.title);
    if(!*summary.title) strcpy(summary.title,"Shopping");
  }
  else makeNoteTitle(text,summary.title,sizeof summary.title);
}

// Plain UTF-8 files on LittleFS's POSIX VFS. The same implementation is tested
// against real host files, including restart and interrupted-write recovery.
class NoteStore {
 public:
  bool begin(const char* directory) {
    count_=0; lastId_=0; bytesUsed_=0; ready_=false;
    if (!directory || strlen(directory)>=sizeof(directory_)) return false;
    strcpy(directory_,directory);
    if (mkdir(directory_,0777)!=0 && errno!=EEXIST) return false;
    uint32_t deletedMaximum=0;
    if(!NoteDeletions::initialize(directory_,deletedMaximum)) return false;
    char sequence[128]; namedPath(".sequence",sequence);
    FILE* counter=fopen(sequence,"rb");
    if(counter) {
      char value[10]{}; const size_t n=fread(value,1,9,counter);
      const bool complete=!ferror(counter) && fgetc(counter)==EOF; fclose(counter);
      if(!complete || n!=9 || value[8]!='\n' || !parseHex(value,lastId_)) return false;
    } else if(errno!=ENOENT) return false;
    if(deletedMaximum>lastId_) lastId_=deletedMaximum;
    DIR* dir=opendir(directory_); if(!dir) return false;
    // Include every allocated name, including deleted/corrupt notes, in the ID
    // high-water mark. A complete delete journal wins over an interrupted remove.
    while(const auto* entry=readdir(dir)) {
      uint32_t id;
      const bool deleted=parseName(entry->d_name,'d',".del",id);
      if(deleted || parseName(entry->d_name,'n',".txt",id)) {
        if(id>lastId_) lastId_=id;
        if(deleted && (NoteDeletions::lookupLegacy(directory_,id)!=NoteDeletions::State::Deleted ||
            !NoteDeletions::remember(directory_,id))) { closedir(dir); return false; }
      }
    }
    rewinddir(dir);
    BoundedText text;
    if(!text.reserve(kNoteTextBytes+1)) { closedir(dir); return false; }
    while(const auto* entry=readdir(dir)) {
      uint32_t id=0; if(!parseName(entry->d_name,'n',".txt",id)) continue;
      char path[128]; pathFor(id,path);
      struct stat info{};
      const auto deleted=NoteDeletions::lookup(directory_,id);
      if(deleted==NoteDeletions::State::Error) { closedir(dir); return false; }
      if(deleted==NoteDeletions::State::Deleted) { remove(path); continue; }
      if(stat(path,&info)!=0 || !S_ISREG(info.st_mode) || info.st_size<1 || info.st_size>kNoteTextBytes) continue;
      FILE* file=fopen(path,"rb"); if(!file) continue;
      const size_t read=fread(text.data(),1,size_t(info.st_size),file);
      const bool complete=!ferror(file) && read==size_t(info.st_size) && fgetc(file)==EOF;
      fclose(file); text.data()[read]=0;
      if(!complete || memchr(text.data(),0,read) || !validNoteText(text.data())) continue;
      NoteSummary summary; summary.id=id;
      makeStoredNoteTitle(text.data(),summary);
      bytesUsed_+=read;
      if(*summary.title) insert(summary,read);
    }
    closedir(dir);
    if(!persistSequence(lastId_)) return false;
    ready_=true; return true;
  }
  int count() const { return count_; }
  size_t bytesUsed() const { return bytesUsed_; }
  const NoteSummary* summary(int index) const { return index>=0 && index<count_ ? &items_[index] : nullptr; }
  uint32_t reserveId() {
    if(!ready_ || lastId_==UINT32_MAX || !persistSequence(lastId_+1)) return 0;
    return ++lastId_;
  }
  bool save(const char* text) {
    if(!ready_ || count_>=kMaxNotes || lastId_==UINT32_MAX || !text) return false;
    const size_t bytes=strnlen(text,kNoteTextBytes+1);
    if(bytes>kNoteTextBytes || !validNoteText(text) || bytesUsed_>kNotesQuotaBytes || bytes>kNotesQuotaBytes-bytesUsed_) return false;
    // Reserve the ID durably before publishing a note. A failed write can skip
    // an ID, but cannot reuse a deleted ID after a restart.
    const uint32_t id=reserveId();
    return id && saveReserved(id,text);
  }
  bool saveReserved(uint32_t id,const char* text) {
    if(!ready_ || !id || id>lastId_ || !text) return false;
    const size_t bytes=strnlen(text,kNoteTextBytes+1);
    if(bytes>kNoteTextBytes || !validNoteText(text)) return false;
    if(NoteDeletions::lookup(directory_,id)!=NoteDeletions::State::Clear) return false;
    char deleted[128]; markerFor(id,deleted); struct stat info{};
    if(stat(deleted,&info)==0 || errno!=ENOENT) return false;
    char existing[128]; pathFor(id,existing);
    if(stat(existing,&info)==0) {
      if(!S_ISREG(info.st_mode) || size_t(info.st_size)!=bytes) return false;
      FILE* file=fopen(existing,"rb"); if(!file) return false;
      char chunk[512]; size_t offset=0; bool equal=true;
      while(offset<bytes && equal) {
        const size_t want=bytes-offset<sizeof chunk?bytes-offset:sizeof chunk;
        const size_t read=fread(chunk,1,want,file);
        equal=read==want && !memcmp(chunk,text+offset,want); offset+=read;
      }
      equal=equal && !ferror(file) && fgetc(file)==EOF; fclose(file);
      return equal;
    }
    if(errno!=ENOENT || count_>=kMaxNotes || bytesUsed_>kNotesQuotaBytes || bytes>kNotesQuotaBytes-bytesUsed_) return false;
    char path[128],temporary[128]; pathFor(id,path); namedPath("new.tmp",temporary);
    if(!atomicWrite(temporary,path,text,bytes)) return false;
    NoteSummary item; item.id=id; makeStoredNoteTitle(text,item);
    insert(item,bytes); bytesUsed_+=bytes; return true;
  }
  bool load(int index,char* out,size_t capacity) const {
    if(!out || !capacity) return false;
    out[0]=0; const auto* item=summary(index); if(!item) return false;
    char path[128]; pathFor(item->id,path); struct stat info{};
    if(stat(path,&info) || size_t(info.st_size)!=sizes_[index] || sizes_[index]>=capacity) return false;
    FILE* file=fopen(path,"rb"); if(!file) return false;
    const size_t bytes=fread(out,1,sizes_[index],file);
    const bool complete=!ferror(file) && bytes==sizes_[index] && fgetc(file)==EOF;
    fclose(file); out[bytes]=0;
    if(complete && !memchr(out,0,bytes) && validNoteText(out)) return true;
    out[0]=0; return false;
  }
  bool eraseId(uint32_t id,bool journal=true) {
    if(!ready_ || !id) return false;
    if(!NoteDeletions::canRemember(directory_,id)) return false;
    if(id>lastId_) { if(!persistSequence(id)) return false; lastId_=id; }
    char path[128]; pathFor(id,path);
    if(journal) {
      char marker[128],temporary[128]; markerFor(id,marker);
      snprintf(temporary,sizeof temporary,"%s/d%08lx.tmp",directory_,static_cast<unsigned long>(id));
      // The remote deletion request is persisted BEFORE removing the only copy.
      // Repeated deletion is safe and never clears an existing journal entry.
      const auto existing=NoteDeletions::lookupLegacy(directory_,id);
      if(existing==NoteDeletions::State::Error ||
          (existing==NoteDeletions::State::Clear && !atomicWrite(temporary,marker,"deleted\n",8))) return false;
    }
    // Local outgoing intent is durable before permanent suppression. A failed
    // snapshot keeps both the note and marker so startup/retry can finish it.
    if(!NoteDeletions::remember(directory_,id)) return false;
    if(remove(path)!=0 && errno!=ENOENT) return false;
    for(int i=0;i<count_;++i) if(items_[i].id==id) {
      bytesUsed_-=sizes_[i];
      for(int j=i+1;j<count_;++j) { items_[j-1]=items_[j]; sizes_[j-1]=sizes_[j]; }
      --count_; break;
    }
    return true;
  }
 private:
  char directory_[80]{};
  NoteSummary items_[kMaxNotes]{};
  size_t sizes_[kMaxNotes]{},bytesUsed_=0;
  int count_=0; uint32_t lastId_=0; bool ready_=false;
  void namedPath(const char* name,char (&out)[128]) const { snprintf(out,sizeof out,"%s/%s",directory_,name); }
  void pathFor(uint32_t id,char (&out)[128]) const { snprintf(out,sizeof out,"%s/n%08lx.txt",directory_,static_cast<unsigned long>(id)); }
  void markerFor(uint32_t id,char (&out)[128]) const { snprintf(out,sizeof out,"%s/d%08lx.del",directory_,static_cast<unsigned long>(id)); }
  static bool atomicWrite(const char* temporary,const char* path,const char* text,size_t bytes) {
    FILE* file=fopen(temporary,"wb"); if(!file) return false;
    const bool wrote=fwrite(text,1,bytes,file)==bytes;
    const bool flushed=fflush(file)==0;
    const bool synced=flushed && fsync(fileno(file))==0;
    const bool closed=fclose(file)==0;
    if(!wrote || !synced || !closed || rename(temporary,path)!=0) { remove(temporary); return false; }
    return true;
  }
  bool persistSequence(uint32_t id) const {
    char path[128],temporary[128],value[10]; namedPath(".sequence",path); namedPath(".sequence.tmp",temporary);
    snprintf(value,sizeof value,"%08lx\n",static_cast<unsigned long>(id));
    return atomicWrite(temporary,path,value,9);
  }
  static bool parseHex(const char* value,uint32_t& id) {
    id=0;
    for(int i=0;i<8;++i) {
      const unsigned char ch=value[i];
      const unsigned digit=ch>='0' && ch<='9'?ch-'0':(ch>='a' && ch<='f'?ch-'a'+10:(ch>='A' && ch<='F'?ch-'A'+10:16));
      if(digit>=16) return false;
      id=(id<<4)|digit;
    }
    return true;
  }
  static bool parseName(const char* name,char prefix,const char* suffix,uint32_t& id) {
    return strlen(name)==13 && name[0]==prefix && !strcmp(name+9,suffix) && parseHex(name+1,id) && id;
  }
  void insert(const NoteSummary& item,size_t bytes) {
    int place=0; while(place<count_ && items_[place].id>item.id) ++place;
    if(place>=kMaxNotes) return;
    if(count_<kMaxNotes) ++count_;
    for(int i=count_-1;i>place;--i) { items_[i]=items_[i-1]; sizes_[i]=sizes_[i-1]; }
    items_[place]=item; sizes_[place]=bytes;
  }
};

namespace NotesDetail {
enum class Page { Closed,List,Detail,Answer };
struct AnswerLayout {
  int titleTop,questionTop,bodyTop,bodyBottom,backLeft,backTop;
  int bodyLines,sourceLines;
  int titleLineHeight,bodyLineHeight,sourceLineHeight;
  static constexpr int backWidth=PageUi::Layout::backWidth,backHeight=PageUi::Layout::backHeight,backRadius=PageUi::Layout::backRadius;
  static constexpr int textLeft=12,textColumns=18,lineHeight=18,textScale=2,sectionGap=8;
  int contentHeight() const { return bodyLines*bodyLineHeight+sourceLines*sourceLineHeight+(sourceLines?sectionGap:0); }
  int sourceTop() const { return bodyTop+bodyLines*bodyLineHeight+sectionGap; }
};
struct Runtime {
  NoteStore store;
  Page page=Page::Closed;
  BoundedText body;
  char title[kNoteTitleBytes]{};
  BoundedText answer;
  char questionTitle[kNoteTitleBytes]{};
  char header[32]="Answer";
  char source[96]{};
  Page answerReturn=Page::Closed;
  bool draft=false,deleteConfirm=false,shoppingOnly=false;
  static_assert(kMaxNotes<=256,"Shopping view indices fit the fixed byte array");
  uint8_t shoppingIndices[kMaxNotes]{};
  int shoppingCount=0;
  uint32_t shoppingRevision=0;
  bool shoppingIndexValid=false;
  uint32_t selectedId=0;
  uint32_t revision=0;
};
inline Runtime runtime;
inline AnswerLayout answerLayout(int width,int height) {
  const bool answer=runtime.page==Page::Answer;
  const auto page=PageUi::layout(width,height,answer?runtime.header:"Note");
  const int top=page.titleTop,questionTop=page.bodyTop;
  const int titleLines=Ui::textLineCount(answer?runtime.questionTitle:runtime.title,AnswerLayout::textColumns);
  const int visibleTitleLines=titleLines>2?2:(titleLines>0?titleLines:1);
  const int titlePitch=Ui::textLineHeight(answer?runtime.questionTitle:runtime.title);
  const int bodyPitch=Ui::textLineHeight(answer?runtime.answer.data():runtime.body.data());
  const int sourcePitch=Ui::textLineHeight(answer?runtime.source:"");
  return {top,questionTop,questionTop+visibleTitleLines*titlePitch+AnswerLayout::sectionGap+(runtime.draft&&!answer?18:0),
      page.bodyBottom,page.backLeft,page.backTop,
      answer?Ui::textLineCount(runtime.answer.data(),AnswerLayout::textColumns):0,
      answer?Ui::textLineCount(runtime.source,AnswerLayout::textColumns):0,
      titlePitch,bodyPitch,sourcePitch};
}
inline PageUi::Layout listLayout(int width,int height) {
  return PageUi::layout(width,height,runtime.shoppingOnly?ShoppingNotes::kHeading:"Notes");
}
inline PageUi::Layout bodyLayout(const AnswerLayout& reader) {
  return {reader.titleTop,reader.bodyTop,reader.bodyBottom,reader.backLeft,reader.backTop};
}
inline int deleteLeft(int width) { return width-60; }
inline int deleteTop(int height) { return height-44; }
inline int confirmTop(int height) { return height-106; }
}
inline bool beginNotes(const char* directory="/littlefs/notes") {
  auto& state=NotesDetail::runtime;
  state.shoppingOnly=false;
  state.shoppingIndexValid=false;
  const bool memory=state.body.reserve(kNoteTextBytes+1) && state.answer.reserve(kNoteTextBytes+1);
  return memory && state.store.begin(directory);
}
inline void openNotes() {
  auto& state=NotesDetail::runtime; state.page=NotesDetail::Page::List; state.deleteConfirm=false; state.shoppingOnly=false; ++state.revision;
}
inline void openShoppingNotes() { openNotes(); NotesDetail::runtime.shoppingOnly=true; }
inline void refreshShoppingNoteIndex() {
  auto& state=NotesDetail::runtime;
  if(state.shoppingIndexValid && state.shoppingRevision==state.revision) return;
  state.shoppingCount=0;
  for(int i=0;i<state.store.count();++i)
    if(state.store.summary(i)->shopping) state.shoppingIndices[state.shoppingCount++]=uint8_t(i);
  state.shoppingRevision=state.revision; state.shoppingIndexValid=true;
}
inline int visibleNoteStoreIndex(int index) {
  if(index<0) return -1;
  const auto& state=NotesDetail::runtime;
  if(!state.shoppingOnly) return index;
  refreshShoppingNoteIndex();
  return index<state.shoppingCount?state.shoppingIndices[index]:-1;
}
inline const NoteSummary* visibleNoteSummary(int index) {
  return NotesDetail::runtime.store.summary(visibleNoteStoreIndex(index));
}
inline int visibleNoteCount() {
  const auto& state=NotesDetail::runtime;
  if(!state.shoppingOnly) return state.store.count();
  refreshShoppingNoteIndex();
  return state.shoppingCount;
}
inline bool notesVisible() { return NotesDetail::runtime.page!=NotesDetail::Page::Closed; }
inline bool notesAnswerVisible() { return NotesDetail::runtime.page==NotesDetail::Page::Answer; }
inline bool notesDetailVisible() {
  const auto page=NotesDetail::runtime.page;
  return page==NotesDetail::Page::Detail || page==NotesDetail::Page::Answer;
}
inline uint32_t notesRevision() { return NotesDetail::runtime.revision; }
inline const char* readerBody() {
  const auto& state=NotesDetail::runtime;
  if(state.page==NotesDetail::Page::Answer) return state.answer.data();
  const char* shopping=state.shoppingOnly?ShoppingNotes::body(state.body.data()):nullptr;
  return shopping?shopping:state.body.data();
}
inline bool saveVoiceNote(const char* transcript,bool open=true,uint32_t reservedId=0) {
  auto& state=NotesDetail::runtime;
  if (reservedId?state.store.saveReserved(reservedId,transcript):state.store.save(transcript)) {
    if(open) openNotes();
    else ++state.revision;
    return true;
  }
  // Keep a readable draft if persistent storage is full/unavailable.
  if(!transcript || strnlen(transcript,kNoteTextBytes+1)>kNoteTextBytes || !validNoteText(transcript) || !state.body.reserve(kNoteTextBytes+1)) return false;
  snprintf(state.body.data(),state.body.capacity(),"%s",transcript);
  makeNoteTitle(transcript,state.title,sizeof state.title);
  state.draft=true; state.selectedId=0; state.deleteConfirm=false; state.page=NotesDetail::Page::Detail; ++state.revision;
  return false;
}
// The reader is shared with notes; answers remain transient and are never
// inserted into the note store. Separate bounded storage preserves a readable
// unsaved draft even when persistent storage is full or unavailable.
inline bool showAssistantAnswer(const char* question,const char* answer,const char* source="",const char* heading="Answer") {
  if (!question || !answer || strnlen(question,kNoteTextBytes+1)>kNoteTextBytes || strnlen(answer,kNoteTextBytes+1)>kNoteTextBytes || !validNoteText(question) || !validNoteText(answer) ||
      !source || strlen(source)>=sizeof NotesDetail::runtime.source || (*source && !validNoteText(source)) ||
      !heading || strnlen(heading,sizeof NotesDetail::runtime.header)>=sizeof NotesDetail::runtime.header || !validNoteText(heading)) return false;
  auto& state=NotesDetail::runtime;
  if(!state.answer.reserve(kNoteTextBytes+1)) return false;
  state.deleteConfirm=false;
  if (state.page!=NotesDetail::Page::Answer)
    state.answerReturn=state.page;
  strcpy(state.answer.data(),answer); strcpy(state.source,source);
  strcpy(state.header,heading);
  makeNoteTitle(question,state.questionTitle,sizeof state.questionTitle);
  state.page=NotesDetail::Page::Answer; ++state.revision;
  return true;
}
inline int notesScrollLimit(int height) {
  const auto& state=NotesDetail::runtime;
  if(state.deleteConfirm) return 0;
  if(notesDetailVisible()) {
    const auto layout=NotesDetail::answerLayout(kScreenWidth,height);
    const int content=notesAnswerVisible()?layout.contentHeight():Ui::textLineCount(readerBody(),layout.textColumns)*layout.bodyLineHeight;
    return PageUi::scrollLimit(content,NotesDetail::bodyLayout(layout));
  }
  const int count=visibleNoteCount();
  const auto layout=NotesDetail::listLayout(kScreenWidth,height);
  const int content=count ? (count-1)*kNotesCardStride+kNotesCardHeight : 0;
  return PageUi::scrollLimit(content,layout);
}
inline int notesHit(int x,int y,int offset,int height) {
  const auto& state=NotesDetail::runtime;
  if(state.deleteConfirm) {
    if(Ui::roundedPixel(x-62,y-NotesDetail::confirmTop(height),116,38,10)) return -4;
    return PageUi::backHit(x,y,kScreenWidth,height)?-5:-1;
  }
  if(PageUi::backHit(x,y,kScreenWidth,height)) return -2;
  if(state.page==NotesDetail::Page::Detail && !state.draft && state.selectedId &&
      Ui::roundedPixel(x-NotesDetail::deleteLeft(kScreenWidth),y-NotesDetail::deleteTop(height),36,32,10)) return -3;
  const auto layout=NotesDetail::listLayout(kScreenWidth,height);
  if (notesDetailVisible() || y<layout.bodyTop || y>=layout.bodyBottom) return -1;
  const int64_t local=int64_t(y)-layout.bodyTop+offset;
  if (local<0) return -1;
  const int64_t item=local/kNotesCardStride;
  return item<visibleNoteCount() && Ui::roundedPixel(x-20,int(local%kNotesCardStride),200,kNotesCardHeight,12) ? int(item) : -1;
}
// Called by the main loop after the sync task queues a server tombstone.
// UI and NoteStore are never mutated by the network worker.
inline bool applyRemoteNoteDeletion(uint32_t id) {
  using namespace NotesDetail;
  if(!runtime.store.eraseId(id,false)) return false;
  if(runtime.selectedId==id && !runtime.draft) {
    runtime.selectedId=0; runtime.deleteConfirm=false;
    if(runtime.body.data()) runtime.body.data()[0]=0;
    if(runtime.page==Page::Detail) runtime.page=Page::List;
    if(runtime.answerReturn==Page::Detail) runtime.answerReturn=Page::List;
  }
  ++runtime.revision; return true;
}
inline void activateNoteTarget(int target) {
  using namespace NotesDetail;
  if(target==-5 || (target==-2 && runtime.deleteConfirm)) {
    runtime.deleteConfirm=false; ++runtime.revision; return;
  }
  if(target==-3 && runtime.page==Page::Detail && !runtime.draft && runtime.selectedId) {
    runtime.deleteConfirm=true; ++runtime.revision; return;
  }
  if(target==-4 && runtime.deleteConfirm) {
    if(runtime.store.eraseId(runtime.selectedId)) {
      runtime.selectedId=0; runtime.page=Page::List; runtime.deleteConfirm=false;
      ++runtime.revision;
    }
    return;
  }
  if(runtime.deleteConfirm) return;
  if(target==-2) {
    runtime.page=runtime.page==Page::Answer?runtime.answerReturn:(notesDetailVisible()?Page::List:Page::Closed);
    ++runtime.revision;
  } else if(target>=0 && runtime.body.reserve(kNoteTextBytes+1) && runtime.store.load(visibleNoteStoreIndex(target),runtime.body.data(),runtime.body.capacity())) {
    const auto* summary=visibleNoteSummary(target);
    strcpy(runtime.title,summary->title); runtime.selectedId=summary->id;
    runtime.draft=false; runtime.page=Page::Detail; ++runtime.revision;
  }
}
inline void drawNotes(uint16_t* frame,int width,int height,int offset,int pressed) {
  using namespace NotesDetail;
  if (!frame || !notesVisible() || width<1 || height<1) return;
  const bool answer=notesAnswerVisible();
  const bool detail=notesDetailVisible();
  const char* heading=runtime.deleteConfirm?"Delete note?":answer?runtime.header:
      detail?"Note":runtime.shoppingOnly?ShoppingNotes::kHeading:"Notes";
  PageUi::drawShell(frame,width,height,heading,pressed==(runtime.deleteConfirm?-5:-2));
  if(runtime.deleteConfirm) {
    const auto page=PageUi::layout(width,height,heading);
    Ui::wrappedText(frame,width,height,runtime.title,page.textLeft,page.bodyTop,
        page.textColumns,page.lineHeight,page.textScale,page.bodyTop,confirmTop(height)-12,2,true);
    Ui::box(frame,width,height,(width-116)/2,confirmTop(height),116,38,10,pressed==-4,0);
    Ui::wrappedText(frame,width,height,"Delete",12,Ui::centeredTextTop("Delete",confirmTop(height),38),18,18,2,
        confirmTop(height),confirmTop(height)+38,1,true);
    return;
  }
  offset=PageUi::boundedOffset(offset,notesScrollLimit(height));
  if(!detail) {
    const auto page=listLayout(width,height);
    const int count=visibleNoteCount();
    if(!count) PageUi::drawBody(frame,width,height,runtime.shoppingOnly?
        "No items yet. Hold + to add a shopping list.":
        "Hold + to create your first note.",page);
    for(int i=0;i<count;++i) {
      const int64_t top=int64_t(page.bodyTop)+int64_t(i)*kNotesCardStride-offset;
      if(top+kNotesCardHeight<=page.bodyTop || top>=page.bodyBottom) continue;
      // Menu cards may be partially visible at either end of the scrolling
      // body. Clip their fill and outline as well as their text to that body.
      for(int yy=0;yy<kNotesCardHeight;++yy) {
        const int y=int(top)+yy;
        if(y<page.bodyTop || y>=page.bodyBottom) continue;
        for(int xx=0;xx<200;++xx) {
          if(!Ui::roundedPixel(xx,yy,200,kNotesCardHeight,12)) continue;
          const bool edge=!Ui::roundedPixel(xx-1,yy-1,198,kNotesCardHeight-2,11);
          Ui::pixel(frame,width,height,20+xx,y,edge?theme().border:
              (pressed==i?theme().pressed:theme().card),edge?220:230);
        }
      }
      Ui::wrappedText(frame,width,height,visibleNoteSummary(i)->title,32,int(top)+10,
          14,20,2,page.bodyTop,page.bodyBottom,2);
    }
    const int content=count?(count-1)*kNotesCardStride+kNotesCardHeight:0;
    PageUi::drawScrollIndicator(frame,width,height,page,offset,content);
    return;
  }
  const auto reader=answerLayout(width,height);
  const auto page=bodyLayout(reader);
  Ui::wrappedText(frame,width,height,answer?runtime.questionTitle:runtime.title,reader.textLeft,
      reader.questionTop,reader.textColumns,reader.titleLineHeight,reader.textScale,
      reader.questionTop,reader.bodyTop-reader.sectionGap-(runtime.draft&&!answer?18:0),2,true);
  if(runtime.draft && !answer)
    Ui::text(frame,width,height,"Not saved",Ui::textCenteredX("Not saved",width,1),
        Ui::centeredTextTop("Not saved",reader.bodyTop-18,18,1),1,0xFBCA,0,reader.bodyTop);
  Ui::wrappedText(frame,width,height,readerBody(),reader.textLeft,reader.bodyTop-offset,
      reader.textColumns,reader.bodyLineHeight,reader.textScale,reader.bodyTop,reader.bodyBottom,kNoteTextBytes);
  if(answer && *runtime.source)
    Ui::wrappedText(frame,width,height,runtime.source,reader.textLeft,reader.sourceTop()-offset,
        reader.textColumns,reader.sourceLineHeight,reader.textScale,reader.bodyTop,reader.bodyBottom);
  if(runtime.page==Page::Detail && !runtime.draft && runtime.selectedId) {
    const int left=deleteLeft(width),top=deleteTop(height);
    Ui::box(frame,width,height,left,top,36,32,10,pressed==-3,0);
    for(int y=top+7;y<top+24;++y) for(int x=left+12;x<left+25;++x)
      if(y==top+7 || (y>=top+10 && (x==left+13 || x==left+23 || y==top+23)))
        Ui::pixel(frame,width,height,x,y,theme().text);
    for(int x=left+16;x<=left+20;++x) Ui::pixel(frame,width,height,x,top+5,theme().text);
  }
  const int content=answer?reader.contentHeight():Ui::textLineCount(readerBody(),reader.textColumns)*reader.bodyLineHeight;
  PageUi::drawScrollIndicator(frame,width,height,page,offset,content);
}
}  // namespace Tamagotchi
