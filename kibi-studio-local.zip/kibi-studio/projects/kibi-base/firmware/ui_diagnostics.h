#pragma once
#include <cstddef>
#include <cstdint>
#ifndef KIBI_UI_DIAGNOSTICS
#define KIBI_UI_DIAGNOSTICS 0
#endif
#if KIBI_UI_DIAGNOSTICS
#include <atomic>
#endif

namespace Tamagotchi::UiDiagnostics {
inline constexpr bool kEnabled=KIBI_UI_DIAGNOSTICS!=0;
inline constexpr size_t kBucketCount=64;
inline constexpr uint32_t kBucketWidthUs=4000;
inline constexpr uint32_t kMaximumBucketUs=kBucketCount*kBucketWidthUs;
struct PercentileUpperBound {
  bool available=false,overflow=false;
  uint32_t upperUs=0;
};
struct HistogramSnapshot {
  uint32_t buckets[kBucketCount]{};
  uint32_t count=0,lastUs=0,maxUs=0,overflow=0;
  // Inclusive bucket bounds, never exact percentiles. An overflow percentile
  // has no finite upper bound; upperUs remains zero and overflow is explicit.
  PercentileUpperBound percentileUpperBound(unsigned percent) const {
    if(!count) return {};
    if(percent<1) percent=1;
    if(percent>100) percent=100;
    const uint64_t rank=(uint64_t(count)*percent+99)/100;
    uint64_t accumulated=0;
    for(size_t i=0;i<kBucketCount;++i) {
      accumulated+=buckets[i];
      if(accumulated>=rank) return {true,false,uint32_t(i+1)*kBucketWidthUs};
    }
    return {true,true,0};
  }
};
struct Snapshot {
  bool enabled=kEnabled;
  HistogramSnapshot compose,present,interval,i2cRead,queueAge,sampleToSpi;
  uint32_t pollCount=0,enqueueFailures=0,overflowCancels=0;
};

#if KIBI_UI_DIAGNOSTICS
// Each histogram has one writing task. Atomic buckets allow a diagnostic
// snapshot from the main loop without blocking the touch producer.
class Histogram {
 public:
  void observe(uint32_t durationUs) {
    if(durationUs>kMaximumBucketUs) overflow_.fetch_add(1,std::memory_order_relaxed);
    else buckets_[durationUs?(durationUs-1)/kBucketWidthUs:0].fetch_add(1,std::memory_order_relaxed);
    lastUs_.store(durationUs,std::memory_order_relaxed);
    if(durationUs>maxUs_.load(std::memory_order_relaxed)) maxUs_.store(durationUs,std::memory_order_relaxed);
    count_.fetch_add(1,std::memory_order_release);
  }
  HistogramSnapshot snapshot() const {
    HistogramSnapshot result;
    result.count=count_.load(std::memory_order_acquire);
    for(size_t i=0;i<kBucketCount;++i) result.buckets[i]=buckets_[i].load(std::memory_order_relaxed);
    result.lastUs=lastUs_.load(std::memory_order_relaxed);
    result.maxUs=maxUs_.load(std::memory_order_relaxed);
    result.overflow=overflow_.load(std::memory_order_relaxed);
    return result;
  }
 private:
  std::atomic<uint32_t> buckets_[kBucketCount]{};
  std::atomic<uint32_t> count_{0},lastUs_{0},maxUs_{0},overflow_{0};
};

class Diagnostics {
 public:
  // Main-loop hooks: begin every consumer update, then dequeue all available
  // events. Only the latest sample in that batch can reach one completed SPI
  // presentation. A batch with no redraw cannot leak into a later frame.
  void beginInputBatch() { cancelInput(); }
  void inputDequeued(uint32_t sampleUs,uint32_t nowUs,bool cancelled=false) {
    queueAge_.observe(uint32_t(nowUs-sampleUs));
    if(cancelled) cancelInput();
    else sampledInput(sampleUs);
  }
  void sampledInput(uint32_t sampleUs) { pendingSampleUs_=sampleUs; inputPending_=true; }
  void cancelInput() { inputPending_=false; }
  void frameComposed(uint32_t durationUs) { compose_.observe(durationUs); }
  void framePresented(uint32_t durationUs,uint32_t completedAtUs) {
    present_.observe(durationUs);
    if(presented_) interval_.observe(uint32_t(completedAtUs-lastPresentedUs_));
    lastPresentedUs_=completedAtUs; presented_=true;
    if(inputPending_) {
      sampleToSpi_.observe(uint32_t(completedAtUs-pendingSampleUs_));
      inputPending_=false;
    }
  }
  // Producer hooks: one poll is one complete I2C read attempt, including errors.
  void inputPolled(uint32_t durationUs) { i2cRead_.observe(durationUs); }
  void enqueueFailed() { enqueueFailures_.fetch_add(1,std::memory_order_relaxed); }
  void overflowCancelled() { overflowCancels_.fetch_add(1,std::memory_order_relaxed); }
  Snapshot snapshot() const {
    Snapshot result;
    result.compose=compose_.snapshot(); result.present=present_.snapshot();
    result.interval=interval_.snapshot(); result.i2cRead=i2cRead_.snapshot();
    result.queueAge=queueAge_.snapshot(); result.sampleToSpi=sampleToSpi_.snapshot();
    result.pollCount=result.i2cRead.count;
    result.enqueueFailures=enqueueFailures_.load(std::memory_order_relaxed);
    result.overflowCancels=overflowCancels_.load(std::memory_order_relaxed);
    return result;
  }
 private:
  Histogram compose_,present_,interval_,i2cRead_,queueAge_,sampleToSpi_;
  std::atomic<uint32_t> enqueueFailures_{0},overflowCancels_{0};
  uint32_t pendingSampleUs_=0,lastPresentedUs_=0;
  bool inputPending_=false,presented_=false;
};
static_assert(sizeof(Diagnostics)<=2048,"Opt-in UI diagnostic state must remain bounded");
inline Diagnostics diagnostics;
inline void beginInputBatch() { diagnostics.beginInputBatch(); }
inline void inputDequeued(uint32_t sampleUs,uint32_t nowUs,bool cancelled=false) { diagnostics.inputDequeued(sampleUs,nowUs,cancelled); }
inline void sampledInput(uint32_t sampleUs) { diagnostics.sampledInput(sampleUs); }
inline void cancelInput() { diagnostics.cancelInput(); }
inline void frameComposed(uint32_t durationUs) { diagnostics.frameComposed(durationUs); }
inline void framePresented(uint32_t durationUs,uint32_t completedAtUs) { diagnostics.framePresented(durationUs,completedAtUs); }
inline void inputPolled(uint32_t durationUs) { diagnostics.inputPolled(durationUs); }
inline void enqueueFailed() { diagnostics.enqueueFailed(); }
inline void overflowCancelled() { diagnostics.overflowCancelled(); }
inline Snapshot snapshot() { return diagnostics.snapshot(); }
#else
// No diagnostic runtime, queue timestamp, clock read or counter is allocated in
// the default build. Callers that read clocks guard those reads with the macro.
inline void beginInputBatch() {}
inline void inputDequeued(uint32_t,uint32_t,bool=false) {}
inline void sampledInput(uint32_t) {}
inline void cancelInput() {}
inline void frameComposed(uint32_t) {}
inline void framePresented(uint32_t,uint32_t) {}
inline void inputPolled(uint32_t) {}
inline void enqueueFailed() {}
inline void overflowCancelled() {}
inline Snapshot snapshot() { return {}; }
#endif
} // namespace Tamagotchi::UiDiagnostics
