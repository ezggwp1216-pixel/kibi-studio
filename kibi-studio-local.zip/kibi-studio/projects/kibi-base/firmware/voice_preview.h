#pragma once
#include "fullscreen_page.h"
#include "realtime_voice_protocol.h"

namespace Tamagotchi::VoicePreview {
enum class Kind : uint8_t { Hidden,Transcript,Answer };
// Both instances used by the device live in PSRAM. This is display-only text,
// separate from the final result and every note/reminder persistence buffer.
struct Card {
  Kind kind=Kind::Hidden;
  uint32_t revision=0;
  char title[129]{},text[4097]{};
  bool set(Kind next,const char* heading,const char* body) {
    if((next!=Kind::Transcript && next!=Kind::Answer) || !heading || !body) return false;
    const size_t headingBytes=strnlen(heading,sizeof title);
    const size_t bodyBytes=strnlen(body,32769);
    if(!headingBytes || headingBytes>=sizeof title || !bodyBytes || bodyBytes>32768 ||
       (next==Kind::Answer && bodyBytes>=sizeof text) ||
       !RealtimeVoice::validUtf8(reinterpret_cast<const uint8_t*>(heading),headingBytes) ||
       !RealtimeVoice::validUtf8(reinterpret_cast<const uint8_t*>(body),bodyBytes)) return false;
    bool content=false;
    for(size_t i=0;i<bodyBytes;++i) {
      const auto byte=static_cast<uint8_t>(body[i]);
      if(byte<32 && byte!='\n' && byte!='\r' && byte!='\t') return false;
      content|=byte>32;
    }
    for(size_t i=0;i<headingBytes;++i) if(static_cast<uint8_t>(heading[i])<32) return false;
    if(!content) return false;
    size_t count=bodyBytes<sizeof text?bodyBytes:sizeof text-1;
    while(count && (static_cast<uint8_t>(body[count])&0xc0)==0x80) --count;
    if(kind==next && !strcmp(title,heading) && strlen(text)==count && !memcmp(text,body,count)) return true;
    memcpy(title,heading,headingBytes+1);memcpy(text,body,count);text[count]=0;
    kind=next;++revision;return true;
  }
  void clear() {
    if(kind!=Kind::Hidden) { kind=Kind::Hidden;title[0]=text[0]=0;++revision; }
  }
};
class Presentation {
 public:
  void reset() { active_=false;dismissed_=false; }
  void start() { active_=true;dismissed_=false; }
  // Back belongs to this attempt, including its durable final result. Only
  // reset/start for a new attempt may permit the reader to open again.
  void finish() { active_=false; }
  void dismiss() { dismissed_=true; }
  bool allowFinal() const { return !dismissed_; }
  bool visible(const Card& card) const { return active_ && !dismissed_ && card.kind!=Kind::Hidden; }
 private:
  bool active_=false,dismissed_=false;
};
inline void draw(uint16_t* frame,int width,int height,const Card& card,unsigned phase,bool pressedBack) {
  if(!frame || width<1 || height<1 || card.kind==Kind::Hidden) return;
  PageUi::drawShell(frame,width,height,card.title,pressedBack);
  auto page=PageUi::layout(width,height,card.title);
  const char* label=card.kind==Kind::Transcript?"Preparing reply":"Receiving reply";
  const int dotTop=height-50,labelHeight=Ui::textInkHeight(label,1);
  const int labelInkTop=dotTop-5-labelHeight;
  page.bodyBottom=std::min(page.bodyBottom,labelInkTop-6);
  PageUi::drawBody(frame,width,height,card.text,page);
  Ui::text(frame,width,height,label,Ui::textCenteredX(label,width,1),
      Ui::centeredTextTop(label,labelInkTop,labelHeight,1),1,theme().text,0,dotTop-4);
  for(unsigned i=0;i<3;++i) Ui::box(frame,width,height,width/2-7+int(i)*6,height-50,3,3,1,i==phase%3,0);
}
} // namespace Tamagotchi::VoicePreview
