#pragma once

// Bound-device commands use OpenAI Realtime; menu dictation stays on batch.
// A build flag switches the whole voice route; there is no automatic fallback.
#ifndef KIBI_CLOUD_VOICE_ENABLED
#define KIBI_CLOUD_VOICE_ENABLED 1
#endif
#if KIBI_CLOUD_VOICE_ENABLED != 0 && KIBI_CLOUD_VOICE_ENABLED != 1
#error KIBI_CLOUD_VOICE_ENABLED must be 0 or 1
#endif
#ifndef KIBI_REALTIME_VOICE_ENABLED
#define KIBI_REALTIME_VOICE_ENABLED 1
#endif
#if KIBI_REALTIME_VOICE_ENABLED != 0 && KIBI_REALTIME_VOICE_ENABLED != 1
#error KIBI_REALTIME_VOICE_ENABLED must be 0 or 1
#endif

namespace Tamagotchi::CloudVoice {
inline constexpr bool kEnabled=KIBI_CLOUD_VOICE_ENABLED!=0;
// Three bounded provider attempts can outlive two minutes. This is GET-only;
// the durable device inbox also delivers results after a timeout or reboot.
inline constexpr unsigned long kPollMilliseconds=420000;
}
