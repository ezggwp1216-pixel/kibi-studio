#pragma once
#include "audio_file.h"

namespace Tamagotchi::NoteDeletions {
enum class State { Clear,Deleted,Error };
// Deletion knowledge must outlive the outgoing .del marker and inbox receipts.
// Merge adjacent IDs without ever evicting history. At 4096 disjoint ranges a
// new isolated deletion fails before its note is removed. The snapshot is at
// most 32780 bytes; mutation uses one temporary 32 KiB PSRAM-only buffer on ESP.
// Lookups stream the file with fixed small stack storage and no retained RAM.
constexpr size_t kMaximumRanges=4096;
namespace Detail {
inline bool path(const char* directory,const char* name,char (&out)[128]) {
  if(!directory) return false;
  const int length=snprintf(out,sizeof out,"%s/%s",directory,name);
  return length>0 && size_t(length)<sizeof out;
}
inline uint32_t number(const uint8_t* in) {
  uint32_t value=0; for(int i=0;i<4;++i) value|=uint32_t(in[i])<<(8*i); return value;
}
inline void number(uint8_t* out,uint32_t value) {
  for(int i=0;i<4;++i) out[i]=uint8_t(value>>(8*i));
}
inline uint32_t checksum(uint32_t value,const uint8_t* data,size_t bytes) {
  for(size_t i=0;i<bytes;++i) {
    value^=data[i];
    for(int bit=0;bit<8;++bit) value=(value>>1)^(0xedb88320u & (0u-(value&1)));
  }
  return value;
}
struct Snapshot {
  size_t count=0;
  uint32_t maximum=0;
  bool contains=false,joinable=false;
};
inline bool read(const char* directory,uint32_t id,Snapshot& out,uint8_t* records=nullptr) {
  char filename[128]; if(!path(directory,".deleted",filename)) return false;
  FILE* file=fopen(filename,"rb"); if(!file) return false;
  uint8_t header[8],record[8],footer[4];
  bool ok=fread(header,1,sizeof header,file)==sizeof header && !memcmp(header,"KND1",4);
  const size_t count=ok?number(header+4):0;
  ok=ok && count<=kMaximumRanges;
  uint32_t crc=ok?checksum(~uint32_t(0),header,sizeof header):0,previous=0;
  Snapshot result; result.count=count;
  for(size_t i=0;ok && i<count;++i) {
    ok=fread(record,1,sizeof record,file)==sizeof record;
    if(!ok) break;
    const uint32_t first=number(record),last=number(record+4);
    ok=first && last>=first && (!i || uint64_t(previous)+1<first);
    if(!ok) break;
    previous=last;
    result.contains|=id && id>=first && id<=last;
    result.joinable|=id && uint64_t(id)+1>=first && uint64_t(id)<=uint64_t(last)+1;
    crc=checksum(crc,record,sizeof record);
    if(records) memcpy(records+8*i,record,sizeof record);
  }
  ok=ok && fread(footer,1,sizeof footer,file)==sizeof footer && number(footer)==~crc &&
      fgetc(file)==EOF && !ferror(file);
  const bool closed=fclose(file)==0;
  if(!ok || !closed) return false;
  result.maximum=previous; out=result; return true;
}
inline bool write(const char* directory,const uint8_t* records,size_t count) {
  char filename[128],temporary[128];
  if(count>kMaximumRanges || !path(directory,".deleted",filename) || !path(directory,".deleted.part",temporary)) return false;
  uint8_t header[8],footer[4]; memcpy(header,"KND1",4); number(header+4,uint32_t(count));
  uint32_t crc=checksum(~uint32_t(0),header,sizeof header);
  crc=checksum(crc,records,8*count); number(footer,~crc);
  FILE* file=fopen(temporary,"wb"); if(!file) return false;
  bool ok=fwrite(header,1,sizeof header,file)==sizeof header;
  if(count) ok=(fwrite(records,8,count,file)==count) && ok;
  ok=(fwrite(footer,1,sizeof footer,file)==sizeof footer) && ok;
  ok=(fflush(file)==0) && ok; ok=(fsync(fileno(file))==0) && ok; ok=(fclose(file)==0) && ok;
  if(!ok || rename(temporary,filename)!=0) { remove(temporary); return false; }
  return true;
}
} // namespace Detail

// Called only when opening a NoteStore: allow old installations with no ledger,
// ignore interrupted .part files, and reject corrupt committed history.
inline bool initialize(const char* directory,uint32_t& maximum) {
  char filename[128]; if(!Detail::path(directory,".deleted",filename)) return false;
  struct stat info{};
  if(stat(filename,&info)!=0) {
    if(errno!=ENOENT || !Detail::write(directory,nullptr,0)) return false;
  }
  Detail::Snapshot snapshot;
  if(!Detail::read(directory,0,snapshot)) return false;
  maximum=snapshot.maximum; return true;
}
inline State lookup(const char* directory,uint32_t id) {
  if(!id) return State::Error;
  Detail::Snapshot snapshot;
  if(!Detail::read(directory,id,snapshot)) return State::Error;
  return snapshot.contains?State::Deleted:State::Clear;
}
inline State lookupLegacy(const char* directory,uint32_t id) {
  if(!directory || !id) return State::Error;
  char filename[128];
  const int length=snprintf(filename,sizeof filename,"%s/d%08lx.del",directory,static_cast<unsigned long>(id));
  if(length<=0 || size_t(length)>=sizeof filename) return State::Error;
  struct stat info{};
  if(stat(filename,&info)!=0) return errno==ENOENT?State::Clear:State::Error;
  if(!S_ISREG(info.st_mode)) return State::Error;
  FILE* file=fopen(filename,"rb"); if(!file) return State::Error;
  char value[8];
  const bool ok=fread(value,1,sizeof value,file)==sizeof value && !memcmp(value,"deleted\n",sizeof value) &&
      fgetc(file)==EOF && !ferror(file);
  const bool closed=fclose(file)==0;
  return ok && closed?State::Deleted:State::Error;
}
inline bool canRemember(const char* directory,uint32_t id) {
  if(!id) return false;
  Detail::Snapshot snapshot;
  return Detail::read(directory,id,snapshot) &&
      (snapshot.contains || snapshot.joinable || snapshot.count<kMaximumRanges);
}
inline bool remember(const char* directory,uint32_t id) {
  if(!id) return false;
  Detail::Snapshot snapshot;
  if(!Detail::read(directory,id,snapshot)) return false;
  if(snapshot.contains) return true;
  if(snapshot.count==kMaximumRanges && !snapshot.joinable) return false;
  BoundedText memory;
  if(!memory.reserve(8*kMaximumRanges)) return false;
  auto* records=reinterpret_cast<uint8_t*>(memory.data());
  if(!Detail::read(directory,id,snapshot,records)) return false;
  if(snapshot.contains) return true;
  size_t place=0,count=snapshot.count;
  while(place<count && uint64_t(Detail::number(records+8*place+4))+1<id) ++place;
  if(place<count && uint64_t(id)+1>=Detail::number(records+8*place)) {
    const uint32_t first=Detail::number(records+8*place),last=Detail::number(records+8*place+4);
    Detail::number(records+8*place,id<first?id:first);
    const uint32_t end=id>last?id:last;
    Detail::number(records+8*place+4,end);
    if(place+1<count && uint64_t(end)+1>=Detail::number(records+8*(place+1))) {
      Detail::number(records+8*place+4,Detail::number(records+8*(place+1)+4));
      memmove(records+8*(place+1),records+8*(place+2),8*(count-place-2)); --count;
    }
  } else {
    if(count==kMaximumRanges) return false;
    memmove(records+8*(place+1),records+8*place,8*(count-place));
    Detail::number(records+8*place,id); Detail::number(records+8*place+4,id); ++count;
  }
  return Detail::write(directory,records,count);
}
} // namespace Tamagotchi::NoteDeletions
