#pragma once
#include "realtime_voice_protocol.h"
#include <ArduinoJson.h>

namespace Tamagotchi::RealtimeVoice {
enum class ServerEvent { Ready,Progress,Transcript,Preview,Poll,Final,Fallback,Invalid };
inline bool messageString(JsonVariantConst json,const char* key,size_t capacity,const char*& out) {
  if(!json[key].is<const char*>()) return false;
  const JsonString value=json[key].as<JsonString>();
  out=value.c_str();
  return out && value.size()<capacity && strlen(out)==value.size();
}
inline ServerEvent classifyMessage(JsonVariantConst json,const char* expectedId,bool ready,const SendLedger& ledger) {
  if(!json.is<JsonObjectConst>() || !expectedId) return ServerEvent::Invalid;
  const char *type="",*id="";
  if(!json["type"].isNull() && !messageString(json,"type",24,type)) return ServerEvent::Invalid;
  if(!json["job_id"].isNull() && (!messageString(json,"job_id",33,id) || strcmp(id,expectedId))) return ServerEvent::Invalid;
  if(!strcmp(type,"ready")) return !ready && !strcmp(id,expectedId)?ServerEvent::Ready:ServerEvent::Invalid;
  if(!strcmp(type,"processing")) return ready?ServerEvent::Progress:ServerEvent::Invalid;
  if(!strcmp(type,"transcript")) {
    const char* text;
    return ready && ledger.committed() && !strcmp(id,expectedId) && messageString(json,"text",32769,text) &&
        *text && validUtf8(reinterpret_cast<const uint8_t*>(text),strlen(text))?ServerEvent::Transcript:ServerEvent::Invalid;
  }
  if(!strcmp(type,"preview")) {
    const char *text,*title;
    return ready && ledger.committed() && !strcmp(id,expectedId) && messageString(json,"text",4097,text) &&
        messageString(json,"title",129,title) && *text && *title &&
        validUtf8(reinterpret_cast<const uint8_t*>(text),strlen(text)) &&
        validUtf8(reinterpret_cast<const uint8_t*>(title),strlen(title))?ServerEvent::Preview:ServerEvent::Invalid;
  }
  if(!strcmp(type,"error")) {
    const char* code="";
    if(!messageString(json,"code",64,code) && !messageString(json,"error",64,code)) return ServerEvent::Invalid;
    return !strcmp(code,"realtime_not_configured") && ledger.canFallback()?ServerEvent::Fallback:ServerEvent::Invalid;
  }
  if(*type || strcmp(id,expectedId)) return ServerEvent::Invalid;
  const char* status;
  if(!messageString(json,"status",16,status)) return ServerEvent::Invalid;
  if(!strcmp(status,"queued") || !strcmp(status,"processing") || !strcmp(status,"retry")) return ServerEvent::Poll;
  if(!strcmp(status,"failed")) return ServerEvent::Final;
  if(!strcmp(status,"completed") && (ledger.committed() || (!ready && ledger.canFallback()))) return ServerEvent::Final;
  return ServerEvent::Invalid;
}
} // namespace Tamagotchi::RealtimeVoice
