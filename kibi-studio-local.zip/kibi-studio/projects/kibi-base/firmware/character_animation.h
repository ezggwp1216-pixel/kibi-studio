#pragma once

#include "design.h"
#include "embedded_assets.h"
#include "animation_rules.h"
#include <stdlib.h>
#include <string.h>

#if defined(ARDUINO) || defined(TAMAGOTCHI_ANIMATION_GIF_TEST)
#include <AnimatedGIF.h>
#endif

#ifdef ARDUINO
#include <Arduino.h>
#include <LittleFS.h>
#include <esp_heap_caps.h>
#endif

namespace Tamagotchi {

struct CharacterClipConfig {
  const char* path=nullptr;
  PlaybackRule rule{};
};
inline bool characterRenderAllowed(bool home,bool pointerDown,bool scrolling,int64_t top,int height,int screenHeight) {
  return home && !pointerDown && !scrolling && height>0 && top<screenHeight && top+height>0;
}

class CharacterAnimation {
 public:
  bool update(bool charging, uint32_t now, const uint16_t* durations = nullptr,
              const uint16_t* jumpDurations = nullptr, int poseFrameCount = kCharacterFrameCount,
              int jumpFrameCount = kCharacterFrameCount) {
    if (poseFrameCount <= 0 || (jumpDurations && jumpFrameCount <= 0)) return false;
    const int before = frame_, beforeJump = jumpFrame_;
    if (frame_ >= poseFrameCount) frame_ = poseFrameCount - 1;
    if (jumpFrame_ >= jumpFrameCount) jumpFrame_ = -1;
    const int target = charging ? poseFrameCount - 1 : 0;
    if (!initialized_ || target != target_) {
      lastJumpAt_ = now;
      initialized_ = true;
      target_ = target;
      frameAt_ = now;
    }
    while (frame_ != target_) {
      const uint32_t duration = durations && durations[frame_] ? durations[frame_] : kCharacterFrameDurationMs;
      if (uint32_t(now - frameAt_) < duration) break;
      frameAt_ += duration;
      frame_ += target_ > frame_ ? 1 : -1;
    }
    if (charging || frame_ != 0 || !jumpDurations) {
      jumpFrame_ = -1;
      lastJumpAt_ = now;
    } else if (before != 0) {
      lastJumpAt_ = now;  // Begin a fresh idle interval after standing back up.
    } else {
      if (jumpFrame_ < 0 && uint32_t(now-lastJumpAt_) >= kCharacterJumpIntervalMs) {
        jumpFrame_ = 0;
        jumpAt_ = lastJumpAt_ = now;
      }
      while (jumpFrame_ >= 0) {
        const uint32_t duration = jumpDurations[jumpFrame_] ? jumpDurations[jumpFrame_] : kCharacterFrameDurationMs;
        if (uint32_t(now-jumpAt_) < duration) break;
        jumpAt_ += duration;
        if (++jumpFrame_ == jumpFrameCount) jumpFrame_ = -1;
      }
    }
    return frame_ != before || jumpFrame_ != beforeJump;
  }
  int frameIndex() const { return frame_; }
  int jumpFrameIndex() const { return jumpFrame_; }

 private:
  int frame_ = 0, target_ = 0;
  bool initialized_ = false;
  uint32_t frameAt_ = 0;
  int jumpFrame_ = -1;
  uint32_t jumpAt_ = 0, lastJumpAt_ = 0;
};

// Bit 16 marks an opaque RGB565 pixel, preserving true black independently
// from transparency. Only the currently displayed frame lives in PSRAM.
inline bool copyCharacterLine(uint32_t* frame, int x, int y, int count,
                              const uint8_t* indices, const uint16_t* palette, int transparent,
                              int width = kCharacterWidth, int height = kCharacterHeight,
                              size_t paletteCount = 256) {
  if (!frame || !indices || !palette || width <= 0 || height <= 0 || width > 256 || height > 256 ||
      !paletteCount || paletteCount > 256 || x < 0 || y < 0 || y >= height || count < 0 || x > width - count) return false;
  uint32_t* output = frame + size_t(y) * width + x;
  for (int i = 0; i < count; ++i) {
    if (indices[i] >= paletteCount) return false;
    output[i] = indices[i] == transparent ? 0 : (0x10000u | palette[indices[i]]);
  }
  return true;
}

// Measure once from the approved pose, then reuse for all motion frames. The
// opacity marker includes true black and ignores transparent palette colors.
inline int characterContentOffsetX(const uint32_t* sprite,int width,int height) {
  if(!sprite || width<=0 || height<=0 || width>256 || height>256) return 0;
  int left=width,right=-1;
  for(int y=0;y<height;++y) for(int x=0;x<width;++x) {
    if(!(sprite[size_t(y)*width+x]&0x10000u)) continue;
    if(x<left) left=x;
    if(x>right) right=x;
  }
  return right<left?0:(width-(right-left+1))/2-left;
}

inline void drawCharacter(uint16_t* frame, int width, int height, const uint32_t* sprite, int offsetY,
                          int spriteWidth = kCharacterWidth, int spriteHeight = kCharacterHeight,
                          int anchorX = kCharacterX, int anchorY = kCharacterY) {
  if (!frame || !sprite || width <= 0 || height <= 0 || spriteWidth <= 0 || spriteHeight <= 0) return;
  const int64_t worldTop = int64_t(anchorY) - offsetY;
  if (worldTop >= height || worldTop + spriteHeight <= 0 || anchorX >= width ||
      int64_t(anchorX) + spriteWidth <= 0) return;
  const int top = int(worldTop);
  const int firstY = top < 0 ? 0 : top;
  const int lastY = int(worldTop + spriteHeight < height ? worldTop + spriteHeight : height);
  const int firstX = anchorX < 0 ? 0 : anchorX;
  const int lastX = int(int64_t(anchorX) + spriteWidth < width ? int64_t(anchorX) + spriteWidth : width);
  for (int y = firstY; y < lastY; ++y) {
    const uint32_t* source = sprite + size_t(y - top) * spriteWidth;
    for (int x = firstX; x < lastX; ++x) {
      const uint32_t pixel = source[x - anchorX];
      if (pixel & 0x10000u) frame[size_t(y) * width + x] = uint16_t(pixel);
    }
  }
}

// AGF1 is a small seek directory around unmodified, independent GIF frames.
// Metadata is read on demand, so adding stored clips does not grow the pixel cache.
namespace CharacterDetail {
constexpr size_t kPackedHeaderBytes = 40, kPackedEntryBytes = 16;
constexpr uint16_t kMaxAnimationDimension = 256;
constexpr uint16_t kMaxPlaybackFrames = 256;
constexpr uint32_t kMaxEncodedFrameBytes = 512 * 1024;
using ReadAt = bool (*)(void*, uint32_t, uint8_t*, size_t);

inline uint16_t read16(const uint8_t* bytes) {
  return uint16_t(bytes[0]) | uint16_t(bytes[1]) << 8;
}
inline uint32_t read32(const uint8_t* bytes) {
  return uint32_t(read16(bytes)) | uint32_t(read16(bytes + 2)) << 16;
}
inline uint32_t crc32(const uint8_t* bytes, size_t size) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t i = 0; i < size; ++i) {
    crc ^= bytes[i];
    for (int bit = 0; bit < 8; ++bit) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
  }
  return ~crc;
}

struct AnimationMetadata {
  uint16_t width = 0, height = 0, frameCount = 0;
  int16_t anchorX = 0, anchorY = 0;
  uint8_t mode = 0;  // 0 endpoint holds, 1 repeat, 2 once; App chooses the role.
  char identifier[16]{};
};
struct PackedFrame {
  uint32_t offset = 0, size = 0, crc = 0;
  uint16_t duration = 0;
};

class PackedAnimation {
 public:
  AnimationMetadata metadata;
  uint32_t maxFrameBytes = 0;

  void close() { *this = PackedAnimation{}; }
  bool open(ReadAt reader, void* context, size_t length) {
    close();
    uint8_t header[kPackedHeaderBytes];
    if (!reader || length < sizeof(header) || length > UINT32_MAX ||
        !reader(context, 0, header, sizeof(header)) || memcmp(header, "AGF1", 4) ||
        read32(header + 36) != length || read16(header + 10) != 1 || header[16] > 2 ||
        header[17] || header[18] || header[19] || !header[20] || !memchr(header + 20, 0, 16)) return false;
    metadata.width = read16(header + 4);
    metadata.height = read16(header + 6);
    metadata.frameCount = read16(header + 8);
    metadata.anchorX = int16_t(read16(header + 12));
    metadata.anchorY = int16_t(read16(header + 14));
    metadata.mode = header[16];
    memcpy(metadata.identifier, header + 20, 16);
    bool ended = false;
    for (char c : metadata.identifier) {
      if (!c) ended = true;
      else if (ended || uint8_t(c) < 32 || uint8_t(c) > 126) { close(); return false; }
    }
    const uint32_t directoryEnd = kPackedHeaderBytes + uint32_t(metadata.frameCount) * kPackedEntryBytes;
    if (!metadata.width || metadata.width > kMaxAnimationDimension || !metadata.height ||
        metadata.height > kMaxAnimationDimension || !metadata.frameCount || directoryEnd > length) {
      close(); return false;
    }
    reader_ = reader;
    context_ = context;
    length_ = uint32_t(length);
    uint32_t position = directoryEnd;
    for (uint32_t index = 0; index < metadata.frameCount; ++index) {
      PackedFrame frame;
      if (!entry(int(index), frame) || frame.offset != position) { close(); return false; }
      position += frame.size;  // entry() already proved size <= length - offset.
      if (frame.size > maxFrameBytes) maxFrameBytes = frame.size;
    }
    if (position != length_) { close(); return false; }
    return true;
  }

  bool entry(int index, PackedFrame& frame) const {
    uint8_t bytes[kPackedEntryBytes];
    if (!reader_ || index < 0 || index >= metadata.frameCount ||
        !reader_(context_, kPackedHeaderBytes + uint32_t(index) * kPackedEntryBytes, bytes, sizeof(bytes))) return false;
    frame.offset = read32(bytes);
    frame.size = read32(bytes + 4);
    frame.duration = read16(bytes + 8);
    frame.crc = read32(bytes + 12);
    return !read16(bytes + 10) && frame.duration && frame.duration <= 60000 && frame.size &&
        frame.size <= kMaxEncodedFrameBytes && frame.offset <= length_ && frame.size <= length_ - frame.offset;
  }

  bool readFrame(int index, uint8_t* output, size_t capacity, PackedFrame& frame) const {
    return output && entry(index, frame) && frame.size <= capacity &&
        reader_(context_, frame.offset, output, frame.size) && crc32(output, frame.size) == frame.crc;
  }

 private:
  ReadAt reader_ = nullptr;
  void* context_ = nullptr;
  uint32_t length_ = 0;
};

struct AnimationBuffers {
  uint32_t* pixels = nullptr;
  uint8_t* input = nullptr;
  size_t pixelCapacity = 0, inputCapacity = 0;
  void (*release)(void*) = nullptr;

  void clear() {
    if (release) { release(pixels); release(input); }
    pixels = nullptr;
    input = nullptr;
    pixelCapacity = inputCapacity = 0;
    release = nullptr;
  }
  bool reserve(size_t pixelCount, size_t inputBytes, void* (*allocate)(size_t), void (*deallocate)(void*)) {
    clear();
    if (!allocate || !deallocate || !pixelCount || pixelCount > size_t(kMaxAnimationDimension) * kMaxAnimationDimension ||
        !inputBytes || inputBytes > kMaxEncodedFrameBytes) return false;
    release = deallocate;
    pixels = static_cast<uint32_t*>(allocate(pixelCount * sizeof(uint32_t)));
    if (pixels) input = static_cast<uint8_t*>(allocate(inputBytes));
    if (!pixels || !input) { clear(); return false; }
    pixelCapacity = pixelCount;
    inputCapacity = inputBytes;
    return true;
  }
};

#if defined(ARDUINO) || defined(TAMAGOTCHI_ANIMATION_GIF_TEST)
// Strictly check a standalone full-frame GIF before passing it to AnimatedGIF.
// This also prevents a corrupted descriptor/palette/block length reaching its parser.
inline bool validFrameGif(const uint8_t* bytes, size_t size, const AnimationMetadata& metadata,
                          uint16_t duration, uint16_t& paletteCount) {
  if (!bytes || size < 14 || (memcmp(bytes, "GIF89a", 6) && memcmp(bytes, "GIF87a", 6)) ||
      read16(bytes + 6) != metadata.width || read16(bytes + 8) != metadata.height || !(bytes[10] & 128)) return false;
  paletteCount = uint16_t(2u << (bytes[10] & 7));
  size_t position = 13 + size_t(paletteCount) * 3;
  if (position > size || size - position < 19 || bytes[position] != 0x21 || bytes[position + 1] != 0xF9 ||
      bytes[position + 2] != 4 || bytes[position + 7] || ((bytes[position + 3] >> 2) & 7) != 2 ||
      ((bytes[position + 3] & 1) && bytes[position + 6] >= paletteCount)) return false;
  const uint32_t gifDuration = uint32_t(read16(bytes + position + 4)) * 10;
  if ((gifDuration ? gifDuration : kCharacterFrameDurationMs) != duration) return false;
  position += 8;
  if (bytes[position] != 0x2C || read16(bytes + position + 1) || read16(bytes + position + 3) ||
      read16(bytes + position + 5) != metadata.width || read16(bytes + position + 7) != metadata.height ||
      (bytes[position + 9] & ~0x40u) || bytes[position + 10] < 2 || bytes[position + 10] > 8) return false;
  position += 11;
  while (position < size) {
    const size_t count = bytes[position++];
    if (!count) return position + 1 == size && bytes[position] == 0x3B;
    if (count > size - position) return false;
    position += count;
  }
  return false;
}

struct DecodeTarget {
  uint32_t* pixels;
  uint16_t width, height, paletteCount;
  uint8_t rows[kMaxAnimationDimension / 8]{};
  int rowCount = 0;
  bool valid = true;
};

inline void receiveGifLine(GIFDRAW* line) {
  auto* target = line ? static_cast<DecodeTarget*>(line->pUser) : nullptr;
  if (!target) return;
  if (!line->pPixels || !line->pPalette || line->iX || line->iY || line->iWidth != target->width ||
      line->iHeight != target->height || line->ucDisposalMethod != 2 || line->y < 0 || line->y >= target->height ||
      (target->rows[line->y / 8] & (1u << (line->y % 8)))) { target->valid = false; return; }
  target->rows[line->y / 8] |= uint8_t(1u << (line->y % 8));
  target->valid &= copyCharacterLine(target->pixels, 0, line->y, line->iWidth, line->pPixels, line->pPalette,
      line->ucHasTransparency ? line->ucTransparent : -1, target->width, target->height, target->paletteCount);
  ++target->rowCount;
}

inline bool decodeFrame(const PackedAnimation& clip, int index, AnimatedGIF& decoder, AnimationBuffers& buffers) {
  const auto& metadata = clip.metadata;
  const size_t pixels = size_t(metadata.width) * metadata.height;
  PackedFrame frame;
  uint16_t paletteCount = 0;
  if (!buffers.pixels || !pixels || pixels > buffers.pixelCapacity ||
      !clip.readFrame(index, buffers.input, buffers.inputCapacity, frame) ||
      !validFrameGif(buffers.input, frame.size, metadata, frame.duration, paletteCount)) return false;
  decoder.begin(GIF_PALETTE_RGB565_LE);
  if (!decoder.open(buffers.input, int(frame.size), receiveGifLine)) { decoder.close(); return false; }
  DecodeTarget target{buffers.pixels, metadata.width, metadata.height, paletteCount};
  int duration = 0;
  const int result = decoder.playFrame(false, &duration, &target);
  const bool valid = result >= 0 && decoder.getLastError() == GIF_SUCCESS && target.valid &&
      target.rowCount == metadata.height && (duration ? duration : int(kCharacterFrameDurationMs)) == frame.duration;
  decoder.close();
  return valid;
}
#endif

#ifdef ARDUINO
constexpr int kExtraClipCount=7,kHeroClipIndex=7,kRecordClipIndex=8;
constexpr size_t kClipFileBufferBytes=512;
struct DesignClip {
  File file;
  PackedAnimation clip;
  uint16_t durations[kMaxPlaybackFrames]{};
  char path[128]{};
  PlaybackRule rule{};
  bool available=false;
  void close() { file.close(); clip.close(); path[0]=0; rule=PlaybackRule{}; available=false; }
};
struct Runtime {
  File chargeFile, jumpFile;
  PackedAnimation charge, jump;
  AnimationBuffers buffers;
  uint16_t durations[kMaxPlaybackFrames]{}, jumpDurations[kMaxPlaybackFrames]{};
  CharacterAnimation animation;
  VoiceRecordingPose voice;
  int decodedFrame = -1,horizontalCorrection=0;
  bool decodedJump = false, visible = false, jumpAvailable = false;
  DesignClip extra[kExtraClipCount],hero,record;
  AnimationRules rules;
  bool dynamicDesign=false,chargeEnabled=true;
  int extraCount=0,decodedClip=-1;
};
inline Runtime runtime;
// AnimatedGIF's internal tables stay off the small Arduino loop stack.
inline AnimatedGIF decoder;

inline bool readFile(void* context, uint32_t offset, uint8_t* output, size_t count) {
  auto& file = *static_cast<File*>(context);
  return file && offset <= file.size() && count <= file.size() - offset && file.seek(offset) &&
      file.read(output, count) == count;
}
inline bool openClip(const char* path, File& file, PackedAnimation& clip, uint16_t* durations, uint8_t expectedMode) {
  if (!path || !*path) return false;
  file = LittleFS.open(path, FILE_READ);
  bool opened=false;
  if(file && file.setBufferSize(kClipFileBufferBytes) && !file.isDirectory())
    opened=clip.open(readFile,&file,file.size());
  if(!opened) {
    file.close();clip.close();
    auto* fallback=KibiAssets::lookup(path);
    if(fallback) opened=clip.open(KibiAssets::read,fallback,fallback->size);
  }
  if(!opened || clip.metadata.frameCount>kMaxPlaybackFrames || clip.metadata.mode!=expectedMode) {
    clip.close();file.close();return false;
  }
  for (int i = 0; i < clip.metadata.frameCount; ++i) {
    PackedFrame frame;
    if (!clip.entry(i, frame)) { clip.close(); file.close(); return false; }
    durations[i] = frame.duration;
  }
  return true;
}
inline void* allocatePsram(size_t size) {
  return heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
}
#endif
}  // namespace CharacterDetail

#ifdef ARDUINO
inline void unloadCharacter() {
  using namespace CharacterDetail;
  runtime.buffers.clear();
  runtime.chargeFile.close(); runtime.jumpFile.close();
  runtime.charge.close(); runtime.jump.close();
  for(auto& clip:runtime.extra) clip.close();
  runtime.hero.close();runtime.record.close(); runtime.rules.configure(nullptr,0,0);
  runtime.dynamicDesign=false; runtime.chargeEnabled=true; runtime.extraCount=0; runtime.decodedClip=-1;
  runtime.animation = CharacterAnimation{};
  runtime.voice = VoiceRecordingPose{};
  runtime.decodedFrame = -1;
  // Bundled artwork retains its original layout; custom designs set this once
  // from their approved hero after successful activation.
  runtime.horizontalCorrection=0;
  runtime.decodedJump = runtime.visible = runtime.jumpAvailable = false;
}

inline bool loadCharacter(const char* chargePath = kCharacterPath, const char* jumpPath = kCharacterJumpPath) {
  using namespace CharacterDetail;
  unloadCharacter();
  if (!openClip(chargePath, runtime.chargeFile, runtime.charge, runtime.durations, 0)) {
    Serial.printf("[ERROR] Missing/invalid character animation: %s\n", chargePath ? chargePath : "(null)");
    return false;
  }
  runtime.jumpAvailable = openClip(jumpPath, runtime.jumpFile, runtime.jump, runtime.jumpDurations, 2);
  if (runtime.jumpAvailable && (runtime.jump.metadata.width != runtime.charge.metadata.width ||
      runtime.jump.metadata.height != runtime.charge.metadata.height ||
      runtime.jump.metadata.anchorX != runtime.charge.metadata.anchorX ||
      runtime.jump.metadata.anchorY != runtime.charge.metadata.anchorY)) {
    runtime.jumpAvailable = false;
    runtime.jump.close(); runtime.jumpFile.close();
  }
  const size_t inputBytes = runtime.jumpAvailable && runtime.jump.maxFrameBytes > runtime.charge.maxFrameBytes ?
      runtime.jump.maxFrameBytes : runtime.charge.maxFrameBytes;
  const size_t pixelCount = size_t(runtime.charge.metadata.width) * runtime.charge.metadata.height;
  if (!runtime.buffers.reserve(pixelCount, inputBytes, allocatePsram, free) ||
      !decodeFrame(runtime.charge, 0, decoder, runtime.buffers)) {
    Serial.println("[ERROR] Character allocation/decoding failed");
    unloadCharacter();
    return false;
  }
  runtime.decodedFrame = 0;
  runtime.visible = true;
  Serial.printf("[CHARACTER] Current-frame PSRAM=%u bytes; jump=%s\n",
      unsigned(pixelCount * sizeof(uint32_t) + inputBytes), runtime.jumpAvailable ? "ready" : "unavailable");
  return true;
}

// Downloaded designs retain copied paths and small metadata. Every clip shares
// one pair of buffers sized once to the largest canvas and encoded frame.
inline bool loadCharacterDesign(const char* chargePath,bool chargeEnabled,
                                const CharacterClipConfig* clips,int count,
                                const char* heroPath,uint32_t now,const char* recordPath=nullptr) {
  using namespace CharacterDetail;
  unloadCharacter();
  if(count<0 || count>kExtraClipCount || (count && !clips) ||
     !openClip(chargePath,runtime.chargeFile,runtime.charge,runtime.durations,0)) return false;
  runtime.dynamicDesign=true; runtime.chargeEnabled=chargeEnabled; runtime.extraCount=count;
  size_t pixels=size_t(runtime.charge.metadata.width)*runtime.charge.metadata.height;
  size_t input=runtime.charge.maxFrameBytes;
  auto include=[&](DesignClip& slot) {
    const size_t size=size_t(slot.clip.metadata.width)*slot.clip.metadata.height;
    if(size>pixels) pixels=size;
    if(slot.clip.maxFrameBytes>input) input=slot.clip.maxFrameBytes;
  };
  for(int i=0;i<count;++i) {
    auto& slot=runtime.extra[i]; slot.rule=clips[i].rule;
    const char* path=clips[i].path;
    if(!slot.rule.enabled || !path || strnlen(path,sizeof slot.path)>=sizeof slot.path ||
       slot.rule.trigger>3 || !slot.rule.intervalSeconds || slot.rule.intervalSeconds>86400) { slot.rule.enabled=false; continue; }
    strcpy(slot.path,path);
    slot.available=openClip(slot.path,slot.file,slot.clip,slot.durations,slot.rule.repeat?1:2);
    if(!slot.available) { slot.rule.enabled=false; continue; }
    slot.rule.duration=0;
    for(int frame=0;frame<slot.clip.metadata.frameCount;++frame) slot.rule.duration+=slot.durations[frame];
    include(slot);
  }
  auto& hero=runtime.hero;
  if(heroPath && *heroPath && strnlen(heroPath,sizeof hero.path)<sizeof hero.path) {
    strcpy(hero.path,heroPath);
    hero.available=openClip(hero.path,hero.file,hero.clip,hero.durations,1);
    if(hero.available && hero.clip.metadata.frameCount!=1) { hero.close(); }
    if(hero.available) include(hero);
  }
  auto& record=runtime.record;
  if(recordPath && *recordPath) {
    if(strnlen(recordPath,sizeof record.path)>=sizeof record.path) { unloadCharacter();return false; }
    strcpy(record.path,recordPath);
    record.available=openClip(record.path,record.file,record.clip,record.durations,0);
    if(!record.available) { unloadCharacter();return false; }
    include(record);
  }
  if(!runtime.buffers.reserve(pixels,input,allocatePsram,free)) { unloadCharacter(); return false; }
  // Validate all frames during activation. A broken required clip rejects the
  // design so the caller can reload its last known-good manifest immediately.
  for(int frame=0;frame<runtime.charge.metadata.frameCount;++frame) {
    if(!decodeFrame(runtime.charge,frame,decoder,runtime.buffers)) { unloadCharacter(); return false; }
  }
  if(record.available) for(int frame=0;frame<record.clip.metadata.frameCount;++frame) {
    if(!decodeFrame(record.clip,frame,decoder,runtime.buffers)) { unloadCharacter();return false; }
  }
  PlaybackRule rules[kExtraClipCount]{};
  for(int i=0;i<count;++i) {
    auto& slot=runtime.extra[i];
    if(slot.available) for(int frame=0;frame<slot.clip.metadata.frameCount;++frame) {
      if(!decodeFrame(slot.clip,frame,decoder,runtime.buffers)) { slot.close(); break; }
    }
    rules[i]=slot.rule; rules[i].enabled=slot.available && slot.rule.enabled;
  }
  if(hero.available && !decodeFrame(hero.clip,0,decoder,runtime.buffers)) hero.close();
  runtime.rules.configure(rules,count,now);
  runtime.decodedClip=hero.available?kHeroClipIndex:-1;
  if(!decodeFrame(hero.available?hero.clip:runtime.charge,0,decoder,runtime.buffers)) { unloadCharacter(); return false; }
  const auto& baseline=hero.available?hero.clip.metadata:runtime.charge.metadata;
  runtime.horizontalCorrection=characterContentOffsetX(runtime.buffers.pixels,baseline.width,baseline.height);
  runtime.decodedFrame=0; runtime.visible=true;
  return true;
}

inline int characterHorizontalCorrection() { return CharacterDetail::runtime.horizontalCorrection; }
inline const uint32_t* characterPixels() {
  return CharacterDetail::runtime.visible ? CharacterDetail::runtime.buffers.pixels : nullptr;
}
inline bool characterReady() { return characterPixels() != nullptr; }
inline bool characterVoiceActive() { return CharacterDetail::runtime.voice.frameIndex()>=0; }
inline const CharacterDetail::AnimationMetadata& characterMetadata() {
  const auto& runtime = CharacterDetail::runtime;
  if(runtime.dynamicDesign) {
    if(runtime.decodedClip==CharacterDetail::kHeroClipIndex) return runtime.hero.clip.metadata;
    if(runtime.decodedClip==CharacterDetail::kRecordClipIndex) return runtime.record.clip.metadata;
    if(runtime.decodedClip>=0 && runtime.decodedClip<runtime.extraCount) return runtime.extra[runtime.decodedClip].clip.metadata;
  }
  return runtime.decodedJump ? runtime.jump.metadata : runtime.charge.metadata;
}

inline bool updateCharacter(bool charging, uint32_t now, bool visible = true,int hour=-1,int minute=-1,
                            bool voiceRecording=false,bool voiceBusy=false) {
  using namespace CharacterDetail;
  if (!runtime.buffers.pixels) return false;
  // A downloaded custom hero must never borrow an unrelated bundled reaction
  // when its charge role was removed. The legacy design owns its bundled clip.
  const bool ownRecord=runtime.dynamicDesign && runtime.record.available;
  const bool voiceAvailable=ownRecord || !runtime.dynamicDesign || runtime.chargeEnabled;
  const bool voiceWasPlaying=runtime.voice.frameIndex()>=0;
  const bool voiceChanged=runtime.voice.update(voiceRecording && voiceAvailable,now,
      ownRecord?runtime.record.durations:runtime.durations,
      ownRecord?runtime.record.clip.metadata.frameCount:runtime.charge.metadata.frameCount);
  const bool voicePlaying=runtime.voice.frameIndex()>=0;
  // The final handoff resets timed extras too, so a completed return cannot
  // immediately launch an animation whose interval elapsed underneath it.
  const bool suppressExtras=voiceRecording || voiceBusy || voicePlaying || voiceWasPlaying;
  if(runtime.dynamicDesign) {
    const bool changed=runtime.animation.update(runtime.chargeEnabled && charging,now,runtime.durations,nullptr,runtime.charge.metadata.frameCount) || voiceChanged;
    const bool chargeOwns=runtime.chargeEnabled && (charging || runtime.animation.frameIndex()!=0);
    const int active=runtime.rules.update(now,suppressExtras || chargeOwns || charging,hour,minute,
        suppressExtras || runtime.chargeEnabled);
    // Timers progress under overlays, but hidden playback never touches files.
    if(!visible) return false;
    int selected=voicePlaying?(ownRecord?kRecordClipIndex:-1):(chargeOwns?-1:(active>=0?active:(runtime.hero.available?kHeroClipIndex:-1)));
    int frame=runtime.animation.frameIndex();
    if(voicePlaying) frame=runtime.voice.frameIndex();
    else if(selected==kHeroClipIndex) frame=0;
    else if(selected>=0) frame=playbackFrame(runtime.extra[selected].durations,
        runtime.extra[selected].clip.metadata.frameCount,runtime.rules.startedAt(),now,runtime.extra[selected].rule.repeat);
    if(runtime.visible && selected==runtime.decodedClip && frame==runtime.decodedFrame) return changed;
    const PackedAnimation& clip=selected<0?runtime.charge:(selected==kHeroClipIndex?runtime.hero.clip:
        (selected==kRecordClipIndex?runtime.record.clip:runtime.extra[selected].clip));
    if(!decodeFrame(clip,frame,decoder,runtime.buffers)) {
      if(selected<0) { unloadCharacter(); return true; }
      if(selected==kHeroClipIndex) runtime.hero.close();
      else if(selected==kRecordClipIndex) { runtime.record.close();runtime.voice=VoiceRecordingPose{}; }
      else {
        runtime.extra[selected].close();
        PlaybackRule rules[kExtraClipCount]{};
        for(int i=0;i<runtime.extraCount;++i) { rules[i]=runtime.extra[i].rule; rules[i].enabled=runtime.extra[i].available && rules[i].enabled; }
        runtime.rules.configure(rules,runtime.extraCount,now);
      }
      selected=chargeOwns?-1:(runtime.hero.available?kHeroClipIndex:-1);
      frame=selected<0?runtime.animation.frameIndex():0;
      if(!decodeFrame(selected<0?runtime.charge:runtime.hero.clip,frame,decoder,runtime.buffers)) { unloadCharacter(); return true; }
    }
    runtime.decodedFrame=frame; runtime.decodedClip=selected; runtime.decodedJump=false; runtime.visible=true;
    return true;
  }
  const bool changed = runtime.animation.update(charging, now, runtime.durations,
      runtime.jumpAvailable && !suppressExtras ? runtime.jumpDurations : nullptr,
      runtime.charge.metadata.frameCount, runtime.jump.metadata.frameCount) || voiceChanged;
  // Overlays hide the character while its timers and charge transitions continue.
  // Returning to the scene decodes just the frame selected by the current state.
  if (!visible) return false;
  const bool jump = !voicePlaying && runtime.animation.jumpFrameIndex() >= 0;
  const int frame = voicePlaying ? runtime.voice.frameIndex() :
      (jump ? runtime.animation.jumpFrameIndex() : runtime.animation.frameIndex());
  if (runtime.visible && frame == runtime.decodedFrame && jump == runtime.decodedJump) return changed;
  if (decodeFrame(jump ? runtime.jump : runtime.charge, frame, decoder, runtime.buffers)) {
    runtime.decodedFrame = frame;
    runtime.decodedJump = jump;
    runtime.visible = true;
    return true;
  }
  // Failed optional jump falls back to the current charge pose. Failed required
  // animation releases resources and leaves the independently drawn scene usable.
  Serial.println("[ERROR] Invalid animation frame; using available fallback");
  if (jump) {
    runtime.jumpAvailable = false;
    runtime.jump.close(); runtime.jumpFile.close();
    runtime.animation.update(charging, now, runtime.durations, nullptr, runtime.charge.metadata.frameCount);
    if (decodeFrame(runtime.charge, runtime.animation.frameIndex(), decoder, runtime.buffers)) {
      runtime.decodedFrame = runtime.animation.frameIndex();
      runtime.decodedJump = false;
      runtime.visible = true;
      return true;
    }
  }
  unloadCharacter();
  return true;
}
#endif

}  // namespace Tamagotchi
