#pragma once
#include <cstddef>

namespace Tamagotchi::RecordingStorage {
struct Space { size_t total=0,used=0; };
inline bool valid(Space space) { return space.total && space.used<=space.total; }
inline bool fits(Space space,size_t required) {
  return valid(space) && required && required<=space.total-space.used;
}

// Worker-only preparation. Never discard rollback assets when the selected
// recording already fits; recheck real filesystem space after any reclamation.
template<class ClosePart,class Inspect,class Reclaim>
bool prepare(size_t required,ClosePart closePart,Inspect inspect,Reclaim reclaim) {
  if(!required || !closePart()) return false;
  const auto space=inspect();
  if(!valid(space)) return false;
  if(fits(space,required)) return true;
  return reclaim() && fits(inspect(),required);
}
} // namespace Tamagotchi::RecordingStorage
