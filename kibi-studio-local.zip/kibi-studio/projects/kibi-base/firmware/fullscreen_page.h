#pragma once

#include "menu.h"

namespace Tamagotchi::PageUi {

// Shared geometry for menu pages and readers. Only the body scrolls; title and
// Back remain anchored to the physical display.
struct Layout {
  int titleTop,bodyTop,bodyBottom,backLeft,backTop;
  static constexpr int backWidth=100,backHeight=32,backRadius=10;
  static constexpr int textLeft=12,textColumns=18,lineHeight=18,textScale=2,sectionGap=8;
};
inline int titleColumns(int width,int height) {
  int radius=kScreenCornerRadius;
  if(radius>width/2) radius=width/2;
  if(radius>height/2) radius=height/2;
  int inset=0;
  const int top=theme().statusTop;
  if(top<radius) {
    const int dy=2*top+1-2*radius;
    while(inset<radius) {
      const int dx=2*inset+1-2*radius;
      if(dx*dx+dy*dy<=4*radius*radius) break;
      ++inset;
    }
  }
  const int columns=(width-2*(inset+4)+Layout::textScale)/(6*Layout::textScale);
  return columns>15?15:(columns>0?columns:1);
}
inline Layout layout(int width,int height,const char* title="") {
  const int lines=title?Ui::textLineCount(title,titleColumns(width,height)):0;
  const int visibleLines=lines>2?2:(lines>0?lines:1);
  return {theme().statusTop,theme().statusTop+visibleLines*Ui::textLineHeight(title,Layout::lineHeight,Layout::textScale)+12,
      height-56,(width-Layout::backWidth)/2,height-44};
}
inline bool backHit(int x,int y,int width,int height) {
  const auto page=layout(width,height);
  return width>0 && height>0 && Ui::roundedPixel(x-page.backLeft,y-page.backTop,
      page.backWidth,page.backHeight,page.backRadius);
}
inline int scrollLimit(int contentHeight,const Layout& page) {
  const int viewport=page.bodyBottom>page.bodyTop?page.bodyBottom-page.bodyTop:0;
  return contentHeight>viewport?contentHeight-viewport:0;
}
inline int scrollLimit(const char* text,const Layout& page) {
  return scrollLimit(text?Ui::textLineCount(text,Layout::textColumns)*Ui::textLineHeight(text,Layout::lineHeight,Layout::textScale):0,page);
}
inline int boundedOffset(int offset,int limit) { return offset<0?0:(offset>limit?limit:offset); }

inline void drawShell(uint16_t* frame,int width,int height,const char* title,bool pressedBack=false) {
  if(!frame || width<1 || height<1) return;
  const auto page=layout(width,height,title);
  const Ui::Blend565 wash(theme().card,210);
  Ui::blendPixels(frame,size_t(width)*height,wash);
  if(title) Ui::wrappedText(frame,width,height,title,page.textLeft,page.titleTop-Ui::textInkTop(title),
      titleColumns(width,height),page.lineHeight,page.textScale,0,page.bodyTop-12,2,true);
  Ui::box(frame,width,height,page.backLeft,page.backTop,page.backWidth,page.backHeight,
      page.backRadius,pressedBack,0);
  Ui::wrappedText(frame,width,height,"Back",page.textLeft,Ui::centeredTextTop("Back",page.backTop,page.backHeight),
      page.textColumns,page.lineHeight,page.textScale,page.backTop,
      page.backTop+page.backHeight,1,true);
}
inline void drawBody(uint16_t* frame,int width,int height,const char* text,const Layout& page,int offset=0) {
  if(!frame || !text || width<1 || height<1 || page.bodyBottom<=page.bodyTop) return;
  offset=boundedOffset(offset,scrollLimit(text,page));
  Ui::wrappedText(frame,width,height,text,page.textLeft,page.bodyTop-offset,
      page.textColumns,page.lineHeight,page.textScale,page.bodyTop,page.bodyBottom,0x7fffffff);
}
inline void drawScrollIndicator(uint16_t* frame,int width,int height,const Layout& page,int offset,int contentHeight) {
  if(!frame || width<1 || height<1 || page.bodyBottom<=page.bodyTop) return;
  const int limit=scrollLimit(contentHeight,page);
  if(limit<1) return;
  const int track=page.bodyBottom-page.bodyTop;
  const int calculated=int(int64_t(track)*track/(track+limit));
  const int thumb=calculated>12?calculated:(track<12?track:12);
  const int top=page.bodyTop+int(int64_t(boundedOffset(offset,limit))*(track-thumb)/limit);
  for(int y=top;y<top+thumb;++y) for(int x=width-12;x<width-9;++x)
    Ui::pixel(frame,width,height,x,y,0xC63F);
}
} // namespace Tamagotchi::PageUi
