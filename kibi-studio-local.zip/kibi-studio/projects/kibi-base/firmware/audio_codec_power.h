#pragma once
#include <cstddef>
#include <cstdint>

namespace Tamagotchi::MicrophonePower {
inline constexpr uint32_t kReadyBudgetMs=600,kClockPrerollMs=80;
enum class WakeStatus : uint8_t { Ready,Cancelled,TimedOut,DriverError,CodecError };
enum class DacStatus : uint8_t { Absent,Suspended,WriteError };
struct Register { uint8_t address,value; };

// Preserve the DS02's working stereo initialization, bias and 30 dB gain.
inline constexpr Register kInitializeAdc[]={
  {0x00,0xFF},{0x00,0x41},{0x01,0x3F},{0x09,0x30},{0x0A,0x30},{0x23,0x2A},
  {0x22,0x0A},{0x20,0x0A},{0x21,0x2A},{0x08,0x10},{0x40,0x43},{0x41,0x70},
  {0x42,0x70},{0x07,0x20},{0x02,0xC1},{0x11,0x60},{0x12,0x00},{0x01,0x34},
  {0x06,0x00},{0x47,0x08},{0x48,0x08},{0x4B,0x00},{0x4C,0xFF},{0x43,0x1A},
  {0x44,0x1A},{0x40,0x43},{0x00,0x71},{0x00,0x41}
};
// Standby sequences derived from Espressif Systems' Apache-2.0 esp_codec_dev:
// https://github.com/espressif/esp-adf/blob/release/v2.x/components/esp_codec_dev/device/es7210/es7210.c#L294-L306
// https://github.com/espressif/esp-adf/blob/release/v2.x/components/esp_codec_dev/device/es8311/es8311.c#L265-L286
inline constexpr Register kStandbyAdc[]={
  {0x47,0xFF},{0x48,0xFF},{0x49,0xFF},{0x4A,0xFF},{0x4B,0xFF},{0x4C,0xFF},
  {0x40,0xC0},{0x01,0x7F},{0x06,0x07}
};
inline constexpr Register kSuspendDac[]={
  {0x32,0x00},{0x17,0x00},{0x0E,0xFF},{0x12,0x02},{0x14,0x00},{0x0D,0xFA},
  {0x15,0x00},{0x02,0x10},{0x00,0x00},{0x00,0x1F},{0x01,0x30},{0x01,0x00},
  {0x45,0x00},{0x0D,0xFC},{0x02,0x00}
};

template<class Bus> class Codecs {
 public:
  explicit Codecs(Bus& bus):bus_(bus) {}
  template<class Clock,class Cancelled>
  WakeStatus initialize(Clock clock,Cancelled cancelled,uint32_t started) {
    for(const auto reg:kInitializeAdc) {
      if(cancelled()) return WakeStatus::Cancelled;
      // Each Wire transaction has the existing 20 ms timeout. Do not start one
      // unless it fits the remaining shared budget; never change the shared bus.
      if(uint32_t(clock()-started)>=kReadyBudgetMs-20) return WakeStatus::TimedOut;
      if(!bus_.write(0x40,reg.address,reg.value)) return WakeStatus::CodecError;
    }
    if(cancelled()) return WakeStatus::Cancelled;
    return uint32_t(clock()-started)>=kReadyBudgetMs?WakeStatus::TimedOut:WakeStatus::Ready;
  }
  bool standby() { return writeAll(0x40,kStandbyAdc); }
  DacStatus suspendUnusedDac() {
    if(dacChecked_) return dacStatus_;
    dacChecked_=true;
    if(bus_.present(0x18)) dacStatus_=writeAll(0x18,kSuspendDac)?DacStatus::Suspended:DacStatus::WriteError;
    return dacStatus_;
  }
 private:
  template<size_t N> bool writeAll(uint8_t address,const Register (&sequence)[N]) {
    bool ok=true;
    // A failed write must not prevent attempts to shut down the other blocks.
    for(const auto reg:sequence) { const bool written=bus_.write(address,reg.address,reg.value); ok=written && ok; }
    return ok;
  }
  Bus& bus_;
  bool dacChecked_=false;
  DacStatus dacStatus_=DacStatus::Absent;
};

template<class Capture,class Codec> class Lifecycle {
 public:
  Lifecycle(Capture& capture,Codec& codec):capture_(capture),codec_(codec) {}
  template<class Clock,class Pause,class Cancelled>
  WakeStatus wake(Clock clock,Pause pause,Cancelled cancelled,uint32_t started) {
    if(cancelled()) return WakeStatus::Cancelled;
    // Failed cleanup is retried and must succeed before a fresh capture.
    if(attempted_ && !standbyKnown_ && !standby()) return WakeStatus::CodecError;
    attempted_=true;standbyKnown_=false;
    if(uint32_t(clock()-started)>=kReadyBudgetMs) return WakeStatus::TimedOut;
    if(!capture_.begin() || !capture_.start()) return WakeStatus::DriverError;
    const uint32_t clockAt=clock();
    while(uint32_t(clock()-clockAt)<kClockPrerollMs) {
      if(cancelled()) return WakeStatus::Cancelled;
      if(uint32_t(clock()-started)>=kReadyBudgetMs) return WakeStatus::TimedOut;
      pause(5);
    }
    return codec_.initialize(clock,cancelled,started);
  }
  bool standby() {
    if(standbyKnown_) return true;
    // Power down the analog/ADC/bias blocks while MCLK is still available.
    // end() deletes the channel: disable() alone leaves MCLK running in IDF.
    const bool codecOk=codec_.standby();
    const bool driverOk=capture_.end();
    standbyKnown_=codecOk && driverOk;
    return standbyKnown_;
  }
  bool standbyKnown() const { return standbyKnown_; }
 private:
  Capture& capture_;
  Codec& codec_;
  bool attempted_=false,standbyKnown_=false;
};

// Explicit close reports failures before success can escape; destruction is the
// cancellation/error safety net, reporting the same checked result to its owner.
template<class Owner,class Observe> class StandbyScope {
 public:
  StandbyScope(Owner& owner,Observe observe):owner_(owner),observe_(observe) {}
  StandbyScope(const StandbyScope&)=delete;
  StandbyScope& operator=(const StandbyScope&)=delete;
  ~StandbyScope() { if(!closed_) close(); }
  bool close() {
    if(closed_) return result_;
    closed_=true; result_=owner_.standby(); observe_(result_); return result_;
  }
 private:
  Owner& owner_;
  Observe observe_;
  bool closed_=false,result_=false;
};
} // namespace Tamagotchi::MicrophonePower
