#pragma once
#include <stdint.h>
// Public starter intentionally has no old owner's endpoint or pairing token.
// Configure a new owner's service through a dedicated provisioning integration.
namespace Tamagotchi::ServerConfig {
inline constexpr char kBaseUrl[] = "";
inline constexpr char kReceiptScopeBaseUrl[] = "";
inline constexpr char kToken[] = "";
inline constexpr char kCa[] = "";
inline constexpr uint64_t kProvisionedEpoch = 0;
}
