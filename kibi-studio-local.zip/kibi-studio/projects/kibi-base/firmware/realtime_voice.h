#pragma once
#include "cloud_voice.h"
#include "realtime_voice_protocol.h"
#include "realtime_voice_messages.h"
#include "voice_preview.h"
#include "tls_diagnostics.h"

#if defined(ARDUINO) && KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
#include <NetworkClientSecure.h>
#include <mbedtls/base64.h>
#include <mbedtls/sha1.h>
#include <new>

namespace Tamagotchi::RealtimeVoice {
enum class ConnectionPhase:uint32_t { Idle,Clock,Gate,Connect,Upgrade,Start,WaitingReady,Streaming,Commit,Complete,Fallback,Poll,Failed,Cancelled };
struct ConnectionDiagnostics {
  ConnectionPhase phase;
  uint32_t ageMs,gateWaitMs,connectMs,gateFailures;
  int32_t tlsError,upgradeStatus;
};
namespace Detail {
enum class Completion { Idle,Running,Final,Fallback,Poll,Failed,Cancelled };
struct Runtime {
  BoundedText pcmStorage,incoming,outgoing,previewMemory;
  SemaphoreHandle_t previewLock=nullptr;
  VoicePreview::Card *previewInbox=nullptr,*previewDisplay=nullptr;
  VoicePreview::Presentation presentation;
  bool previewPending=false; // Main-loop owned, as are display/presentation.
  PcmRing* ring=nullptr;
  TaskHandle_t task=nullptr;
  std::atomic<bool> active{false},cancelled{false},captureDone{false};
  std::atomic<uint32_t> samples{0};
  std::atomic<Completion> completion{Completion::Idle};
  std::atomic<ConnectionPhase> connectionPhase{ConnectionPhase::Idle};
  std::atomic<uint32_t> phaseAt{0},gateWaitMs{0},connectMs{0},gateFailures{0};
  std::atomic<int32_t> connectError{0},upgradeStatus{0};
  uint32_t noteId=0;
  bool readOnlyProbe=false;
  char jobId[33]{},error[192]{};
};
inline Runtime runtime;
inline void phase(ConnectionPhase value) {
  runtime.phaseAt.store(millis());runtime.connectionPhase.store(value);
}
inline void logPhase(const char* name,int32_t value=0,uint32_t elapsed=0) {
  char line[160];
  snprintf(line,sizeof line,"[VOICE-WS] job=%.12s phase=%s value=%ld elapsed_ms=%lu\n",
      runtime.jobId,name,(long)value,(unsigned long)elapsed);
  Serial.print(line);
}
inline void publishPreview(VoicePreview::Kind kind,const char* title,const char* text) {
  if(!runtime.previewLock || xSemaphoreTake(runtime.previewLock,pdMS_TO_TICKS(20))!=pdTRUE) return;
  runtime.previewInbox->set(kind,title,text);
  xSemaphoreGive(runtime.previewLock);
}
using Socket=ServerTransport::Socket;
inline Completion fail(const char* message,const SendLedger& ledger) {
  phase(ConnectionPhase::Failed);
  snprintf(runtime.error,sizeof runtime.error,"%s",message);
  return ledger.failureRecovery()==FailureRecovery::Poll?Completion::Poll:Completion::Failed;
}
inline void logConnect(unsigned attempt,uint32_t elapsed,int error,bool connected) {
  char line[256];
  runtime.connectMs.store(elapsed);runtime.connectError.store(error);
  snprintf(line,sizeof line,"[VOICE-CONNECT] job=%.12s attempt=%u elapsed_ms=%lu connected=%u tls=%d wifi=%d ring_bytes=%u heap=%lu largest=%lu\n",
      runtime.jobId,attempt,(unsigned long)elapsed,unsigned(connected),error,int(WiFi.status()),unsigned(runtime.ring->size()),
      (unsigned long)ESP.getFreeHeap(),(unsigned long)ESP.getMaxAllocHeap());
  Serial.print(line);
}
inline bool writeAll(NetworkClient& client,const uint8_t* data,size_t bytes,bool cancelling=false) {
  size_t offset=0; const uint32_t started=millis();
  while(offset<bytes) {
    if((!cancelling && runtime.cancelled.load()) || uint32_t(millis()-started)>=2000 || !client.connected()) return false;
    const size_t sent=client.write(data+offset,bytes-offset);
    if(!sent || sent>bytes-offset) return false;
    offset+=sent;
  }
  return true;
}
inline bool sendFrame(NetworkClient& client,uint8_t opcode,const uint8_t* data,size_t bytes,bool cancelling=false) {
  uint8_t mask[4],header[14]; esp_fill_random(mask,sizeof mask);
  const size_t headerBytes=clientFrameHeader(opcode,bytes,mask,header);
  if(!writeAll(client,header,headerBytes,cancelling)) return false;
  uint8_t masked[512];
  for(size_t offset=0;offset<bytes;) {
    const size_t count=bytes-offset<sizeof masked?bytes-offset:sizeof masked;
    memcpy(masked,data+offset,count); maskBytes(masked,count,mask,offset);
    if(!writeAll(client,masked,count,cancelling)) return false;
    offset+=count;
  }
  return true;
}
inline bool sendText(NetworkClient& client,const char* text,bool cancelling=false) {
  return sendFrame(client,1,reinterpret_cast<const uint8_t*>(text),strlen(text),cancelling);
}
inline int upgrade(NetworkClient& client,const SecureEndpoint& endpoint) {
  uint8_t nonce[16],digest[20]; esp_fill_random(nonce,sizeof nonce);
  char key[25]{},expected[29]{},joined[64]; size_t bytes=0;
  if(mbedtls_base64_encode(reinterpret_cast<unsigned char*>(key),sizeof key,&bytes,nonce,sizeof nonce) || bytes!=24) return 0;
  snprintf(joined,sizeof joined,"%s258EAFA5-E914-47DA-95CA-C5AB0DC85B11",key);
  if(mbedtls_sha1(reinterpret_cast<const unsigned char*>(joined),strlen(joined),digest) ||
     mbedtls_base64_encode(reinterpret_cast<unsigned char*>(expected),sizeof expected,&bytes,digest,sizeof digest) || bytes!=28) return 0;
  if(!*ServerConfig::kToken || strnlen(ServerConfig::kToken,513)>512 || strpbrk(ServerConfig::kToken,"\r\n")) return 0;
  char request[1152],host[144];
  if(!ServerTransport::formatHost(endpoint,host,sizeof host)) return 0;
  const int count=snprintf(request,sizeof request,
      "GET %s/api/core/realtime/%s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
      "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\nAuthorization: Bearer %s\r\nUser-Agent: kibi/Realtime/1\r\n\r\n",
      endpoint.prefix,runtime.jobId,host,key,ServerConfig::kToken);
  if(count<=0 || size_t(count)>=sizeof request || !writeAll(client,reinterpret_cast<const uint8_t*>(request),size_t(count))) return 0;
  // Header storage is transient PSRAM; the receive buffer remains bounded and
  // is reused for final JSON after Upgrade, including a frame arriving at once.
  char* headers=runtime.incoming.data(); size_t used=0; const uint32_t started=millis();
  while(used<4096 && uint32_t(millis()-started)<8000 && !runtime.cancelled.load()) {
    if(client.available()) {
      const int byte=client.read(); if(byte<0) continue;
      headers[used++]=char(byte); headers[used]=0;
      if(!byte) return 0;
      if(used>=4 && !memcmp(headers+used-4,"\r\n\r\n",4)) return validateUpgrade(headers,expected);
    } else if(!client.connected()) break;
    else delay(1);
  }
  return 0;
}
inline Completion session() {
  SendLedger ledger;
  SecureEndpoint endpoint;
  if(!parseEndpoint(ServerConfig::kBaseUrl,endpoint)) return fail("The kibi Core address is not configured.",ledger);
  phase(ConnectionPhase::Clock);
  const uint32_t clockStarted=millis();
  while(endpoint.secure && time(nullptr)<1735689600) {
    if(runtime.cancelled.load()) return Completion::Cancelled;
    if(uint32_t(millis()-clockStarted)>=12000) return fail("Wait for the clock, then record again.",ledger);
    delay(20);
  }
  phase(ConnectionPhase::Gate);
  const uint32_t gateStarted=millis();
  NetworkGate::Lease lease(NetworkGate::Priority::Voice,8000);
  runtime.gateWaitMs.store(uint32_t(millis()-gateStarted));
  logPhase("gate",bool(lease),runtime.gateWaitMs.load());
  const bool cancelled=runtime.cancelled.load();
  if(cancelled) return Completion::Cancelled;
  if(!lease) {
    ++runtime.gateFailures;
    // The original queue and WAV keep collecting; no HTTP or PCM reached a
    // server. Releasing the button can upload this exact existing job ID.
    if(initialLeaseRecovery(false,ledger,cancelled)==InitialConnectRecovery::Fallback) return Completion::Fallback;
    return fail("Could not open voice chat. Record again.",ledger);
  }
  Socket client;
  if(*ServerConfig::kCa) client.setCACert(ServerConfig::kCa); else client.useBuiltinCACertBundle();
  client.setTimeout(1000); client.setHandshakeTimeout(6);
  // Declare stop after the lease/client: TLS is always closed before another
  // network owner can begin, also on every early return.
  struct Stop { NetworkClient& client; ~Stop() { client.stop(); } } stop{client};
  phase(ConnectionPhase::Connect);
  for(unsigned attempt=1;;++attempt) {
    if(runtime.cancelled.load()) return Completion::Cancelled;
    const uint32_t connectStarted=millis();
    const bool connected=WiFi.status()==WL_CONNECTED && client.connect(endpoint.host,endpoint.port,6000);
    char ignored[1]{};
    const int tlsError=connected?0:client.lastError(ignored,sizeof ignored);
    logConnect(attempt,uint32_t(millis()-connectStarted),tlsError,connected);
    if(connected) break;
    client.stop();
    if(runtime.cancelled.load()) return Completion::Cancelled;
    const auto recovery=initialConnectRecovery(attempt,tlsError,false,ledger,false);
    if(recovery==InitialConnectRecovery::Fallback) return Completion::Fallback;
    if(recovery!=InitialConnectRecovery::Retry)
      return fail("Voice chat is offline. Record again.",ledger);
    // Only transport setup repeats. Upgrade/start/PCM were never sent, and
    // neither the job identity nor the producer queue is reset.
    const uint32_t retryAt=millis();
    while(uint32_t(millis()-retryAt)<250) {
      if(runtime.cancelled.load()) return Completion::Cancelled;
      delay(10);
    }
  }
  client.ioTimeout(1000);
  if(runtime.cancelled.load()) return Completion::Cancelled;
  phase(ConnectionPhase::Upgrade);
  const int status=upgrade(client,endpoint);
  runtime.upgradeStatus.store(status);logPhase("upgrade_status",status);
  // HTTP compatibility fallback is safe before a WebSocket/PCM is accepted.
  // Authentication or provider failures after Upgrade never trigger a new
  // transport attempt; certificate failures already failed closed above.
  if(status==404) return Completion::Fallback;
  if(status!=101) return fail("The server could not open voice chat. Record again.",ledger);
  char start[192];
  snprintf(start,sizeof start,"{\"type\":\"start\",\"version\":%u,\"note_id\":\"%08lx\",\"sample_rate\":16000,\"channels\":1,\"format\":\"pcm16\"}",
      kProtocolVersion,static_cast<unsigned long>(runtime.noteId));
  phase(ConnectionPhase::Start);
  if(!sendText(client,start)) return fail("Voice chat was interrupted while starting.",ledger);
  logPhase("start_sent");phase(ConnectionPhase::WaitingReady);
  FrameDecoder decoder(runtime.incoming.data(),runtime.incoming.capacity());
  Https::PsramJsonAllocator allocator; JsonDocument json(&allocator);
  bool ready=false; uint32_t committedAt=0,sentBytes=0,lastPing=millis(); const uint32_t started=millis();
  auto* pcm=reinterpret_cast<uint8_t*>(runtime.outgoing.data());
  for(;;) {
    if(runtime.cancelled.load()) { sendText(client,"{\"type\":\"cancel\"}",true); return Completion::Cancelled; }
    // One bounded read batch lets the PCM producer and UI run between TLS work.
    unsigned received=0;
    while(client.available() && received++<8192) {
      const int byte=client.read(); if(byte<0) break;
      FrameEvent event; const auto frame=decoder.feed(uint8_t(byte),event);
      if(frame==FrameResult::Invalid || frame==FrameResult::Binary)
        return fail("The server returned an invalid voice response.",ledger);
      if(frame==FrameResult::Ping) {
        if(!sendFrame(client,10,event.data,event.bytes)) return fail("Voice chat was interrupted.",ledger);
      } else if(frame==FrameResult::Closed) {
        sendFrame(client,8,event.data,event.bytes);
        return fail("Voice chat closed. Record again.",ledger);
      } else if(frame==FrameResult::Text) {
        json.clear();
        if(memchr(event.data,0,event.bytes) || deserializeJson(json,reinterpret_cast<const char*>(event.data),event.bytes,DeserializationOption::NestingLimit(6)) || json.overflowed())
          return fail("The server returned an invalid voice response.",ledger);
        const auto message=classifyMessage(json.as<JsonVariantConst>(),runtime.jobId,ready,ledger);
        if(message==ServerEvent::Ready) {
          ready=true;phase(ConnectionPhase::Streaming);logPhase("ready",0,uint32_t(millis()-started));
          if(runtime.readOnlyProbe) {
            if(!sendText(client,"{\"type\":\"cancel\"}",true)) return fail("The voice chat check was interrupted.",ledger);
            logPhase("probe_ready_cancelled");return Completion::Cancelled;
          }
        } else if(message==ServerEvent::Progress) {
          // Durable finalization still arrives in the unchanged final envelope.
        } else if(message==ServerEvent::Transcript) {
          publishPreview(VoicePreview::Kind::Transcript,"You said",json["text"].as<const char*>());
        } else if(message==ServerEvent::Preview) {
          publishPreview(VoicePreview::Kind::Answer,json["title"].as<const char*>(),json["text"].as<const char*>());
        } else if(message==ServerEvent::Fallback) return Completion::Fallback;
        else if(message==ServerEvent::Poll) return Completion::Poll;
        else if(message==ServerEvent::Final) {
          const uint8_t close[]={3,232}; sendFrame(client,8,close,sizeof close);
          return Completion::Final;
        } else return fail("The service could not process your voice request.",ledger);
      }
    }
    if(!client.connected()) return fail("Voice chat was interrupted. Record again.",ledger);
    if(!ready && uint32_t(millis()-started)>=kReadyTimeoutMs) return fail("The server did not confirm the recording.",ledger);
    if(ready && !ledger.committed()) {
      const size_t count=runtime.ring->pop(pcm,kMaximumPcmFrameBytes);
      if(count) {
        // Claim before the first transport byte: a partial write is ambiguous.
        ledger.pcmAttempted();
        if(!sentBytes) logPhase("first_pcm",int32_t(count));
        if(!sendFrame(client,2,pcm,count)) return fail("Audio transfer was interrupted. Record again.",ledger);
        sentBytes+=uint32_t(count);
      } else if(runtime.captureDone.load(std::memory_order_acquire)) {
        // Producer may have published the last block between pop and captureDone.
        if(runtime.ring->size()) continue;
        const uint32_t samples=runtime.samples.load();
        if(sentBytes!=samples*2 || !ledger.claimCommit()) return fail("The audio transfer is incomplete.",ledger);
        phase(ConnectionPhase::Commit);
        char commit[64]; snprintf(commit,sizeof commit,"{\"type\":\"commit\",\"samples\":%lu}",static_cast<unsigned long>(samples));
        if(!sendText(client,commit)) return fail("Recording confirmation was interrupted. Checking the original request.",ledger);
        logPhase("commit",int32_t(samples));
        committedAt=millis();
      }
    }
    if(ledger.committed() && uint32_t(millis()-committedAt)>=90000)
      return fail("The reply is delayed. Checking the original request.",ledger);
    if(!ledger.committed() && uint32_t(millis()-started)>=45000)
      return fail("The voice recording timed out.",ledger);
    if(uint32_t(millis()-lastPing)>=15000) {
      if(!sendFrame(client,9,nullptr,0)) return fail("Voice chat was interrupted.",ledger);
      lastPing=millis();
    }
    delay(1);
  }
}
inline void worker(void*) {
  for(;;) {
    ulTaskNotifyTake(pdTRUE,portMAX_DELAY);
    const auto result=session(); // Its TLS client/lease are already destroyed.
    phase(result==Completion::Final?ConnectionPhase::Complete:result==Completion::Fallback?ConnectionPhase::Fallback:
        result==Completion::Poll?ConnectionPhase::Poll:result==Completion::Cancelled?ConnectionPhase::Cancelled:ConnectionPhase::Failed);
    runtime.completion.store(result,std::memory_order_release);
    runtime.active.store(false,std::memory_order_release);
  }
}
} // namespace Detail

inline const char* connectionPhaseName(ConnectionPhase phase) {
  constexpr const char* names[]={"idle","clock","gate","connect","upgrade","start","waiting-ready","streaming","commit","complete","fallback","poll","failed","cancelled"};
  const uint32_t index=uint32_t(phase);return index<sizeof names/sizeof names[0]?names[index]:"unknown";
}
// Scalar snapshots never wait on a TLS owner, filesystem or preview mutex.
inline ConnectionDiagnostics connectionDiagnostics() {
  const auto& state=Detail::runtime;
  return {state.connectionPhase.load(),uint32_t(millis()-state.phaseAt.load()),state.gateWaitMs.load(),
      state.connectMs.load(),state.gateFailures.load(),state.connectError.load(),state.upgradeStatus.load()};
}

inline bool begin() {
  auto& state=Detail::runtime;
  if(state.task) return true;
  if(!state.pcmStorage.reserve(kPcmRingBytes) || !state.incoming.reserve(CloudVoice::Detail::kMaximumResponseBytes+1) ||
     !state.outgoing.reserve(kMaximumPcmFrameBytes) || !state.previewMemory.reserve(2*sizeof(VoicePreview::Card))) return false;
  if(!state.previewLock) state.previewLock=xSemaphoreCreateMutex();
  if(!state.previewLock) return false;
  if(!state.previewInbox) {
    state.previewInbox=new(state.previewMemory.data()) VoicePreview::Card{};
    state.previewDisplay=new(state.previewMemory.data()+sizeof(VoicePreview::Card)) VoicePreview::Card{};
  }
  if(!state.ring) state.ring=new(std::nothrow) PcmRing(reinterpret_cast<uint8_t*>(state.pcmStorage.data()),kPcmRingBytes);
  return state.ring && xTaskCreatePinnedToCore(Detail::worker,"voice_ws",8192,nullptr,1,&state.task,0)==pdPASS;
}
// Called only by the main loop before a new voice worker is notified.
inline void resetPreview() {
  auto& state=Detail::runtime;
  state.presentation.reset();state.previewPending=false;
  if(state.previewDisplay) state.previewDisplay->clear();
  if(state.previewLock && xSemaphoreTake(state.previewLock,pdMS_TO_TICKS(20))==pdTRUE) {
    state.previewInbox->clear();
    xSemaphoreGive(state.previewLock);
  }
}
inline const VoicePreview::Card* preview() {
  const auto& state=Detail::runtime;
  return state.previewDisplay && state.presentation.visible(*state.previewDisplay)?state.previewDisplay:nullptr;
}
inline bool updatePreview(bool pending) {
  auto& state=Detail::runtime;
  const bool wasVisible=preview()!=nullptr;
  const bool transition=pending!=state.previewPending;
  if(transition) {
    if(pending) state.presentation.start();else state.presentation.finish();
    state.previewPending=pending;
  }
  bool changed=false;
  if(pending && state.previewLock && xSemaphoreTake(state.previewLock,0)==pdTRUE) {
    if(state.previewDisplay->revision!=state.previewInbox->revision) {
      *state.previewDisplay=*state.previewInbox;changed=true;
    }
    xSemaphoreGive(state.previewLock);
  }
  return (changed && preview()) || wasVisible!=(preview()!=nullptr);
}
inline void dismissPreview() { Detail::runtime.presentation.dismiss(); }
inline bool allowFinalPresentation() { return Detail::runtime.presentation.allowFinal(); }
inline bool start(uint32_t noteId,bool readOnlyProbe=false) {
  auto& state=Detail::runtime;
  if(!state.task || !noteId || state.active.exchange(true)) return false;
  state.ring->reset(); state.cancelled=false; state.captureDone=false; state.samples=0;
  state.noteId=noteId; state.error[0]=0; state.incoming.data()[0]=0;
  state.readOnlyProbe=readOnlyProbe;
  state.gateWaitMs=0;state.connectMs=0;state.connectError=0;state.upgradeStatus=0;
  Detail::phase(ConnectionPhase::Idle);
  uint8_t random[16]; esp_fill_random(random,sizeof random);
  for(size_t i=0;i<sizeof random;++i) snprintf(state.jobId+2*i,3,"%02x",random[i]);
  state.completion.store(Detail::Completion::Running,std::memory_order_release);
  xTaskNotifyGive(state.task); return true;
}
inline const char* jobId() { return Detail::runtime.jobId; }
inline bool shouldStopCapture() {
  const auto state=Detail::runtime.completion.load(std::memory_order_acquire);
  return state!=Detail::Completion::Running && state!=Detail::Completion::Fallback;
}
inline bool append(const int16_t* mono,size_t samples) {
  auto& state=Detail::runtime;
  if(state.completion.load(std::memory_order_acquire)!=Detail::Completion::Running) return true;
  return state.ring->push(reinterpret_cast<const uint8_t*>(mono),samples*2);
}
inline void cancel() {
  auto& state=Detail::runtime; state.cancelled.store(true,std::memory_order_release);
  // Only the TLS owner touches/closes its socket. Capture has already stopped;
  // its independent task can finish a bounded handshake without blocking UI.
  while(state.active.load(std::memory_order_acquire)) delay(10);
}
enum class Finish { Complete,Fallback,Failed };
inline Finish finish(uint32_t samples,char* transcript,size_t capacity,Assistant::Reply& reply,char* error,size_t errorCapacity) {
  auto& state=Detail::runtime;
  state.samples=samples; state.captureDone.store(true,std::memory_order_release);
  while(state.active.load(std::memory_order_acquire)) delay(10);
  strcpy(reply.jobId,state.jobId);
  const auto completed=state.completion.load(std::memory_order_acquire);
  if(completed==Detail::Completion::Fallback) {
    // The compatibility PUT uses exactly the same job and reserved note ID.
    const size_t bytes=AudioFile::pendingBytes(); FILE* file=bytes?fopen(AudioFile::kPendingPath,"rb"):nullptr;
    CloudVoice::RecordingIdentity identity; identity.noteId=state.noteId; identity.bytes=uint32_t(bytes); strcpy(identity.jobId,state.jobId);
    const bool hashed=file && CloudVoice::Detail::hashWav(file,bytes,identity.sha256);
    if(file) fclose(file);
    if(hashed && CloudVoice::saveIdentity(AudioFile::kPendingPath,identity)) return Finish::Fallback;
    Weather::fail(error,errorCapacity,"Could not verify the voice recording ID."); return Finish::Failed;
  }
  // Streaming PCM is single use. Neither GET recovery nor an error needs WAV.
  AudioFile::acknowledgeSaved();
  if(completed==Detail::Completion::Poll)
    return CloudVoice::pollJob(state.jobId,state.noteId,transcript,capacity,reply,error,errorCapacity,10000)?Finish::Complete:Finish::Failed;
  if(completed==Detail::Completion::Final) {
    Https::PsramJsonAllocator allocator; JsonDocument json(&allocator);
    if(!deserializeJson(json,static_cast<const char*>(state.incoming.data()),DeserializationOption::NestingLimit(6))) {
      const auto result=CloudVoice::parseResult(json.as<JsonVariantConst>(),state.jobId,transcript,capacity,reply,error,errorCapacity);
      return result==CloudVoice::Result::Complete || result==CloudVoice::Result::Unavailable?Finish::Complete:Finish::Failed;
    }
  }
  Weather::fail(error,errorCapacity,*state.error?state.error:"The voice recording was interrupted. Record again.");
  return Finish::Failed;
}
} // namespace Tamagotchi::RealtimeVoice
#endif
