#pragma once
#include "notes.h"
#include <ArduinoJson.h>

namespace Tamagotchi::Inbox {
constexpr size_t kReceiptCount=64;
constexpr uint32_t kPollMilliseconds=10000;
enum class Kind { Note,Shopping,Answer,Reminder,Clarify,Unavailable,Notification };
enum class Applied { Failed,Already,New };

inline bool lowerHex(const char* value,size_t bytes) {
  if(!value || strnlen(value,bytes+1)!=bytes) return false;
  for(size_t i=0;i<bytes;++i)
    if(!((value[i]>='0' && value[i]<='9') || (value[i]>='a' && value[i]<='f'))) return false;
  return true;
}
inline uint32_t crc(const uint8_t* data,size_t bytes) {
  uint32_t value=~uint32_t(0);
  for(size_t i=0;i<bytes;++i) {
    value^=data[i];
    for(int bit=0;bit<8;++bit) value=(value>>1)^(0xedb88320u & (0u-(value&1)));
  }
  return ~value;
}
inline void put32(uint8_t* out,uint32_t value) {
  for(int i=0;i<4;++i) out[i]=uint8_t(value>>(i*8));
}
inline uint32_t get32(const uint8_t* in) {
  uint32_t value=0; for(int i=0;i<4;++i) value|=uint32_t(in[i])<<(i*8); return value;
}
inline void decodeHex(const char* text,uint8_t* out,size_t bytes) {
  auto digit=[](char c) { return c<='9'?c-'0':c-'a'+10; };
  for(size_t i=0;i<bytes;++i) out[i]=uint8_t(digit(text[2*i])*16+digit(text[2*i+1]));
}
inline void encodeHex(const uint8_t* data,char* out,size_t bytes) {
  constexpr char digits[]="0123456789abcdef";
  for(size_t i=0;i<bytes;++i) { out[2*i]=digits[data[i]>>4]; out[2*i+1]=digits[data[i]&15]; }
  out[2*bytes]=0;
}

// A committed CRC snapshot is the only authority. An interrupted .part is
// ignored; corruption fails closed so an unacknowledged server delivery remains
// recoverable. The scope is a SHA-256 of the configured host/device credential.
class ReceiptStore {
 public:
  bool begin(const char* path,const char* scope) {
    ready_=false; count_=0;
    if(!path || strlen(path)>=sizeof path_ || !lowerHex(scope,64)) return false;
    strcpy(path_,path); decodeHex(scope,scope_,32);
    FILE* file=fopen(path_,"rb");
    if(!file) {
      if(errno!=ENOENT || !persist(nullptr)) return false;
      ready_=true; return true;
    }
    uint8_t data[kMaximumBytes]; const size_t bytes=fread(data,1,sizeof data,file);
    const bool complete=!ferror(file) && fgetc(file)==EOF; fclose(file);
    if(!complete || bytes<44 || memcmp(data,"KIR1",4)) return false;
    const size_t count=get32(data+36);
    if(count>kReceiptCount || bytes!=44+16*count || get32(data+bytes-4)!=crc(data,bytes-4)) return false;
    if(memcmp(data+4,scope_,32)) {
      if(!persist(nullptr)) return false;
      ready_=true; return true;
    }
    for(size_t i=0;i<count;++i) encodeHex(data+40+16*i,ids_[i],16);
    count_=count; ready_=true; return true;
  }
  bool contains(const char* id) const {
    if(!ready_ || !lowerHex(id,32)) return false;
    for(size_t i=0;i<count_;++i) if(!strcmp(ids_[i],id)) return true;
    return false;
  }
  bool markApplied(const char* id) {
    if(!ready_ || !lowerHex(id,32)) return false;
    if(contains(id)) return true;
    if(!persist(id)) return false;
    if(count_==kReceiptCount) {
      memmove(ids_,ids_+1,(kReceiptCount-1)*sizeof ids_[0]); --count_;
    }
    strcpy(ids_[count_++],id); return true;
  }
 private:
  static constexpr size_t kMaximumBytes=44+16*kReceiptCount;
  char path_[128]{},ids_[kReceiptCount][33]{};
  uint8_t scope_[32]{};
  size_t count_=0;
  bool ready_=false;
  bool persist(const char* added) const {
    const size_t skip=added && count_==kReceiptCount?1:0;
    const size_t count=count_-skip+(added?1:0),bytes=44+16*count;
    uint8_t data[kMaximumBytes]; memcpy(data,"KIR1",4); memcpy(data+4,scope_,32); put32(data+36,uint32_t(count));
    for(size_t i=skip;i<count_;++i) decodeHex(ids_[i],data+40+16*(i-skip),16);
    if(added) decodeHex(added,data+40+16*(count-1),16);
    put32(data+bytes-4,crc(data,bytes-4));
    char temporary[sizeof path_+6]; snprintf(temporary,sizeof temporary,"%s.part",path_);
    FILE* file=fopen(temporary,"wb"); if(!file) return false;
    bool ok=fwrite(data,1,bytes,file)==bytes;
    ok=(fflush(file)==0) && ok; ok=(fsync(fileno(file))==0) && ok; ok=(fclose(file)==0) && ok;
    if(!ok || rename(temporary,path_)!=0) { remove(temporary); return false; }
    return true;
  }
};

struct Delivery {
  char id[33]{},heading[32]{},title[129]{};
  Kind kind=Kind::Notification;
  uint32_t noteId=0;
  BoundedText body;
  bool reserve() { return body.reserve(kNoteTextBytes+1); }
};
inline bool stringField(JsonVariantConst json,const char* name,size_t capacity,const char*& out,bool empty=false) {
  if(!json[name].is<const char*>()) return false;
  const auto text=json[name].as<JsonString>();
  out=text.c_str();
  return out && text.size()<capacity && !memchr(out,0,text.size()) &&
      ((empty && !*out) || validNoteText(out));
}
inline bool parse(JsonVariantConst json,Delivery& out) {
  if(!json.is<JsonObjectConst>() || json.size()!=7) return false;
  for(const char* name:{"id","kind","heading","title","text","note_id","note_text"})
    if(json[name].isUnbound()) return false;
  const char *id,*kind,*heading,*title,*text,*body;
  if(!stringField(json,"id",33,id) || !lowerHex(id,32) ||
     !stringField(json,"kind",16,kind) || !stringField(json,"heading",32,heading) ||
     !stringField(json,"title",129,title,true) || !stringField(json,"text",kNoteTextBytes+1,text,true)) return false;
  const char* names[]={"note","shopping","answer","reminder","clarify","unavailable","notification"};
  size_t index=0; while(index<7 && strcmp(kind,names[index])) ++index;
  if(index==7) return false;
  uint32_t noteId=0;
  if(index<2) {
    const char* note;
    if(*text || !stringField(json,"note_id",9,note) || !lowerHex(note,8) ||
       !stringField(json,"note_text",kNoteTextBytes+1,body)) return false;
    for(int i=0;i<8;++i) noteId=(noteId<<4)|uint32_t(note[i]<='9'?note[i]-'0':note[i]-'a'+10);
    if(!noteId || (index==1 && !ShoppingNotes::body(body))) return false;
  } else {
    if(!json["note_id"].isNull() || !json["note_text"].isNull() || !*text) return false;
    body=text;
  }
  if(!out.reserve()) return false;
  strcpy(out.id,id); strcpy(out.heading,heading); strcpy(out.title,title);
  out.kind=Kind(index); out.noteId=noteId; strcpy(out.body.data(),body); return true;
}

class PollSchedule {
 public:
  bool due(uint32_t now,bool allowed) {
    if(!allowed || (started_ && uint32_t(now-at_)<kPollMilliseconds)) return false;
    at_=now; started_=true; return true;
  }
 private:
  uint32_t at_=0; bool started_=false;
};
inline bool matchesError(bool error,const char* current,const char* incoming) {
  return error && lowerHex(current,32) && lowerHex(incoming,32) && !strcmp(current,incoming);
}
inline bool canApply(Kind kind,bool busy,bool pointerDown,bool readerOccupied,bool matchingError) {
  return !busy && !pointerDown && (kind==Kind::Note || !readerOccupied || matchingError);
}
inline NoteDeletions::State deletionState(const char* directory,uint32_t id) {
  const auto permanent=NoteDeletions::lookup(directory,id);
  return permanent==NoteDeletions::State::Clear?NoteDeletions::lookupLegacy(directory,id):permanent;
}
inline bool deletedNote(const char* directory,uint32_t id) {
  return deletionState(directory,id)==NoteDeletions::State::Deleted;
}
template<class Save,class Show>
Applied consume(const Delivery& delivery,ReceiptStore& receipts,Save save,Show show,bool deleted=false) {
  if(receipts.contains(delivery.id)) return Applied::Already;
  const bool note=delivery.kind==Kind::Note,shopping=delivery.kind==Kind::Shopping;
  // A durable local delete wins over a result that arrived later. Consuming the
  // receipt also releases the one pending slot while server reconciliation runs.
  if((note || shopping) && deleted) return receipts.markApplied(delivery.id)?Applied::New:Applied::Failed;
  if((note || shopping) && !save(delivery.noteId,delivery.body.data())) return Applied::Failed;
  const char* body=shopping?ShoppingNotes::body(delivery.body.data()):delivery.body.data();
  if(!note && !show(delivery.heading,*delivery.title?delivery.title:delivery.heading,body)) return Applied::Failed;
  return receipts.markApplied(delivery.id)?Applied::New:Applied::Failed;
}
template<class Save,class Show>
Applied consume(const Delivery& delivery,ReceiptStore& receipts,Save save,Show show,NoteDeletions::State deleted) {
  // An unavailable/corrupt ledger is not proof of deletion. Preserve the pending
  // delivery and leave it unacknowledged until durable history can be read.
  if(deleted==NoteDeletions::State::Error) return Applied::Failed;
  return consume(delivery,receipts,save,show,deleted==NoteDeletions::State::Deleted);
}
} // namespace Tamagotchi::Inbox
