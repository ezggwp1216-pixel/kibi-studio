#pragma once
#include "cloud_voice_protocol.h"

#if defined(ARDUINO) && KIBI_CLOUD_VOICE_ENABLED
#include "server_config.h"
#include "server_transport.h"
#include <WiFiMulti.h>
#include <mbedtls/sha256.h>
#include <esp_random.h>
#include <time.h>

namespace Tamagotchi::CloudVoice {
namespace Detail {
inline constexpr size_t kMaximumResponseBytes=6*kNoteTextBytes+16384;
class WavStream final : public Stream {
 public:
  WavStream(FILE* file,size_t bytes):payload_("",0,file,bytes,"",0) {}
  int available() override { return int(payload_.remaining()); }
  int peek() override { return payload_.peek(); }
  int read() override { uint8_t value; return payload_.read(&value,1)?value:-1; }
  size_t readBytes(char* out,size_t bytes) override { return payload_.read(reinterpret_cast<uint8_t*>(out),bytes); }
  size_t write(uint8_t) override { return 0; }
  void flush() override {}
  bool complete() const { return !payload_.failed() && !payload_.remaining(); }
 private:
  FileMultipartPayload payload_;
};
inline bool hashWav(FILE* file,size_t bytes,char (&hex)[65]) {
  if(fseek(file,0,SEEK_SET)) return false;
  mbedtls_sha256_context sha; mbedtls_sha256_init(&sha);
  bool ok=mbedtls_sha256_starts(&sha,0)==0;
  uint8_t chunk[2048],digest[32]{}; size_t read=0;
  while(ok && read<bytes) {
    const size_t want=bytes-read<sizeof chunk?bytes-read:sizeof chunk;
    const size_t count=fread(chunk,1,want,file); read+=count;
    ok=count==want && mbedtls_sha256_update(&sha,chunk,count)==0;
  }
  ok=ok && !ferror(file) && fgetc(file)==EOF && mbedtls_sha256_finish(&sha,digest)==0;
  mbedtls_sha256_free(&sha);
  if(fseek(file,0,SEEK_SET)) ok=false;
  if(ok) for(size_t i=0;i<32;++i) snprintf(hex+i*2,3,"%02x",digest[i]);
  return ok;
}
inline bool prepareIdentity(FILE* file,size_t bytes,uint32_t reservedNoteId,RecordingIdentity& identity) {
  char digest[65]; if(!hashWav(file,bytes,digest)) return false;
  const auto existing=readIdentity(AudioFile::kPendingPath,identity);
  if(existing==IdentityStatus::Ready)
    return identity.noteId==reservedNoteId && identityMatches(identity,digest,bytes);
  if(existing!=IdentityStatus::Missing || !reservedNoteId) return false;
  uint8_t random[16]; esp_fill_random(random,sizeof random);
  static constexpr char hex[]="0123456789abcdef";
  for(size_t i=0;i<sizeof random;++i) { identity.jobId[2*i]=hex[random[i]>>4]; identity.jobId[2*i+1]=hex[random[i]&15]; }
  identity.jobId[32]=0; strcpy(identity.sha256,digest); identity.bytes=uint32_t(bytes); identity.noteId=reservedNoteId;
  // Publish one identity before the single upload can reach Core. After PUT,
  // audio is discarded and only this in-memory identity is used for GETs.
  return saveIdentity(AudioFile::kPendingPath,identity);
}
struct HttpResult { int status=0; bool valid=false; };
inline HttpResult request(const char* url,const RecordingIdentity& identity,FILE* wav,uint32_t budget,
                          char* buffer,size_t capacity,JsonDocument& response) {
  response.clear();
  if(budget<1000) return {-1,false};
  const uint32_t timeout=budget<8000?budget:8000;
  ServerTransport::Client client(budget,NetworkGate::Priority::Voice);
  if(*ServerConfig::kCa) client.setCACert(ServerConfig::kCa);
  else client.useBuiltinCACertBundle();
  client.setTimeout(timeout); client.setHandshakeTimeout(timeout/1000);
  HTTPClient http;
  http.setUserAgent("kibi/CoreVoice/1"); http.setConnectTimeout(timeout<6000?timeout:6000);
  http.setTimeout(timeout); http.setReuse(false);
  if(!http.begin(client,url)) return {-1,false};
  struct End { HTTPClient& http; ~End() { http.end(); } } end{http};
  http.addHeader("Authorization",String("Bearer ")+ServerConfig::kToken);
  http.addHeader("Accept","application/json"); http.addHeader("Accept-Encoding","identity");
  int status;
  if(wav) {
    if(fseek(wav,0,SEEK_SET)) return {0,false};
    char noteId[9]; snprintf(noteId,sizeof noteId,"%08lx",static_cast<unsigned long>(identity.noteId));
    http.addHeader("Content-Type","audio/wav"); http.addHeader("X-Audio-SHA256",identity.sha256);
    http.addHeader("X-Note-ID",noteId);
    WavStream stream(wav,identity.bytes);
    status=http.sendRequest("PUT",&stream,identity.bytes);
    if(!stream.complete()) return {status<0?status:-1,false};
  } else status=http.GET();
  if(status!=200 && (!wav || status!=202 && status!=201)) return {status,false};
  Https::BoundedStream sink(buffer,capacity);
  const int expected=http.getSize();
  if(expected>=int(capacity)) return {status,false};
  const int received=http.writeToStream(&sink);
  if(client.timedOut() || sink.overflow || received<0 || (expected>=0 && received!=expected)) return {status,false};
  const auto parsed=deserializeJson(response,static_cast<const char*>(buffer),sink.size(),DeserializationOption::NestingLimit(6));
  return {status,!parsed && !response.overflowed()};
}
inline bool httpFailure(int status,char* error,size_t capacity) {
  const char* message="No response from kibi Core. Audio deleted; it will not be resent.";
  if(status==401 || status==403) message="Device access denied. Check pairing, then record again.";
  else if(status==409) message="Recording conflicts with a server job. It will not be resent.";
  else if(status==413 || status==422) message="The server rejected the audio format. Record again.";
  else if(status==429) message="The service is busy. Audio deleted; it will not be resent.";
  return Weather::fail(error,capacity,message);
}
} // namespace Detail

// A disconnected stream can ask only about its original durable identity. It
// must never replay PCM as a new upload after an ambiguous write or commit.
inline bool pollJob(const char* jobId,uint32_t noteId,char* transcript,size_t transcriptCapacity,
                    Assistant::Reply& reply,char* error,size_t errorCapacity,uint32_t initialNotFoundGraceMs=0) {
  if(!lowerHex(jobId,32)) return Weather::fail(error,errorCapacity,"Invalid voice request ID.");
  strcpy(reply.jobId,jobId);
  RecordingIdentity identity; strcpy(identity.jobId,jobId); identity.noteId=noteId;
  char url[256];
  const int bytes=snprintf(url,sizeof url,"%s/api/core/voice/%s",ServerConfig::kBaseUrl,jobId);
  if(bytes<=0 || size_t(bytes)>=sizeof url) return Weather::fail(error,errorCapacity,"Invalid kibi Core address.");
  BoundedText scratch;
  if(!scratch.reserve(Detail::kMaximumResponseBytes+1)) return Weather::fail(error,errorCapacity,"Not enough memory for the kibi Core response.");
  Https::PsramJsonAllocator allocator; JsonDocument response(&allocator);
  const uint32_t started=millis(); bool observed=false;
  for(;;) {
    const uint32_t remaining=pollRemaining(started,millis()); if(remaining<1500) break;
    const auto received=Detail::request(url,identity,nullptr,remaining,scratch.data(),scratch.capacity(),response);
    if(received.valid) {
      observed=true;
      const auto result=parseResult(response.as<JsonVariantConst>(),jobId,transcript,transcriptCapacity,reply,error,errorCapacity);
      if(result==Result::Complete || result==Result::Unavailable) return true;
      if(result!=Result::Pending) return false;
    } else if(!retryableHttp(received.status) && !retryInitialMissingJob(received.status,observed,started,millis(),initialNotFoundGraceMs))
      return Detail::httpFailure(received.status,error,errorCapacity);
    delay(1500);
  }
  return Weather::fail(error,errorCapacity,"Still processing. The result will arrive as a notification. Audio deleted.");
}

inline bool process(uint32_t reservedNoteId,char* transcript,size_t transcriptCapacity,Assistant::Reply& reply,
                    char* error,size_t errorCapacity) {
  auto fail=[&](const char* message) { return Weather::fail(error,errorCapacity,message); };
  if(!ServerTransport::configured() || !*ServerConfig::kToken)
    return fail("Configure the kibi Core address in settings.");
  if(WiFi.status()!=WL_CONNECTED) return fail("No Wi-Fi. Record again once connected.");
  const uint32_t clockStarted=millis();
  while(ServerTransport::kSecure && time(nullptr)<1735689600) {
    if(uint32_t(millis()-clockStarted)>=12000) return fail("Wait for the clock, then record again.");
    delay(30);
  }
  const size_t bytes=AudioFile::pendingBytes();
  if(!bytes) return fail("Could not read the audio. Record again.");
  FILE* file=fopen(AudioFile::kPendingPath,"rb");
  if(!file) return fail("Could not open the saved recording.");
  struct Close {
    FILE* file;
    void now() { if(file) { fclose(file); file=nullptr; } }
    ~Close() { now(); }
  } close{file};
  RecordingIdentity identity;
  if(!Detail::prepareIdentity(file,bytes,reservedNoteId,identity))
    return fail("Could not verify the recording ID. Record again.");
  strcpy(reply.jobId,identity.jobId);
  char url[256];
  const int urlBytes=snprintf(url,sizeof url,"%s/api/core/voice/%s",ServerConfig::kBaseUrl,identity.jobId);
  if(urlBytes<=0 || size_t(urlBytes)>=sizeof url) return fail("Invalid kibi Core address. Check settings.");
  BoundedText scratch;
  if(!scratch.reserve(Detail::kMaximumResponseBytes+1)) return fail("Not enough memory for the kibi Core response.");
  Https::PsramJsonAllocator allocator; JsonDocument response(&allocator);
  // Never re-upload on timeout/error: the server may already have accepted it.
  // Only status GETs below may repeat, always for this same job identity.
  const auto uploaded=Detail::request(url,identity,file,90000,scratch.data(),scratch.capacity(),response);
  // The server owns its accepted copy; no WAV is needed to receive a result.
  // Also discard an ambiguous upload. Only GET may retry after this point.
  close.now();
  if(!AudioFile::acknowledgeSaved()) Serial.println("[AI] Uploaded audio cleanup pending; final attempt cleanup will retry");
  if(!canPollAfterUpload(uploaded.status,uploaded.valid))
    return Detail::httpFailure(uploaded.status,error,errorCapacity);
  if(!uploaded.valid) {
    response.clear(); response["job_id"]=identity.jobId; response["status"]="queued";
  }
  const uint32_t pollingStarted=millis();
  for(;;) {
    const auto result=parseResult(response.as<JsonVariantConst>(),identity.jobId,transcript,transcriptCapacity,reply,error,errorCapacity);
    if(result==Result::Complete || result==Result::Unavailable) return true;
    if(result!=Result::Pending) return false;
    uint32_t remaining=pollRemaining(pollingStarted,millis());
    if(remaining<1500) break;
    delay(1500); remaining=pollRemaining(pollingStarted,millis());
    const auto polled=Detail::request(url,identity,nullptr,remaining,scratch.data(),scratch.capacity(),response);
    if(polled.valid) continue;
    if(!retryableHttp(polled.status)) return Detail::httpFailure(polled.status,error,errorCapacity);
    // Keep a valid pending document between transient GET failures.
    response.clear(); response["job_id"]=identity.jobId; response["status"]="retry";
  }
  return fail("Still processing. The result will arrive as a notification. Audio deleted.");
}
} // namespace Tamagotchi::CloudVoice
#endif
