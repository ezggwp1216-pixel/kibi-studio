#pragma once

#include <ArduinoJson.h>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <initializer_list>
#ifdef ARDUINO
#include "http_json.h"
#endif

namespace Tamagotchi { namespace Weather {

struct WeatherRequest {
  char city[96];
  char country[3];
  int dayOffset;
  char targetDate[11]{}; // Optional ISO date; resolved against the destination's local date.
};
struct WeatherReply { char text[1400]; char source[96]; };
struct WeatherLocation { char name[96]; char country[3]; double latitude; double longitude; };

inline bool fail(char* error,size_t capacity,const char* reason) {
  if(error && capacity) {
    size_t length=std::strlen(reason);
    if(length>=capacity) {
      length=capacity-1;
      while(length && (uint8_t(reason[length])&0xC0)==0x80) --length;
    }
    std::memcpy(error,reason,length); error[length]=0;
  }
  return false;
}
inline size_t boundedLength(const char* text,size_t capacity) {
  if(!text) return capacity;
  size_t length=0;
  while(length<capacity && text[length]) ++length;
  return length;
}
// Reject malformed UTF-8 and control characters before city names enter a URL or reply.
inline bool validText(const char* text,size_t capacity) {
  const size_t length=boundedLength(text,capacity);
  if(!length || length>=capacity) return false;
  for(size_t i=0;i<length;) {
    const uint8_t lead=uint8_t(text[i++]);
    if(lead<0x80) { if(lead<0x20 || lead==0x7F) return false; continue; }
    unsigned count=0; uint32_t point=0,minimum=0;
    if(lead>=0xC2 && lead<=0xDF) { count=1; point=lead&0x1F; minimum=0x80; }
    else if(lead>=0xE0 && lead<=0xEF) { count=2; point=lead&0x0F; minimum=0x800; }
    else if(lead>=0xF0 && lead<=0xF4) { count=3; point=lead&7; minimum=0x10000; }
    else return false;
    if(count>length-i) return false;
    while(count--) {
      const uint8_t next=uint8_t(text[i++]);
      if((next&0xC0)!=0x80) return false;
      point=(point<<6)|(next&0x3F);
    }
    if(point<minimum || point>0x10FFFF || (point>=0xD800 && point<=0xDFFF) ||
       (point>=0x80 && point<=0x9F) || point==0x2028 || point==0x2029) return false;
  }
  return true;
}
inline char upperAscii(char c) { return c>='a' && c<='z'?char(c-'a'+'A'):c; }
inline bool countryCode(const char* country,char (&out)[3],bool allowEmpty) {
  const size_t length=boundedLength(country,3);
  if(!length && allowEmpty) { out[0]=0; return true; }
  if(length!=2) return false;
  for(size_t i=0;i<2;++i) {
    out[i]=upperAscii(country[i]);
    if(out[i]<'A' || out[i]>'Z') return false;
  }
  out[2]=0; return true;
}
inline bool sameName(const char* left,const char* right) {
  // The voice router supplies English city names; spaces and ASCII case are immaterial.
  while(true) {
    while(*left==' ') ++left;
    while(*right==' ') ++right;
    if(upperAscii(*left)!=upperAscii(*right)) return false;
    if(!*left) return true;
    ++left; ++right;
  }
}
inline const char* searchName(const char* city) {
  // GeoNames indexes this city as Qui Nhon. Never substitute an unrelated default city.
  if(sameName(city,"Quy Nhon") || sameName(city,"Qui Nhon") ||
     !std::strcmp(city,"Куинён") || !std::strcmp(city,"Куйнён")) return "Qui Nhon";
  return city;
}
inline bool dateNumber(const char* text,int& serial) {
  if(!text) return false;
  for(int i=0;i<10;++i) {
    if(i==4 || i==7) { if(text[i]!='-') return false; }
    else if(text[i]<'0' || text[i]>'9') return false;
  }
  const int year=(text[0]-'0')*1000+(text[1]-'0')*100+(text[2]-'0')*10+text[3]-'0';
  const int month=(text[5]-'0')*10+text[6]-'0',day=(text[8]-'0')*10+text[9]-'0';
  if(year<1970 || year>2199 || month<1 || month>12) return false;
  const bool leap=year%4==0 && (year%100!=0 || year%400==0);
  static const uint8_t days[]={31,28,31,30,31,30,31,31,30,31,30,31};
  if(day<1 || day>days[month-1]+(month==2 && leap)) return false;
  const int prior=year-1;
  serial=(year-1970)*365+(prior/4-1969/4)-(prior/100-1969/100)+(prior/400-1969/400)+day-1;
  for(int i=1;i<month;++i) serial+=days[i-1]+(i==2 && leap);
  return true;
}
inline bool validateRequest(const WeatherRequest& request,char* error,size_t capacity) {
  char country[3];
  if(!validText(request.city,sizeof request.city) || boundedLength(request.city,sizeof request.city)<2)
    return fail(error,capacity,"Specify the city name.");
  bool visible=false;
  for(const char* p=request.city;*p;++p) if(*p!=' ') visible=true;
  if(!visible) return fail(error,capacity,"Name a city.");
  if(!countryCode(request.country,country,true)) return fail(error,capacity,"Use a two-letter country code.");
  if(request.targetDate[0]) {
    int serial;
    if(boundedLength(request.targetDate,sizeof request.targetDate)!=10 || !dateNumber(request.targetDate,serial))
      return fail(error,capacity,"Invalid forecast date. Use a valid YYYY-MM-DD date.");
  } else if(request.dayOffset<0 || request.dayOffset>6)
    return fail(error,capacity,"Forecasts cover today and the next six days.");
  return true;
}
inline bool encodeQuery(const char* text,char* out,size_t capacity) {
  if(!out || !capacity) return false;
  size_t used=0; out[0]=0;
  static const char hex[]="0123456789ABCDEF";
  for(const uint8_t* p=reinterpret_cast<const uint8_t*>(text);*p;++p) {
    const bool plain=(*p>='a' && *p<='z') || (*p>='A' && *p<='Z') ||
        (*p>='0' && *p<='9') || *p=='-' || *p=='_' || *p=='.' || *p=='~';
    const size_t need=plain?1:3;
    if(used+need>=capacity) { out[0]=0; return false; }
    if(plain) out[used++]=char(*p);
    else { out[used++]='%'; out[used++]=hex[*p>>4]; out[used++]=hex[*p&15]; }
  }
  out[used]=0; return true;
}
inline bool makeGeocodingUrl(const WeatherRequest& request,char* out,size_t capacity,char* error,size_t errorCapacity) {
  if(out && capacity) out[0]=0;
  if(!validateRequest(request,error,errorCapacity)) return false;
  char encoded[3*95+1],country[3];
  if(!encodeQuery(searchName(request.city),encoded,sizeof encoded) || !out || !capacity)
    return fail(error,errorCapacity,"The city name is too long.");
  countryCode(request.country,country,true);
  const int length=std::snprintf(out,capacity,
      "https://geocoding-api.open-meteo.com/v1/search?name=%s&count=10&language=en&format=json%s%s",
      encoded,country[0]?"&countryCode=":"",country);
  if(length<0 || size_t(length)>=capacity) { out[0]=0; return fail(error,errorCapacity,"The city name is too long."); }
  return true;
}
inline bool number(JsonVariantConst value,double low,double high,double& out) {
  if(!value.is<double>() || value.is<bool>()) return false;
  out=value.as<double>();
  return std::isfinite(out) && out>=low && out<=high;
}
inline bool parseLocation(JsonVariantConst document,const WeatherRequest& request,WeatherLocation& out,
                          char* error,size_t capacity) {
  out=WeatherLocation{};
  if(!validateRequest(request,error,capacity)) return false;
  if(!document.is<JsonObjectConst>() || document["error"].as<bool>()) return fail(error,capacity,"Could not find the city.");
  const JsonArrayConst results=document["results"].as<JsonArrayConst>();
  if(results.isNull() || !results.size()) return fail(error,capacity,"City not found. Specify its name and country.");
  if(results.size()>10) return fail(error,capacity,"Too many matches. Specify the city and country.");
  char expectedCountry[3];
  countryCode(request.country,expectedCountry,true);
  size_t matches=0;
  for(JsonObjectConst result:results) {
    const char* name=result["name"].as<const char*>();
    const char* country=result["country_code"].as<const char*>();
    char actualCountry[3]; double latitude,longitude;
    if(!validText(name,sizeof out.name) || !countryCode(country,actualCountry,false) ||
       !number(result["latitude"],-90,90,latitude) || !number(result["longitude"],-180,180,longitude))
      return fail(error,capacity,"The service returned invalid city data.");
    if((expectedCountry[0] && std::strcmp(actualCountry,expectedCountry)) || !sameName(name,searchName(request.city))) continue;
    if(++matches>1) { out=WeatherLocation{}; return fail(error,capacity,"Several cities match. Specify the country or region."); }
    std::strcpy(out.name,name); std::strcpy(out.country,actualCountry);
    out.latitude=latitude; out.longitude=longitude;
  }
  if(!matches) return fail(error,capacity,"No exact match. Specify the city and country.");
  return true;
}
inline bool makeForecastUrl(const WeatherLocation& location,char* out,size_t capacity,char* error,size_t errorCapacity,
                            bool secure=true) {
  if(!out || !capacity) return fail(error,errorCapacity,"The weather request is too long.");
  out[0]=0;
  if(!std::isfinite(location.latitude) || !std::isfinite(location.longitude) ||
     location.latitude<-90 || location.latitude>90 || location.longitude<-180 || location.longitude>180)
    return fail(error,errorCapacity,"Invalid city coordinates.");
  const int length=std::snprintf(out,capacity,
      "%s://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f"
      "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
      "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
      "&temperature_unit=celsius&wind_speed_unit=kmh&timezone=auto&forecast_days=7",
      secure?"https":"http",location.latitude,location.longitude);
  if(length<0 || size_t(length)>=capacity) { out[0]=0; return fail(error,errorCapacity,"The weather request is too long."); }
  return true;
}
inline bool localTime(const char* text,int& serial) {
  if(boundedLength(text,17)!=16 || !dateNumber(text,serial) || text[10]!='T' || text[13]!=':') return false;
  for(int i:{11,12,14,15}) if(text[i]<'0' || text[i]>'9') return false;
  return (text[11]-'0')*10+text[12]-'0'<24 && (text[14]-'0')*10+text[15]-'0'<60;
}
inline bool validateForecastTime(JsonVariantConst document,int64_t now,char* error,size_t capacity) {
  const char* timestamp=document["current"]["time"].as<const char*>();
  int serial; double offset;
  if(!localTime(timestamp,serial) || !number(document["utc_offset_seconds"],-50400,50400,offset) ||
     std::floor(offset)!=offset) return fail(error,capacity,"The weather service returned an invalid local time.");
  if(now<1577836800) return fail(error,capacity,"Wait for the device clock before requesting a forecast.");
  const int64_t local=int64_t(serial)*86400+((timestamp[11]-'0')*10+timestamp[12]-'0')*3600+
      ((timestamp[14]-'0')*10+timestamp[15]-'0')*60;
  const int64_t age=now-(local-int64_t(offset));
  if(age>7200 || age< -1800) return fail(error,capacity,"Weather data is outdated. Try again later.");
  return true;
}
inline bool unit(JsonVariantConst units,const char* key,const char* expected) {
  const char* actual=units[key].as<const char*>();
  return actual && !std::strcmp(actual,expected);
}
inline const char* condition(int code) {
  switch(code) {
    case 0:return "clear"; case 1:return "mainly clear"; case 2:return "partly cloudy";
    case 3:return "overcast"; case 45:return "fog"; case 48:return "rime fog";
    case 51:return "light drizzle"; case 53:return "drizzle"; case 55:return "heavy drizzle";
    case 56:return "light freezing drizzle"; case 57:return "heavy freezing drizzle";
    case 61:return "light rain"; case 63:return "rain"; case 65:return "heavy rain";
    case 66:return "light freezing rain"; case 67:return "heavy freezing rain";
    case 71:return "light snow"; case 73:return "snow"; case 75:return "heavy snow";
    case 77:return "snow grains"; case 80:return "light showers"; case 81:return "showers";
    case 82:return "heavy showers"; case 85:return "light snow showers"; case 86:return "heavy snow showers";
    case 95:return "thunderstorm"; case 96:return "thunderstorm with light hail"; case 97:return "heavy thunderstorm";
    case 99:return "thunderstorm with heavy hail"; default:return nullptr;
  }
}
inline bool weatherCode(JsonVariantConst value,int& out) {
  double code;
  if(!number(value,0,99,code) || std::floor(code)!=code || !condition(int(code))) return false;
  out=int(code); return true;
}
inline bool formatForecast(JsonVariantConst document,const WeatherRequest& request,const WeatherLocation& location,
                           WeatherReply& reply,char* error,size_t capacity) {
  reply=WeatherReply{};
  if(!validateRequest(request,error,capacity)) return false;
  char country[3];
  if(!validText(location.name,sizeof location.name) || !countryCode(location.country,country,false))
    return fail(error,capacity,"Invalid city data.");
  if(!document.is<JsonObjectConst>() || document["error"].as<bool>()) return fail(error,capacity,"The weather service returned an error.");
  double latitude,longitude;
  if(!number(document["latitude"],-90,90,latitude) || !number(document["longitude"],-180,180,longitude))
    return fail(error,capacity,"The weather service returned invalid coordinates.");
  const JsonVariantConst current=document["current"],daily=document["daily"];
  const JsonVariantConst currentUnits=document["current_units"],dailyUnits=document["daily_units"];
  const char* timestamp=current["time"].as<const char*>();
  const char* timezone=document["timezone"].as<const char*>();
  int today;
  double offset;
  if(!localTime(timestamp,today) || !validText(timezone,64) ||
     !number(document["utc_offset_seconds"],-50400,50400,offset) || std::floor(offset)!=offset)
    return fail(error,capacity,"The weather service returned an invalid local time.");
  if(!unit(currentUnits,"time","iso8601") || !unit(dailyUnits,"time","iso8601") ||
     !unit(dailyUnits,"temperature_2m_min","°C") || !unit(dailyUnits,"temperature_2m_max","°C") ||
     !unit(dailyUnits,"precipitation_probability_max","%") || !unit(dailyUnits,"weather_code","wmo code"))
    return fail(error,capacity,"The weather service returned unknown units.");
  for(const char* key:{"time","weather_code","temperature_2m_min","temperature_2m_max","precipitation_probability_max"})
    if(!daily[key].is<JsonArrayConst>() || daily[key].size()!=7)
      return fail(error,capacity,"The seven-day forecast is incomplete.");
  for(int i=0;i<7;++i) {
    const char* date=daily["time"][i].as<const char*>(); int serial;
    if(boundedLength(date,11)!=10 || !dateNumber(date,serial) || serial!=today+i)
      return fail(error,capacity,"Forecast dates do not match the requested period.");
  }
  int day=request.dayOffset;
  if(request.targetDate[0]) {
    int requested=0;
    dateNumber(request.targetDate,requested); // Already validated before reading the response.
    day=requested-today;
    if(day<0 || day>6)
      return fail(error,capacity,"This city's forecast covers today and the next six days. Specify a date.");
  }
  double low,high,probability;
  int dailyCode;
  if(!number(daily["temperature_2m_min"][day],-100,70,low) ||
     !number(daily["temperature_2m_max"][day],-100,70,high) || low>high ||
     !number(daily["precipitation_probability_max"][day],0,100,probability) ||
     !weatherCode(daily["weather_code"][day],dailyCode))
    return fail(error,capacity,"The forecast has no valid readings.");
  const char* date=daily["time"][day].as<const char*>();
  int length;
  if(day==0) {
    double temperature,apparent,wind; int currentCode;
    if(!unit(currentUnits,"temperature_2m","°C") || !unit(currentUnits,"apparent_temperature","°C") ||
       !unit(currentUnits,"weather_code","wmo code") || !unit(currentUnits,"wind_speed_10m","km/h"))
      return fail(error,capacity,"Unknown current weather units.");
    if(!number(current["temperature_2m"],-100,70,temperature) ||
       !number(current["apparent_temperature"],-150,100,apparent) ||
       !number(current["wind_speed_10m"],0,500,wind) || !weatherCode(current["weather_code"],currentCode))
      return fail(error,capacity,"Current weather data is incomplete or invalid.");
    length=std::snprintf(reply.text,sizeof reply.text,
        "%s, %s — today, %s.\nNow: %s, %.1f °C; feels %.1f °C; wind %.1f km/h.\n"
        "Today: %.1f…%.1f °C; precipitation chance up to %.0f%%.\n"
        "As of %.10s %.5s (%s).\nSource: Open-Meteo; GeoNames.",
        location.name,country,date,condition(currentCode),temperature,apparent,wind,low,high,probability,
        timestamp,timestamp+11,timezone);
  } else {
    length=std::snprintf(reply.text,sizeof reply.text,
        "%s, %s — %s%s.\nForecast: %s, %.1f…%.1f °C; precipitation chance up to %.0f%%.\n"
        "Current data as of %.10s %.5s (%s).\nSource: Open-Meteo; GeoNames.",
        location.name,country,day==1?"tomorrow, ":"",date,condition(dailyCode),low,high,probability,
        timestamp,timestamp+11,timezone);
  }
  if(length<0 || size_t(length)>=sizeof reply.text) {
    reply=WeatherReply{}; return fail(error,capacity,"The weather response is too long.");
  }
  std::strcpy(reply.source,"Open-Meteo (weather); GeoNames (city)");
  return true;
}

inline bool fetchWeather(const WeatherRequest& request,WeatherReply& reply,char* error,size_t capacity) {
  reply=WeatherReply{};
  if(error && capacity) error[0]=0;
  if(!validateRequest(request,error,capacity)) return false;
#ifdef ARDUINO
  char url[768];
  WeatherLocation location{};
  JsonDocument document,filter;
  for(const char* key:{"name","latitude","longitude","country_code"}) filter["results"][0][key]=true;
  filter["error"]=true;
  if(filter.overflowed()) return fail(error,capacity,"Not enough memory to find the city.");
  if(!makeGeocodingUrl(request,url,sizeof url,error,capacity) ||
     !Tamagotchi::Https::getJson(url,document,filter,error,capacity) ||
     !parseLocation(document.as<JsonVariantConst>(),request,location,error,capacity)) return false;
  document.clear(); filter.clear();
  filter["error"]=true; filter["timezone"]=true; filter["utc_offset_seconds"]=true;
  filter["latitude"]=true; filter["longitude"]=true;
  for(const char* key:{"time","temperature_2m","apparent_temperature","weather_code","wind_speed_10m"}) {
    filter["current"][key]=true; filter["current_units"][key]=true;
  }
  for(const char* key:{"time","weather_code","temperature_2m_min","temperature_2m_max","precipitation_probability_max"}) {
    filter["daily"][key]=true; filter["daily_units"][key]=true;
  }
  if(filter.overflowed()) return fail(error,capacity,"Not enough memory for the weather request.");
  return makeForecastUrl(location,url,sizeof url,error,capacity) &&
      Tamagotchi::Https::getJson(url,document,filter,error,capacity) &&
      validateForecastTime(document.as<JsonVariantConst>(),int64_t(std::time(nullptr)),error,capacity) &&
      formatForecast(document.as<JsonVariantConst>(),request,location,reply,error,capacity);
#else
  return fail(error,capacity,"Weather requests are available on the device.");
#endif
}

}} // namespace Tamagotchi::Weather
