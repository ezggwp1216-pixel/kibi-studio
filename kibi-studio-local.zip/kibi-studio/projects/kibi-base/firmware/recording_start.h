#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace Tamagotchi {
enum class RecordingAttemptStatus { Complete,Cancelled,PreparationFailed,InsufficientCapacity,CaptureFailed };

// All filesystem preparation belongs to the voice worker. Re-check release at
// every yielding boundary so a notified, cancelled attempt never opens capture.
template<class Cancelled,class Prepare,class HasCapacity,class Capture>
RecordingAttemptStatus runPreparedRecordingAttempt(size_t requiredBytes,Cancelled cancelled,
                                                   Prepare prepare,HasCapacity hasCapacity,Capture capture) {
  if(cancelled()) return RecordingAttemptStatus::Cancelled;
  const bool prepared=prepare(requiredBytes);
  if(cancelled()) return RecordingAttemptStatus::Cancelled;
  if(!prepared) return RecordingAttemptStatus::PreparationFailed;
  const bool fits=hasCapacity(requiredBytes);
  if(cancelled()) return RecordingAttemptStatus::Cancelled;
  if(!fits) return RecordingAttemptStatus::InsufficientCapacity;
  return capture()?RecordingAttemptStatus::Complete:RecordingAttemptStatus::CaptureFailed;
}

enum class RecordingStartStage : uint8_t { Idle,Requested,Worker,Preflight,Ready,LivePcm,Cancelled,Failed };
struct RecordingStartTiming { uint32_t lastUs=0,count=0,maxUs=0; };
struct RecordingStartSnapshot {
  RecordingStartStage stage=RecordingStartStage::Idle;
  uint32_t attempts=0;
  RecordingStartTiming requestToWorker,preflight,workerToFirstPcm,requestToFirstPcm;
};

// The main loop starts an attempt only after the previous worker has finished;
// that worker alone advances it. Snapshot fields are individually atomic and
// never wait, allocate, or retain audio/text. Last values reset per attempt;
// count and maximum accumulate for this boot, including failed preflights.
class RecordingStartDiagnostics {
 public:
  void requested(uint32_t now) {
    requestAt_.store(now,std::memory_order_relaxed);
    requestToWorker_.resetLast(); preflight_.resetLast();
    workerToFirstPcm_.resetLast(); requestToFirstPcm_.resetLast();
    attempts_.fetch_add(1,std::memory_order_relaxed);
    stage_.store(RecordingStartStage::Requested,std::memory_order_release);
  }
  void workerStarted(uint32_t now) {
    if(stage_.load(std::memory_order_acquire)!=RecordingStartStage::Requested) return;
    workerAt_.store(now,std::memory_order_relaxed);
    requestToWorker_.observe(uint32_t(now-requestAt_.load(std::memory_order_relaxed)));
    stage_.store(RecordingStartStage::Worker,std::memory_order_release);
  }
  void preflightStarted(uint32_t now) {
    if(stage_.load(std::memory_order_acquire)!=RecordingStartStage::Worker) return;
    preflightAt_.store(now,std::memory_order_relaxed);
    stage_.store(RecordingStartStage::Preflight,std::memory_order_release);
  }
  void preflightFinished(uint32_t now) {
    if(stage_.load(std::memory_order_acquire)!=RecordingStartStage::Preflight) return;
    preflight_.observe(uint32_t(now-preflightAt_.load(std::memory_order_relaxed)));
    stage_.store(RecordingStartStage::Ready,std::memory_order_release);
  }
  void firstLivePcm(uint32_t now) {
    if(stage_.load(std::memory_order_acquire)!=RecordingStartStage::Ready) return;
    workerToFirstPcm_.observe(uint32_t(now-workerAt_.load(std::memory_order_relaxed)));
    requestToFirstPcm_.observe(uint32_t(now-requestAt_.load(std::memory_order_relaxed)));
    stage_.store(RecordingStartStage::LivePcm,std::memory_order_release);
  }
  void abort(RecordingStartStage stage) {
    if(stage==RecordingStartStage::Cancelled || stage==RecordingStartStage::Failed)
      stage_.store(stage,std::memory_order_release);
  }
  RecordingStartSnapshot snapshot() const {
    return {stage_.load(std::memory_order_acquire),attempts_.load(std::memory_order_relaxed),
            requestToWorker_.snapshot(),preflight_.snapshot(),workerToFirstPcm_.snapshot(),requestToFirstPcm_.snapshot()};
  }
 private:
  struct Timing {
    std::atomic<uint32_t> lastUs{0},count{0},maxUs{0};
    void resetLast() { lastUs.store(0,std::memory_order_relaxed); }
    void observe(uint32_t elapsed) {
      lastUs.store(elapsed,std::memory_order_relaxed);
      count.fetch_add(1,std::memory_order_relaxed);
      if(elapsed>maxUs.load(std::memory_order_relaxed)) maxUs.store(elapsed,std::memory_order_relaxed);
    }
    RecordingStartTiming snapshot() const {
      return {lastUs.load(std::memory_order_relaxed),count.load(std::memory_order_relaxed),maxUs.load(std::memory_order_relaxed)};
    }
  } requestToWorker_,preflight_,workerToFirstPcm_,requestToFirstPcm_;
  std::atomic<RecordingStartStage> stage_{RecordingStartStage::Idle};
  std::atomic<uint32_t> attempts_{0},requestAt_{0},workerAt_{0},preflightAt_{0};
};
} // namespace Tamagotchi
