#pragma once
#include "device_inbox.h"
#include "notifications.h"
#include <cstdint>

namespace Tamagotchi::DevicePoll {
inline bool routineNeeded(bool hintsKnown,uint32_t advertised,uint32_t applied,bool deletions,
                          uint32_t last,uint32_t now) {
  return !hintsKnown || advertised!=applied || deletions || uint32_t(now-last)>=300000u;
}
class Schedule {
 public:
  void requestRefresh() { refreshPending_=true; }
  bool pollDue(uint32_t now,bool idle,bool allowed) {
    (void)idle;
    const uint32_t interval=refreshPending_?10000u:60000u;
    if(!allowed || (pollStarted_ && uint32_t(now-pollAt_)<interval)) return false;
    refreshPending_=false;
    pollAt_=now;pollStarted_=true;return true;
  }
  void unsupported(uint32_t now) { unsupported_=true;unsupportedAt_=now; }
  void supported() { unsupported_=false; }
  bool legacy(uint32_t now) const { return unsupported_ && uint32_t(now-unsupportedAt_)<300000u; }
  bool maintenanceDue(uint32_t now,bool idle,bool allowed) {
    if(idle) { maintenanceIdle_=true;return false; }
    if(!allowed || (!maintenanceIdle_ && maintenanceStarted_ && uint32_t(now-maintenanceAt_)<10000u)) return false;
    maintenanceIdle_=false;maintenanceStarted_=true;maintenanceAt_=now;return true;
  }
  bool writesDue(uint32_t now,bool pending,bool allowed) {
    if(!allowed || !pending || (writesStarted_ && uint32_t(now-writesAt_)<10000u)) return false;
    writesStarted_=true;writesAt_=now;return true;
  }
  uint32_t waitMilliseconds(uint32_t now,bool idle,bool pending,bool allowed) const {
    if(!idle) return 200;
    // Busy/connectivity transitions explicitly notify the worker. No polling
    // wake every second is needed while another owner is using the radio.
    if(!allowed) return 60000;
    uint32_t wait=remaining(now,pollAt_,refreshPending_?10000u:60000u,pollStarted_);
    if(pending) {
      const uint32_t writes=remaining(now,writesAt_,10000,writesStarted_);
      if(writes<wait) wait=writes;
    }
    return wait;
  }
 private:
  static uint32_t remaining(uint32_t now,uint32_t at,uint32_t interval,bool started) {
    const uint32_t elapsed=uint32_t(now-at);
    return !started || elapsed>=interval?1:interval-elapsed;
  }
  uint32_t pollAt_=0,unsupportedAt_=0,maintenanceAt_=0,writesAt_=0;
  bool pollStarted_=false,unsupported_=false,maintenanceStarted_=false,maintenanceIdle_=true,writesStarted_=false,refreshPending_=false;
};
struct Ack {
  char id[33]{};bool confirmed=false;
  bool matches(const char* requested) const { return confirmed && requested && *requested && !strcmp(id,requested); }
};
struct Response {
  uint32_t epoch=0,publishedVersion=0;
  bool deletionsPending=false,haveCore=false,haveReminder=false;
  Ack coreAck,reminderAck;
};
inline bool parseAck(JsonVariantConst value,bool core,Ack& result) {
  result=Ack{};
  if(value.isNull()) return true;
  const char *id,*status;
  if(!value.is<JsonObjectConst>() || value.size()!=2 ||
     !Inbox::stringField(value,"id",core?33:20,id) ||
     !(core?Inbox::lowerHex(id,32):Notifications::validId(id)) ||
     !Inbox::stringField(value,"status",16,status)) return false;
  if(!strcmp(status,"acknowledged")) result.confirmed=true;
  // A missing Core receipt has the same semantics as the old ACK endpoint's
  // 404. A reminder never offered to this device remains pending locally.
  else if(!strcmp(status,core?"not_found":"not_offered")) result.confirmed=core;
  else return false;
  strcpy(result.id,id);return true;
}
inline bool parse(JsonVariantConst value,Response& result,Inbox::Delivery& core,Notifications::Delivery& reminder) {
  if(!value.is<JsonObjectConst>() || (value.size()!=8 && value.size()!=9)) return false;
  for(const auto field:{"version","server_time","core_delivery","reminder_delivery","core_ack","reminder_ack",
                        "published_version","deletions_pending"}) if(value[field].isUnbound()) return false;
  if(value.size()==9 && value["food_today"].isUnbound()) return false;
  if(!value["version"].is<unsigned>() || value["version"].is<bool>() || value["version"].as<unsigned>()!=1 ||
     !value["server_time"].is<uint32_t>() || value["server_time"].is<bool>() ||
     !value["published_version"].is<uint32_t>() || value["published_version"].is<bool>() ||
     !value["deletions_pending"].is<bool>()) return false;
  Response next;
  next.epoch=value["server_time"].as<uint32_t>();
  if(next.epoch<1704067200u || next.epoch>4102444800u) return false;
  next.publishedVersion=value["published_version"].as<uint32_t>();
  next.deletionsPending=value["deletions_pending"].as<bool>();
  if(!parseAck(value["core_ack"],true,next.coreAck) || !parseAck(value["reminder_ack"],false,next.reminderAck)) return false;
  next.haveCore=!value["core_delivery"].isNull();next.haveReminder=!value["reminder_delivery"].isNull();
  if((next.haveCore && !Inbox::parse(value["core_delivery"],core)) ||
     (next.haveReminder && !Notifications::parse(value["reminder_delivery"],reminder))) return false;
  result=next;return true;
}
} // namespace Tamagotchi::DevicePoll
