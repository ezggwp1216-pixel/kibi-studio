#pragma once
#include "server_endpoint.h"

#ifdef ARDUINO
#include "http_json.h"
#include "server_config.h"

namespace Tamagotchi::ServerTransport {
inline constexpr bool kSecure=usesTls(ServerConfig::kBaseUrl);
using Client=ClientFor<kSecure,Https::PlainDeadlineClient,Https::DeadlineClient>;

// The WS owner already holds the network gate and has its own phase deadlines.
// Only a TLS transport enters TLS diagnostics or lowers priority for a handshake.
template<class Transport,bool Secure> class BasicSocket final : public Transport {
 public:
  ~BasicSocket() override { stop(); }
  int connect(IPAddress ip,uint16_t port) override {
    return observedConnect([&] { return Transport::connect(ip,port); });
  }
  int connect(IPAddress ip,uint16_t port,int32_t timeout) override {
    return observedConnect([&] { return Transport::connect(ip,port,timeout); });
  }
  int connect(const char* host,uint16_t port) override {
    return observedConnect([&] { return Transport::connect(host,port); });
  }
  int connect(const char* host,uint16_t port,int32_t timeout) override {
    return observedConnect([&] { return Transport::connect(host,port,timeout); });
  }
  void stop() override {
    if constexpr(Secure) {
      TlsDiagnostics::Context::Closing closing(tlsDiagnostics_);
      Transport::stop();
    } else Transport::stop();
  }
  void ioTimeout(uint32_t milliseconds) {
    configureIoTimeout(static_cast<Transport&>(*this),milliseconds);
    if constexpr(Secure) this->sslclient->socket_timeout=milliseconds;
  }
  void setCACert(const char* ca) { if constexpr(Secure) Transport::setCACert(ca); }
  void useBuiltinCACertBundle() { if constexpr(Secure) Transport::useBuiltinCACertBundle(); }
  void setHandshakeTimeout(unsigned long seconds) { if constexpr(Secure) Transport::setHandshakeTimeout(seconds); }
  int lastError(char* buffer,size_t capacity) {
    if constexpr(Secure) return Transport::lastError(buffer,capacity);
    else { if(capacity) buffer[0]=0; return 0; }
  }
 private:
  TlsDiagnostics::Context tlsDiagnostics_{TlsDiagnostics::tracker,TlsDiagnostics::clock,TlsDiagnostics::internalHeap};
  template<class Connect> int observedConnect(Connect connect) {
    if constexpr(Secure) {
      TlsDiagnostics::Context::Attempt attempt(tlsDiagnostics_);
      if(!attempt.outer()) { const int connected=connect(); attempt.finish(connected!=0); return connected; }
      NetworkGate::TlsHandshakeScope idle;
      const int connected=connect();
      attempt.finish(connected!=0);
      return connected;
    } else return finishPlainConnect(static_cast<Transport&>(*this),connect());
  }
};
using Socket=ClientFor<kSecure,BasicSocket<NetworkClient,false>,BasicSocket<NetworkClientSecure,true>>;
inline bool configured() {
  Endpoint endpoint;
  return parseEndpoint(ServerConfig::kBaseUrl,endpoint);
}
} // namespace Tamagotchi::ServerTransport
#endif
