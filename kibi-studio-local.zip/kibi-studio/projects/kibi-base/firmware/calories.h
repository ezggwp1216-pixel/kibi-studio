#pragma once

#include <ArduinoJson.h>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>

namespace Tamagotchi::Calories {
constexpr size_t kTextBytes=1800;
constexpr uint32_t kFreshCacheMs=10000;
enum class Status { Waiting,Loading,Ready,Error };
struct Summary {
  char date[11]{},text[kTextBytes+1]{};
  double totalKcal=0;
  uint32_t entryCount=0;
  bool estimated=false;
};
// The main kibi account uses UTC+7, matching its clock and daily totals.
inline bool today(int64_t epoch,char (&out)[11]) {
  out[0]=0;
  if(epoch<1704067200 || epoch>4102444800LL) return false;
  const time_t local=time_t(epoch+7*3600);
  tm parts{};
  return gmtime_r(&local,&parts) && std::strftime(out,sizeof out,"%Y-%m-%d",&parts)==10;
}
inline bool validText(const char* value,size_t bytes) {
  if(!value || !bytes || bytes>kTextBytes) return false;
  for(size_t at=0;at<bytes;) {
    const uint8_t lead=uint8_t(value[at]);
    if(lead<0x80) {
      if(lead<32 && lead!='\n' && lead!='\r' && lead!='\t') return false;
      if(lead==127) return false;
      ++at;continue;
    }
    const size_t length=lead>=0xc2 && lead<=0xdf?2:lead>=0xe0 && lead<=0xef?3:lead>=0xf0 && lead<=0xf4?4:0;
    if(!length || at+length>bytes) return false;
    const uint8_t second=uint8_t(value[at+1]);
    if((lead==0xe0 && second<0xa0) || (lead==0xed && second>=0xa0) ||
       (lead==0xf0 && second<0x90) || (lead==0xf4 && second>=0x90)) return false;
    for(size_t i=1;i<length;++i) if((uint8_t(value[at+i])&0xc0)!=0x80) return false;
    at+=length;
  }
  return value[bytes]==0;
}
inline bool parse(JsonVariantConst value,const char* expectedDate,Summary& out) {
  if(!value.is<JsonObjectConst>() || !expectedDate || std::strlen(expectedDate)!=10 ||
     !value["date"].is<const char*>() || !value["timezone"].is<const char*>() ||
     !value["text"].is<const char*>() || !value["estimated"].is<bool>() ||
     value["total_kcal"].is<bool>() || !value["total_kcal"].is<double>() ||
     value["entry_count"].is<bool>() || !value["entry_count"].is<uint32_t>()) return false;
  const auto date=value["date"].as<JsonString>(),zone=value["timezone"].as<JsonString>();
  const auto text=value["text"].as<JsonString>();
  const double total=value["total_kcal"].as<double>();
  if(date.size()!=10 || std::memcmp(date.c_str(),expectedDate,10) ||
     !zone.size() || zone.size()>64 || std::strlen(zone.c_str())!=zone.size() ||
     !validText(text.c_str(),text.size()) || !std::isfinite(total) || total<0 || total>1e9) return false;
  std::memcpy(out.date,date.c_str(),11);
  std::memcpy(out.text,text.c_str(),text.size()+1);
  out.totalKcal=total;out.estimated=value["estimated"].as<bool>();
  out.entryCount=value["entry_count"].as<uint32_t>();
  return true;
}
enum class Receipt { Missing,Invalid,Updated };
// The caller supplies time from an authenticated, validated envelope (for
// example DevicePoll::parse). Snapshot validation and cache safety stay shared.
inline Receipt parseSnapshot(uint32_t serverTime,JsonVariantConst snapshot,Summary& out) {
  char date[11];
  if(!today(serverTime,date)) return Receipt::Invalid;
  if(snapshot.isUnbound()) return Receipt::Missing;
  return parse(snapshot,date,out)?Receipt::Updated:Receipt::Invalid;
}
inline Receipt parseHeartbeat(JsonVariantConst value,Summary& out) {
  if(!value.is<JsonObjectConst>() || !value["ok"].is<bool>() || !value["ok"].as<bool>() ||
     value["server_time"].is<bool>() || !value["server_time"].is<uint32_t>()) return Receipt::Invalid;
  return parseSnapshot(value["server_time"].as<uint32_t>(),value["food_today"],out);
}
inline bool current(const Summary* summary,int64_t epoch,bool trusted) {
  char date[11];
  return trusted && today(epoch,date) && summary && summary->text[0] && !std::strcmp(date,summary->date);
}
// Opening a warm cache needs no request. A cold/stale page can only bring the
// normal heartbeat forward; calories never own a separate TLS transaction.
inline bool needsHeartbeat(const Summary* summary,uint32_t receivedAt,uint32_t now,int64_t epoch,bool trusted) {
  return !current(summary,epoch,trusted) || uint32_t(now-receivedAt)>=kFreshCacheMs;
}
inline bool refreshSatisfied(const Summary* summary,int64_t epoch,bool trusted) {
  return summary && summary->text[0] && (!trusted || current(summary,epoch,true));
}
inline bool format(const Summary* summary,Status status,int64_t epoch,bool trusted,bool online,
                   char* out,size_t capacity) {
  if(!out || !capacity) return false;
  out[0]=0;
  char date[11];
  const bool clock=trusted && today(epoch,date);
  const bool current=clock && summary && summary->text[0] && !std::strcmp(date,summary->date);
  const char* message="Loading today's calories…";
  if(!clock) message="Waiting for the clock.\n\nYour total will appear after connecting.";
  else if(!online) message=current?"\n\nNo Wi-Fi. Showing today's last saved total.":"Connect to Wi-Fi.\n\nYour calories will appear once connected.";
  else if(status==Status::Error) message=current?"\n\nCould not refresh.\nWill retry automatically.":"Could not refresh calories.\n\nWill retry automatically.";
  else if(current) message=status==Status::Loading?"\n\nRefreshing…":"";
  const int bytes=std::snprintf(out,capacity,"%s%s",current?summary->text:"",message);
  if(bytes<0 || size_t(bytes)>=capacity) { out[0]=0;return false; }
  return true;
}
} // namespace Tamagotchi::Calories
