#pragma once
#include "config.h"
#include "notifications.h"
#include "notes.h"
#include "device_inbox.h"
#include "device_poll.h"
#include "calories.h"
#include "recording_storage.h"
#include <ArduinoJson.h>
#include <atomic>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <new>

namespace Tamagotchi::ServerSync {
inline constexpr char kFilesystemPartitionLabel[]="spiffs";
enum class SyncEndpoint:uint32_t { Other,Heartbeat,Sync,Inbox,InboxAck,Reminder,ReminderAck,ReminderDue,Note,Asset,Poll };
enum class SyncRequestStage:uint32_t { Idle,Preparing,Transport,Headers,Body,Closing,Verifying,Complete,Failed,Skipped };
inline const char* syncEndpointName(SyncEndpoint endpoint) {
  constexpr const char* names[]={"other","heartbeat","sync","inbox","inbox-ack","reminder","reminder-ack","reminder-due","note","asset","poll"};
  const uint32_t index=uint32_t(endpoint); return index<11?names[index]:"other";
}
inline const char* syncStageName(SyncRequestStage stage) {
  constexpr const char* names[]={"idle","preparing","transport","headers","body","closing","verifying","complete","failed","skipped"};
  const uint32_t index=uint32_t(stage); return index<10?names[index]:"other";
}
inline SyncEndpoint syncEndpoint(const char* path) {
  if(!path) return SyncEndpoint::Other;
  if(!strcmp(path,"/api/core/device/poll")) return SyncEndpoint::Poll;
  if(!strcmp(path,"/api/device/heartbeat")) return SyncEndpoint::Heartbeat;
  if(!strncmp(path,"/api/device/sync?",17)) return SyncEndpoint::Sync;
  if(!strncmp(path,"/api/core/device/inbox/",23)) return SyncEndpoint::InboxAck;
  if(!strcmp(path,"/api/core/device/inbox")) return SyncEndpoint::Inbox;
  if(!strcmp(path,"/api/device/reminders/ack")) return SyncEndpoint::ReminderAck;
  if(!strcmp(path,"/api/device/reminders/due")) return SyncEndpoint::ReminderDue;
  if(!strncmp(path,"/api/device/reminders/",22)) return SyncEndpoint::Reminder;
  if(!strncmp(path,"/api/device/notes/",18)) return SyncEndpoint::Note;
  return SyncEndpoint::Other;
}
struct SyncRequestSnapshot {
  SyncEndpoint endpoint; SyncRequestStage stage;
  uint32_t startedAt,changedAt; int32_t status,tlsError;
};
// One worker writes these scalars; the UI may read an approximate snapshot
// without owning any filesystem/network mutex or allocating memory.
class SyncRequestTrace {
 public:
  void begin(SyncEndpoint endpoint,uint32_t now) {
    endpoint_.store(uint32_t(endpoint),std::memory_order_relaxed);
    startedAt_.store(now,std::memory_order_relaxed); status(0); tlsError_.store(0,std::memory_order_relaxed);
    phase(SyncRequestStage::Preparing,now);
  }
  void phase(SyncRequestStage stage,uint32_t now) {
    changedAt_.store(now,std::memory_order_relaxed); stage_.store(uint32_t(stage),std::memory_order_relaxed);
  }
  void status(int32_t value) { status_.store(value,std::memory_order_relaxed); }
  void finish(bool ok,int32_t statusValue,int32_t tlsError,uint32_t now) {
    status(statusValue); tlsError_.store(tlsError,std::memory_order_relaxed);
    phase(ok?SyncRequestStage::Complete:SyncRequestStage::Failed,now);
  }
  SyncRequestSnapshot snapshot() const {
    return {SyncEndpoint(endpoint_.load(std::memory_order_relaxed)),SyncRequestStage(stage_.load(std::memory_order_relaxed)),
      startedAt_.load(std::memory_order_relaxed),changedAt_.load(std::memory_order_relaxed),
      status_.load(std::memory_order_relaxed),tlsError_.load(std::memory_order_relaxed)};
  }
 private:
  std::atomic<uint32_t> endpoint_{0},stage_{0},startedAt_{0},changedAt_{0};
  std::atomic<int32_t> status_{0},tlsError_{0};
};
// Display telemetry reads one scalar without waiting for the filesystem mutex.
// A failed sample keeps the last trustworthy value; zero means a full volume.
class FilesystemFreeCache {
 public:
  bool accept(size_t total,size_t used) {
    if(!total || total>UINT32_MAX || used>total || total-used==UINT32_MAX) return false;
    free_.store(uint32_t(total-used),std::memory_order_relaxed);
    return true;
  }
  bool snapshot(uint32_t& bytes) const {
    const uint32_t value=free_.load(std::memory_order_relaxed);
    if(value==UINT32_MAX) return false;
    bytes=value;
    return true;
  }
 private:
  // ESP-IDF's -mdisable-hardware-atomics makes is_always_lock_free false for
  // read-modify-write operations. These relaxed, aligned 32-bit loads/stores
  // still compile to memw + l32i/s32i, without helper calls or a mutex.
  std::atomic<uint32_t> free_{UINT32_MAX};
};

inline void noteUploadTitle(const char* text,size_t bytes,char (&title)[kNoteTitleBytes]) {
  if(ShoppingNotes::body(text)) {
    NoteSummary summary; makeStoredNoteTitle(text,summary);
    strcpy(title,summary.title); return;
  }
  size_t titleBytes=bytes<sizeof title-1?bytes:sizeof title-1;
  while(titleBytes && (uint8_t(text[titleBytes])&0xc0)==0x80) --titleBytes;
  memcpy(title,text,titleBytes); title[titleBytes]=0;
  if(char* newline=strchr(title,'\n')) *newline=0;
}
constexpr int kMaxAssets = 11, kMaxAnimations = 9, kAnimationRoleCount=15;
struct Asset {
  char sha[65]{}, path[96]{};
  uint32_t size = 0;
  uint16_t width = 0, height = 0;
  bool jpeg = false;
};
struct Animation {
  char role[12]{};
  int asset = -1, intervalSeconds = 20, start = 1380, end = 420, priority = 50;
  bool enabled = true, repeat = false;
  uint8_t trigger = 0;
};
struct DesignSpec {
  uint32_t version = 0;
  Asset assets[kMaxAssets];
  Animation animations[kMaxAnimations];
  int assetCount = 0, animationCount = 0, background = -1, hero = -1;
  int characterYOffset = 0;
};
// Reset only the published extents. Asset/rule entries are fully initialized
// before their counts are incremented; this avoids a full DesignSpec temporary
// on the small Arduino loop stack.
inline void resetDesign(DesignSpec& spec) {
  spec.version = 0;
  spec.assetCount = 0;
  spec.animationCount = 0;
  spec.background = -1;
  spec.hero = -1;
  spec.characterYOffset = 0;
}
// The panel reports the current fault. A temporary offline/TLS failure must
// disappear after transport recovery without hiding a rejected design or bad
// credentials that still require a new successful application/configuration.
class SyncErrorState {
 public:
  const char* message() const { return text_; }
  void transient(const char* message) {
    if (!permanent_) copy(message);
  }
  void permanent(const char* message) {
    permanent_ = message && *message;
    copy(message);
  }
  void transportRecovered() {
    if (!permanent_) text_[0] = 0;
  }
  void applied(const char* message = nullptr) { permanent(message); }

 private:
  char text_[192]{};
  bool permanent_ = false;
  void copy(const char* message) {
    if (!message) {
      text_[0] = 0;
      return;
    }
    size_t used = 0;
    while (message[used] && used < sizeof(text_) - 1) {
      const uint8_t lead = uint8_t(message[used]);
      const size_t length = lead < 128 ? 1 :
          (lead >= 0xc2 && lead <= 0xdf ? 2 :
           (lead >= 0xe0 && lead <= 0xef ? 3 : (lead >= 0xf0 && lead <= 0xf4 ? 4 : 0)));
      if (!length || used + length >= sizeof text_) break;
      bool complete = true;
      for (size_t i = 1; i < length; ++i)
        if ((uint8_t(message[used + i]) & 0xc0) != 0x80) {
          complete = false;
          break;
        }
      if (!complete) break;
      used += length;
    }
    memcpy(text_, message, used);
    text_[used] = 0;
  }
};
// A percentage describes transferred graphics bytes, not a guessed duration.
// Verification and application are separate stages; only the main loop's
// successful commit acknowledgement is allowed to report 100 percent.
class DesignUpdateProgress {
 public:
  enum class Stage { Idle, Waiting, Downloading, Verifying, Applying, Complete, Error };
  void begin(const DesignSpec& spec, bool waiting = false) {
    version_ = spec.version;
    bytes_ = total_ = 0;
    for (int i = 0; i < spec.assetCount; ++i) {
      bool duplicate = false;
      for (int j = 0; j < i; ++j)
        duplicate |= !strcmp(spec.assets[i].sha, spec.assets[j].sha);
      if (!duplicate) total_ += spec.assets[i].size;
    }
    stage_ = waiting ? Stage::Waiting : Stage::Downloading;
    error_.applied();
  }
  void transferred(uint32_t count) {
    const uint32_t available = total_ - bytes_;
    bytes_ += count < available ? count : available;
    stage_ = Stage::Downloading;
  }
  void waiting() { stage_ = Stage::Waiting; }
  void verifying() { stage_ = Stage::Verifying; }
  void applying(uint32_t version) {
    if (version_ == version) stage_ = Stage::Applying;
  }
  void applied(uint32_t version) {
    if (!version) return;
    if (version != version_) {
      version_ = version;
      bytes_ = total_ = 0;
    }
    bytes_ = total_;
    stage_ = Stage::Complete;
    error_.applied();
  }
  void failed(uint32_t version, const char* message) {
    if (version != version_) {
      version_ = version;
      bytes_ = total_ = 0;
    }
    stage_ = Stage::Error;
    error_.permanent(message);
  }
  Stage stage() const { return stage_; }
  uint32_t version() const { return version_; }
  uint32_t bytes() const { return bytes_; }
  uint32_t total() const { return total_; }
  const char* error() const { return error_.message(); }
  int percent() const {
    if (stage_ == Stage::Complete) return 100;
    if (stage_ != Stage::Downloading) return -1;
    const int value = total_ ? int(uint64_t(bytes_) * 100 / total_) : 0;
    return value < 99 ? value : 99;
  }
  const char* stageName() const {
    switch (stage_) {
      case Stage::Waiting: return "waiting";
      case Stage::Downloading: return "downloading";
      case Stage::Verifying: return "verifying";
      case Stage::Applying: return "applying";
      case Stage::Complete: return "complete";
      case Stage::Error: return "error";
      default: return "idle";
    }
  }
 private:
  Stage stage_ = Stage::Idle;
  uint32_t version_ = 0, bytes_ = 0, total_ = 0;
  SyncErrorState error_;
};
inline bool validNoteId(const char* id) {
  if (!id || strlen(id) != 8) return false;
  uint32_t n = 0;
  for (int i = 0; i < 8; ++i) {
    char c = id[i];
    if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
    n = (n << 4) | (c <= '9' ? c - '0' : c - 'a' + 10);
  }
  return n != 0;
}
inline bool validHash(const char* text) {
  if (!text || strlen(text) != 64) return false;
  for (int i = 0; i < 64; ++i)
    if (!((text[i] >= '0' && text[i] <= '9') || (text[i] >= 'a' && text[i] <= 'f'))) return false;
  return true;
}
inline int roleIndex(const char* role) {
  const char* names[] = {"charge", "jump", "walk", "sleep", "eyes", "custom1", "custom2",
      "sway","steps","look","curious","stomp","shake","proud","record"};
  if (!role) return -1;
  for (int i = 0; i < kAnimationRoleCount; ++i)
    if (!strcmp(role, names[i])) return i;
  return -1;
}
inline int clockMinutes(const char* value) {
  if (!value || strlen(value) != 5 || value[2] != ':') return -1;
  for (int i : {0, 1, 3, 4})
    if (value[i] < '0' || value[i] > '9') return -1;
  int h = (value[0] - '0') * 10 + value[1] - '0', m = (value[3] - '0') * 10 + value[4] - '0';
  return h < 24 && m < 60 ? h * 60 + m : -1;
}
inline bool parseManifest(JsonVariantConst doc, DesignSpec& out, char* error, size_t capacity) {
  resetDesign(out);
  auto fail = [&](const char* msg) {
    if (error && capacity) snprintf(error, capacity, "%s", msg);
    return false;
  };
  if (!doc.is<JsonObjectConst>() || !doc["version"].is<uint32_t>() || doc["version"].as<uint32_t>() == 0)
    return fail("Invalid design version.");
  out.version = doc["version"].as<uint32_t>();
  const auto offset = doc["character_y_offset"];
  if (!offset.isUnbound()) {
    if (!offset.is<int>() || offset.as<int>() < -128 || offset.as<int>() > 128)
      return fail("Invalid character height offset.");
    out.characterYOffset = offset.as<int>();
  }
  size_t total = 0;
  auto asset = [&](JsonVariantConst value, bool jpeg) -> int {
    if (!value.is<JsonObjectConst>() || out.assetCount >= kMaxAssets) return -1;
    const auto hs = value["sha256"].as<JsonString>();
    const char* kind = value["kind"].as<const char*>();
    if (!hs.c_str() || hs.size() != 64 || !validHash(hs.c_str()) || !kind ||
        strcmp(kind, jpeg ? "jpeg" : "agf") || !value["size"].is<uint32_t>() || !value["width"].is<int>() ||
        !value["height"].is<int>())
      return -1;
    const uint32_t bytes = value["size"].as<uint32_t>();
    int w = value["width"].as<int>(), h = value["height"].as<int>();
    if (!bytes || bytes > 1024 * 1024 || w < 1 || h < 1 ||
        (jpeg ? (w != 240 || h != 888) : (w > 256 || h > 256)))
      return -1;
    auto& a = out.assets[out.assetCount];
    strcpy(a.sha, hs.c_str());
    a.size = bytes;
    a.width = uint16_t(w);
    a.height = uint16_t(h);
    a.jpeg = jpeg;
    snprintf(a.path, sizeof a.path, "/design/%s.%s", a.sha, jpeg ? "jpg" : "agf");
    bool duplicate = false;
    for (int i = 0; i < out.assetCount; ++i) {
      const auto& old = out.assets[i];
      if (strcmp(old.sha, a.sha)) continue;
      if (old.size != a.size || old.width != a.width || old.height != a.height || old.jpeg != a.jpeg)
        return -1;
      duplicate = true;
    }
    if (!duplicate) total += bytes;
    return out.assetCount++;
  };
  if (!doc["background"].isNull()) {
    out.background = asset(doc["background"], true);
    if (out.background < 0) return fail("Invalid background.");
  }
  if (!doc["hero"].isNull()) {
    out.hero = asset(doc["hero"], false);
    if (out.hero < 0) return fail("Invalid character image.");
  }
  const auto list = doc["animations"];
  if (!list.isNull() && !list.is<JsonArrayConst>()) return fail("Invalid animation list.");
  if (list.size() > kMaxAnimations) return fail("Up to nine animations are supported.");
  bool seen[kAnimationRoleCount]{};
  int idleCount=0;
  for (auto value : list.as<JsonArrayConst>()) {
    const char* role = value["role"].as<const char*>();
    int index = roleIndex(role);
    if (index < 0 || seen[index]) return fail("Duplicate or unknown animation role.");
    seen[index] = true;
    auto& rule = out.animations[out.animationCount++];
    rule.start = 1380;
    rule.end = 420;
    strcpy(rule.role, role);
    if (!value["enabled"].is<bool>() || !value["repeat"].is<bool>() || !value["interval_s"].is<int>() ||
        !value["priority"].is<int>())
      return fail("Invalid animation rules.");
    rule.enabled = value["enabled"].as<bool>();
    rule.repeat = value["repeat"].as<bool>();
    rule.intervalSeconds = value["interval_s"].as<int>();
    rule.priority = value["priority"].as<int>();
    if (rule.intervalSeconds < 1 || rule.intervalSeconds > 86400 || rule.priority < -1000 ||
        rule.priority > 1000)
      return fail("Invalid interval or priority.");
    const char* event = value["trigger"].as<const char*>();
    if (!event) return fail("Missing animation event.");
    if (!strcmp(event, "interval"))
      rule.trigger = 0;
    else if (!strcmp(event, "charging"))
      rule.trigger = 1;
    else if (!strcmp(event, "sleep"))
      rule.trigger = 2;
    else if (!strcmp(event,"idle"))
      rule.trigger = 3;
    else if (!strcmp(event,"recording"))
      rule.trigger = 4;
    else
      return fail("Unknown animation event.");
    if((rule.trigger==4)!=(!strcmp(role,"record"))) return fail("Invalid recording event.");
    if(rule.trigger==2 && index>=7) return fail("New animations cannot use the sleep event.");
    if(strcmp(role,"charge") && strcmp(role,"record") && rule.enabled && ++idleCount>7)
      return fail("Up to seven idle animations are supported.");
    if (rule.trigger == 2) {
      rule.start = clockMinutes(value["start"].as<const char*>());
      rule.end = clockMinutes(value["end"].as<const char*>());
      if (rule.start < 0 || rule.end < 0) return fail("Invalid sleep time.");
    }
    rule.asset = asset(value["asset"], false);
    if (rule.asset < 0) return fail("Invalid animation file.");
  }
  if (total > 1024 * 1024) return fail("Design assets exceed 1 MB.");
  return true;
}
}  // namespace Tamagotchi::ServerSync

// Journal helpers stay portable so durability and truncated-write rejection are
// verified against real host files independently of the network task.
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
namespace Tamagotchi::ServerSync {
constexpr size_t kMaxPendingDeletions = 1024;
struct DeletionJournal {
  uint64_t cursor = 0;
  uint32_t ids[kMaxPendingDeletions]{};
  size_t count = 0;
};
inline uint32_t journalCrc(const uint8_t* data, size_t bytes) {
  uint32_t crc = ~uint32_t(0);
  for (size_t i = 0; i < bytes; ++i) {
    crc ^= data[i];
    for (int b = 0; b < 8; ++b) crc = (crc >> 1) ^ (0xedb88320u & uint32_t(-int32_t(crc & 1)));
  }
  return ~crc;
}
inline bool atomicSyncFile(const char* path, const uint8_t* data, size_t bytes) {
  char part[160];
  if (snprintf(part, sizeof part, "%s.part", path) >= int(sizeof part)) return false;
  FILE* file = fopen(part, "wb");
  if (!file) return false;
  bool ok = fwrite(data, 1, bytes, file) == bytes;
  ok = (fflush(file) == 0) && ok;
  ok = (fsync(fileno(file)) == 0) && ok;
  ok = (fclose(file) == 0) && ok;
  if (!ok || rename(part, path) != 0) {
    remove(part);
    return false;
  }
  return true;
}
inline void syncPut32(uint8_t* out, uint32_t value) {
  for (int i = 0; i < 4; ++i) out[i] = uint8_t(value >> (8 * i));
}
inline uint32_t syncGet32(const uint8_t* in) {
  uint32_t out = 0;
  for (int i = 0; i < 4; ++i) out |= uint32_t(in[i]) << (8 * i);
  return out;
}
inline bool writeDeletionJournal(const char* path, const DeletionJournal& journal) {
  if (journal.count > kMaxPendingDeletions) return false;
  const size_t bytes = 20 + journal.count * 4;
  auto* data = static_cast<uint8_t*>(malloc(bytes));
  if (!data) return false;
  memcpy(data, "TSJ1", 4);
  syncPut32(data + 4, uint32_t(journal.cursor));
  syncPut32(data + 8, uint32_t(journal.cursor >> 32));
  syncPut32(data + 12, uint32_t(journal.count));
  for (size_t i = 0; i < journal.count; ++i) syncPut32(data + 16 + 4 * i, journal.ids[i]);
  syncPut32(data + bytes - 4, journalCrc(data, bytes - 4));
  const bool ok = atomicSyncFile(path, data, bytes);
  free(data);
  return ok;
}
inline bool readDeletionJournal(const char* path, DeletionJournal& journal) {
  FILE* file = fopen(path, "rb");
  if (!file) return false;
  uint8_t header[16];
  bool ok = fread(header, 1, 16, file) == 16 && !memcmp(header, "TSJ1", 4);
  const size_t count = ok ? syncGet32(header + 12) : kMaxPendingDeletions + 1;
  if (count > kMaxPendingDeletions) {
    fclose(file);
    return false;
  }
  const size_t bytes = 20 + count * 4;
  auto* data = static_cast<uint8_t*>(malloc(bytes));
  if (!data) {
    fclose(file);
    return false;
  }
  memcpy(data, header, 16);
  ok = fread(data + 16, 1, bytes - 16, file) == bytes - 16 && fgetc(file) == EOF && !ferror(file);
  fclose(file);
  ok = ok && syncGet32(data + bytes - 4) == journalCrc(data, bytes - 4);
  // Validate every ID before changing the caller. The serialized heap buffer
  // is already a complete snapshot, so no 4-KiB stack copy is needed.
  if (ok)
    for (size_t i = 0; i < count; ++i)
      if (!syncGet32(data + 16 + i * 4)) ok = false;
  if (ok) {
    journal.cursor = uint64_t(syncGet32(data + 4)) | (uint64_t(syncGet32(data + 8)) << 32);
    journal.count = count;
    for (size_t i = 0; i < count; ++i) journal.ids[i] = syncGet32(data + 16 + i * 4);
  }
  free(data);
  return ok;
}
}  // namespace Tamagotchi::ServerSync

#ifdef ARDUINO
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <HTTPClient.h>
#include <NetworkClientSecure.h>
#include <esp_littlefs.h>
#include <mbedtls/sha256.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <algorithm>
#include <dirent.h>
#include <time.h>
#include "http_json.h"
#include "server_config.h"
#include "server_transport.h"

namespace Tamagotchi::ServerSync {
namespace Detail {
constexpr const char* kDirectory = "/littlefs/design";
constexpr const char* kJournal = "/littlefs/sync/deletions.bin";
inline SemaphoreHandle_t lock = nullptr;
inline TaskHandle_t worker = nullptr;
inline std::atomic<bool> busy{true}, ready{false}, audioPending{false};
inline std::atomic<bool> powerIdle{false};
inline std::atomic<bool> localWritesPending{true},reminderWritesPending{true};
inline DevicePoll::Schedule pollSchedule;
inline uint32_t hintedVersion=0;
inline bool hintedDeletions=false,hintsKnown=false;
inline std::atomic<bool> progressChanged{false};
inline std::atomic<uint32_t> applied{0}, rejected{0}, serverTime{0};
inline DesignSpec pending, active, gcPrevious;
inline bool havePending = false;
inline DeletionJournal journal;
inline char telemetry[2048] = "{}", deviceId[32]{}, firmwareMd5[33]{};
inline FilesystemFreeCache filesystemSpace;
inline uint32_t filesystemSampleAt=0;
inline std::atomic<uint32_t> recordingLockWaitUs{0},recordingLockWaitMaxUs{0};
inline std::atomic<uint32_t> recordingGcCount{0},recordingGcLastUs{0};
inline SyncRequestTrace requestTrace,downloadTrace;
inline void sampleFilesystemSpace() {
  size_t total=0,used=0;
  if(esp_littlefs_info(kFilesystemPartitionLabel,&total,&used)==ESP_OK) filesystemSpace.accept(total,used);
}
inline SyncErrorState errorState;
inline Reminders::Outbox reminderOutbox;
inline Notifications::Store notificationStore;
inline Reminders::Request reminderTransfer;
inline Notifications::Delivery notificationTransfer;
inline bool reminderStorageReady=false,reminderStorageAttempted=false;
inline std::atomic<uint32_t> notificationRevision{0};
inline DesignUpdateProgress progress;
// Accessed only with lock held. Recording may cancel/close a partially written
// asset while the sync worker waits for TLS, without waiting on that network.
inline FILE* assetPartFile = nullptr;
inline char assetPartPath[160]{};
inline uint32_t heartbeatAt = 0;
inline uint32_t sentNotes[kMaxNotes]{}, sentDeletes[128]{};
inline size_t noteSlot = 0, deleteSlot = 0;
inline uint32_t scanDelete = 0, scanNote = 0;
inline Https::PsramJsonAllocator allocator;
inline Inbox::ReceiptStore inboxReceipts;
inline Inbox::Delivery inboxDelivery;
inline Inbox::PollSchedule inboxSchedule;
inline bool inboxStorageReady=false,inboxPending=false,inboxApplyFailed=false;
inline uint32_t inboxApplyAt=0;
inline char inboxAck[33]{};
// Optional, read-only cache in PSRAM. The existing sync worker owns requests;
// no new task, TLS connection in the display loop, or per-frame allocation.
inline Calories::Summary* calories=nullptr;
inline Calories::Status caloriesStatus=Calories::Status::Waiting;
inline std::atomic<bool> caloriesVisible{false},caloriesClockTrusted{false};
inline std::atomic<bool> caloriesRefreshPending{false};
inline std::atomic<bool> refreshPollRequested{false};
inline std::atomic<uint32_t> caloriesReceivedAt{0},caloriesChanged{0};
inline bool designBusy() { return busy.load() || audioPending.load(); }
inline bool backgroundAllowed() { return !busy.load() && !NetworkGate::voiceBusy(); }
struct Guard {
  bool held = false;
  explicit Guard(uint32_t wait = 10000) {
    held = lock && xSemaphoreTake(lock, pdMS_TO_TICKS(wait)) == pdTRUE;
  }
  ~Guard() {
    if (held) xSemaphoreGive(lock);
  }
  explicit operator bool() const { return held; }
};
inline bool closeAssetPart(bool discard) {
  bool ok=!assetPartFile || fclose(assetPartFile)==0;
  assetPartFile = nullptr;
  const bool removed=!discard || !*assetPartPath || remove(assetPartPath)==0 || errno==ENOENT;
  if(removed) assetPartPath[0]=0;
  return ok && removed;
}
inline void encodeProgress(JsonObject out) {
  out["kind"] = "design";
  out["stage"] = progress.stageName();
  out["version"] = progress.version();
  out["bytes"] = progress.bytes();
  out["total"] = progress.total();
  const int percent = progress.percent();
  if (percent < 0) out["percent"] = nullptr;
  else out["percent"] = percent;
  out["error"] = String(progress.error());
}
inline void error(const char* message) {
  Guard guard;
  if (!guard) return;
  errorState.permanent(message);
}
inline void transientError(const char* message) {
  Guard guard;
  if (guard) errorState.transient(message);
}
inline void transportRecovered() {
  Guard guard;
  if (guard) errorState.transportRecovered();
}
inline bool fileBytes(const char* path, uint32_t expected = 0) {
  struct stat info {};
  return stat(path, &info) == 0 && S_ISREG(info.st_mode) && info.st_size > 0 &&
         (!expected || uint32_t(info.st_size) == expected);
}
inline bool readJsonFile(const char* path, JsonDocument& doc) {
  struct stat info {};
  if (stat(path, &info) || info.st_size <= 0 || info.st_size > 65536) return false;
  auto* data =
      static_cast<char*>(heap_caps_malloc(size_t(info.st_size) + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!data) return false;
  FILE* file = fopen(path, "rb");
  if (!file) {
    free(data);
    return false;
  }
  const size_t bytes = fread(data, 1, size_t(info.st_size), file);
  bool ok = bytes == size_t(info.st_size) && !ferror(file) && fgetc(file) == EOF;
  fclose(file);
  data[bytes] = 0;
  if (ok)
    ok =
        !deserializeJson(doc, static_cast<const char*>(data), bytes, DeserializationOption::NestingLimit(12));
  free(data);
  return ok && !doc.overflowed();
}
inline bool writeJsonFile(const char* path, const JsonDocument& doc) {
  const size_t bytes = measureJson(doc);
  if (bytes > 65536 || doc.overflowed()) return false;
  auto* data = static_cast<uint8_t*>(heap_caps_malloc(bytes + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!data) return false;
  bool ok = serializeJson(doc, reinterpret_cast<char*>(data), bytes + 1) == bytes &&
            atomicSyncFile(path, data, bytes);
  free(data);
  return ok;
}
inline void encodeAsset(JsonObject out, const Asset& a) {
  out["sha256"] = a.sha;
  out["size"] = a.size;
  out["kind"] = a.jpeg ? "jpeg" : "agf";
  out["width"] = a.width;
  out["height"] = a.height;
}
inline void encodeDesign(const DesignSpec& spec, JsonDocument& doc) {
  doc.clear();
  doc["version"] = spec.version;
  doc["character_y_offset"] = spec.characterYOffset;
  if (spec.background >= 0)
    encodeAsset(doc["background"].to<JsonObject>(), spec.assets[spec.background]);
  else
    doc["background"] = nullptr;
  if (spec.hero >= 0)
    encodeAsset(doc["hero"].to<JsonObject>(), spec.assets[spec.hero]);
  else
    doc["hero"] = nullptr;
  auto rules = doc["animations"].to<JsonArray>();
  for (int i = 0; i < spec.animationCount; ++i) {
    const auto& r = spec.animations[i];
    auto item = rules.add<JsonObject>();
    item["role"] = r.role;
    item["enabled"] = r.enabled;
    item["repeat"] = r.repeat;
    const char* triggers[]={"interval","charging","sleep","idle","recording"};
    item["trigger"] = r.trigger<5?triggers[r.trigger]:"interval";
    item["interval_s"] = r.intervalSeconds;
    item["priority"] = r.priority;
    char start[6], end[6];
    snprintf(start, sizeof start, "%02d:%02d", r.start / 60, r.start % 60);
    snprintf(end, sizeof end, "%02d:%02d", r.end / 60, r.end % 60);
    item["start"] = start;
    item["end"] = end;
    encodeAsset(item["asset"].to<JsonObject>(), spec.assets[r.asset]);
  }
}
inline bool loadDesign(const char* path, DesignSpec& spec) {
  JsonDocument doc(&allocator);
  char message[128];
  return readJsonFile(path, doc) && parseManifest(doc.as<JsonVariantConst>(), spec, message, sizeof message);
}
inline bool hashFile(const char* path, const Asset& asset, bool (*keepRunning)()=nullptr) {
  if(keepRunning && !keepRunning()) return false;
  if (!fileBytes(path, asset.size)) return false;
  FILE* file = fopen(path, "rb");
  if (!file) return false;
  mbedtls_sha256_context sha;
  mbedtls_sha256_init(&sha);
  bool ok = mbedtls_sha256_starts(&sha, 0) == 0;
  uint8_t buffer[2048], digest[32]{};
  size_t count;
  while (ok && (!keepRunning || keepRunning()) && (count = fread(buffer, 1, sizeof buffer, file)) > 0)
    ok = mbedtls_sha256_update(&sha, buffer, count) == 0;
  if(keepRunning && !keepRunning()) ok=false;
  ok = ok && !ferror(file) && mbedtls_sha256_finish(&sha, digest) == 0;
  fclose(file);
  mbedtls_sha256_free(&sha);
  char hex[65];
  for (int i = 0; i < 32; ++i) snprintf(hex + i * 2, 3, "%02x", digest[i]);
  return ok && !strcmp(hex, asset.sha);
}
inline bool contains(const DesignSpec& spec, const char* name) {
  for (int i = 0; i < spec.assetCount; ++i) {
    const char* filename = strrchr(spec.assets[i].path, '/');
    if (filename && !strcmp(filename + 1, name)) return true;
  }
  return false;
}
// Caller holds the storage lock. Legacy assets live outside /design and are
// deliberately untouched. Removing previous before recording makes WAV space.
inline void collect(bool recording) {
  resetDesign(gcPrevious);
  if (!recording) loadDesign("/littlefs/design/previous.json", gcPrevious);
  DIR* dir = opendir(kDirectory);
  if (!dir) return;
  while (const auto* entry = readdir(dir)) {
    if (entry->d_name[0] == '.' || !strcmp(entry->d_name, "active.json") ||
        (!recording && !strcmp(entry->d_name, "previous.json")))
      continue;
    if (contains(active, entry->d_name) || (!recording && contains(gcPrevious, entry->d_name))) continue;
    char path[160];
    snprintf(path, sizeof path, "%s/%s", kDirectory, entry->d_name);
    remove(path);
  }
  closedir(dir);
}
inline bool request(const char* method, const char* endpoint, const char* body, JsonDocument& output,
                    uint16_t timeout = 8000,size_t maximum=65536,int* responseStatus=nullptr,
                    bool quietNotFound=false,ServerTransport::Client::Continue keepRunning=nullptr,
                    uint32_t maximumDuration=90000,uint16_t handshakeSeconds=0) {
  requestTrace.begin(syncEndpoint(endpoint),millis());
  if(responseStatus) *responseStatus=0;
  if(NetworkGate::voiceBusy()) { requestTrace.phase(SyncRequestStage::Skipped,millis()); return false; }
  char url[512];
  if (snprintf(url, sizeof url, "%s%s", ServerConfig::kBaseUrl, endpoint) >= int(sizeof url)) {
    requestTrace.finish(false,0,0,millis()); return false;
  }
  auto* buffer = static_cast<char*>(heap_caps_malloc(maximum+1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!buffer) {
    requestTrace.finish(false,0,0,millis());
    transientError("Not enough memory to sync.");
    return false;
  }
  ServerTransport::Client client(maximumDuration,NetworkGate::Priority::Background,keepRunning);
  if (*ServerConfig::kCa) client.setCACert(ServerConfig::kCa);
  else client.useBuiltinCACertBundle();
  client.setHandshakeTimeout(handshakeSeconds?handshakeSeconds:(timeout + 999) / 1000);
  client.setTimeout(timeout);
  HTTPClient http;
  http.setConnectTimeout(std::min(uint16_t(6000), timeout));
  http.setTimeout(timeout);
  http.setReuse(false);
  http.setUserAgent("Tamagotchi/1.0");
  bool ok = http.begin(client, url);
  int status=0;
  if (ok) {
    http.addHeader("Authorization", String("Bearer ") + ServerConfig::kToken);
    http.addHeader("Accept-Encoding", "identity");
    http.addHeader("Content-Type", "application/json");
    requestTrace.phase(SyncRequestStage::Transport,millis());
    status = http.sendRequest(method, reinterpret_cast<uint8_t*>(const_cast<char*>(body)),
                              body ? strlen(body) : 0);
    requestTrace.status(status); requestTrace.phase(SyncRequestStage::Headers,millis());
    if(responseStatus) *responseStatus=status;
    Https::BoundedStream sink(buffer, maximum+1);
    const int knownLength = http.getSize();
    requestTrace.phase(SyncRequestStage::Body,millis());
    int received = (status == 200 && (knownLength<0 || size_t(knownLength)<=maximum)) ? http.writeToStream(&sink) : -1;
    ok = status == 200 && received >= 0 && size_t(received) == sink.size() &&
         (knownLength < 0 || size_t(knownLength) == sink.size()) && !sink.overflow && !client.timedOut();
    if (ok)
      ok = !deserializeJson(output, static_cast<const char*>(buffer), sink.size(),
                            DeserializationOption::NestingLimit(12)) &&
           !output.overflowed();
    if (!ok && !(quietNotFound && status==404) && (!keepRunning || keepRunning())) {
      if (status == 401 || status == 403)
        error("The server rejected the device token.");
      else
        transientError("Sync is incomplete. Will retry later.");
    }
  }
  else if(!keepRunning || keepRunning()) transientError("Sync is incomplete. Will retry later.");
  char ignored[1]{}; const int tlsError=client.lastError(ignored,sizeof ignored);
  requestTrace.phase(SyncRequestStage::Closing,millis());
  http.end();
  free(buffer);
  if (ok) transportRecovered();
  requestTrace.finish(ok,status,tlsError,millis());
  return ok;
}
inline bool notificationRequest(const char* method,const char* endpoint,const char* body,JsonDocument& output,
                                size_t maximum=65536,int* status=nullptr,bool quiet=false) {
  return request(method,endpoint,body,output,8000,maximum,status,quiet,backgroundAllowed,15000,8);
}
inline bool queueDeletion(uint32_t id) {
  if (!id) return false;
  Guard guard;
  if (!guard) return false;
  for (size_t i = 0; i < journal.count; ++i)
    if (journal.ids[i] == id) return true;
  if (journal.count >= kMaxPendingDeletions) return false;
  const size_t old = journal.count;
  journal.ids[journal.count++] = id;
  if (writeDeletionJournal(kJournal, journal)) return true;
  journal.count = old;
  return false;
}
inline void heartbeat(bool fast = false);
inline void downloadHeartbeat() {
  if (uint32_t(millis() - heartbeatAt) >= 1000) heartbeat(true);
}
inline bool assetWorkAllowed() { return !designBusy(); }
inline bool download(const Asset& asset) {
  downloadTrace.begin(SyncEndpoint::Asset,millis());
  char path[144];
  snprintf(path, sizeof path, "/littlefs%s", asset.path);
  // Hash read-only bytes without the shared storage guard. Capture can publish
  // cancellation immediately; each block checks it before doing more work.
  if(designBusy()) { downloadTrace.finish(false,0,0,millis()); return false; }
  if(hashFile(path,asset,assetWorkAllowed)) {
    Guard guard(20);
    if(guard && !designBusy()) {
      progress.transferred(asset.size);
      progressChanged = true;
      downloadTrace.finish(true,0,0,millis());
      return true;
    }
    downloadTrace.finish(false,0,0,millis()); return false;
  }
  if(designBusy()) { downloadTrace.finish(false,0,0,millis()); return false; }
  char part[160];
  snprintf(part, sizeof part, "%s.part", path);
  char url[512];
  snprintf(url, sizeof url, "%s/api/device/assets/%s", ServerConfig::kBaseUrl, asset.sha);
  ServerTransport::Client client;
  if (*ServerConfig::kCa) client.setCACert(ServerConfig::kCa);
  else client.useBuiltinCACertBundle();
  client.setHandshakeTimeout(8);
  client.setTimeout(8000);
  HTTPClient http;
  http.setConnectTimeout(6000);
  http.setTimeout(8000);
  http.setReuse(false);
  if (!http.begin(client, url)) { downloadTrace.finish(false,0,0,millis()); return false; }
  http.addHeader("Authorization", String("Bearer ") + ServerConfig::kToken);
  http.addHeader("Accept-Encoding", "identity");
  downloadTrace.phase(SyncRequestStage::Transport,millis());
  const int status = http.GET();
  downloadTrace.status(status); downloadTrace.phase(SyncRequestStage::Headers,millis());
  if (status != 200 || http.getSize() != int(asset.size) || designBusy()) {
    char ignored[1]{}; const int tlsError=client.lastError(ignored,sizeof ignored);
    downloadTrace.phase(SyncRequestStage::Closing,millis());
    http.end();
    downloadTrace.finish(false,status,tlsError,millis());
    return false;
  }
  // Socket reads and read-only hashes do not own the shared storage guard.
  bool opened = false;
  {
    Guard guard;
    if (guard && !designBusy()) {
      closeAssetPart(true);
      remove(part);
      assetPartFile = fopen(part, "wb");
      if (assetPartFile) {
        snprintf(assetPartPath, sizeof assetPartPath, "%s", part);
        opened = true;
      }
    }
  }
  if (!opened) {
    downloadTrace.phase(SyncRequestStage::Closing,millis());
    http.end();
    downloadTrace.finish(false,status,0,millis());
    return false;
  }
  uint8_t buffer[2048];
  size_t used = 0;
  bool ok = true;
  auto* stream = http.getStreamPtr();
  downloadTrace.phase(SyncRequestStage::Body,millis());
  while (used < asset.size && !designBusy() && !client.timedOut()) {
    const int available = stream->available();
    if (available > 0) {
      const size_t want = std::min(size_t(available), std::min(sizeof buffer, size_t(asset.size - used)));
      const int got = stream->read(buffer, want);
      if (got <= 0) {
        ok = false;
        break;
      }
      {
        Guard guard;
        if (!guard || designBusy() || !assetPartFile ||
            fwrite(buffer, 1, size_t(got), assetPartFile) != size_t(got)) {
          ok = false;
          break;
        }
        used += size_t(got);
        progress.transferred(uint32_t(got));
        progressChanged = true;
      }
    } else if (!stream->connected()) {
      ok = false;
      break;
    } else
      delay(1);
    // Snapshot and POST run outside the file guard. The transport's deadlines
    // still bound both operations, and a recording can close the part meanwhile.
    downloadHeartbeat();
  }
  ok = ok && used == asset.size && !designBusy() && !client.timedOut();
  char ignored[1]{}; const int tlsError=client.lastError(ignored,sizeof ignored);
  downloadTrace.phase(SyncRequestStage::Closing,millis());
  http.end();
  downloadTrace.phase(SyncRequestStage::Verifying,millis());
  {
    Guard guard;
    if (!guard) { downloadTrace.finish(false,status,tlsError,millis()); return false; }
    ok = ok && !designBusy() && assetPartFile;
    if (assetPartFile) {
      ok = (fflush(assetPartFile) == 0) && ok;
      ok = (fsync(fileno(assetPartFile)) == 0) && ok;
      ok = (fclose(assetPartFile) == 0) && ok;
      assetPartFile = nullptr;
    }
  }
  // Retain the part path until commit, so worker-side recording preparation can
  // discard it even after fclose. A cancelled hash must never publish an asset.
  if(ok) ok=hashFile(part,asset,assetWorkAllowed);
  {
    Guard guard;
    if(!guard) { downloadTrace.finish(false,status,tlsError,millis()); return false; }
    ok=ok && !designBusy() && !strcmp(assetPartPath,part);
    if(ok) ok=rename(part,path)==0;
    if(!ok) remove(part);
    if(!strcmp(assetPartPath,part)) assetPartPath[0]=0;
  }
  downloadTrace.finish(ok,status,tlsError,millis());
  return ok;
}
inline void acceptHeartbeatCalories(const JsonDocument& response,uint32_t validatedPollEpoch=0) {
  Calories::Receipt receipt=Calories::Receipt::Missing;
  {
    Guard guard(20);if(!guard || !calories) return;
    receipt=validatedPollEpoch?Calories::parseSnapshot(validatedPollEpoch,response["food_today"],*calories):
        Calories::parseHeartbeat(response.as<JsonVariantConst>(),*calories);
    if(receipt==Calories::Receipt::Updated) {
      caloriesReceivedAt=millis();
      if(Calories::refreshSatisfied(calories,int64_t(time(nullptr)),caloriesClockTrusted.load()))
        caloriesRefreshPending=false;
      caloriesStatus=Calories::Status::Ready;++caloriesChanged;
    } else if(receipt==Calories::Receipt::Invalid) {
      caloriesStatus=Calories::Status::Error;++caloriesChanged;
    }
  }
  char line[96];
  snprintf(line,sizeof line,"[CALORIES] source=%s present=%u parsed=%u\n",
      validatedPollEpoch?"poll":"heartbeat",unsigned(!response["food_today"].isUnbound()),
      unsigned(receipt==Calories::Receipt::Updated));
  Serial.print(line);
}
inline void heartbeat(bool fast) {
  // Recording itself needs no TLS and may last five minutes: keep its heartbeat
  // alive, then let the voice upload/poll own the transport when it starts.
  if(NetworkGate::voiceBusy()) return;
  JsonDocument body(&allocator), response(&allocator);
  {
    Guard guard;
    if (!guard) return;
    progressChanged = false;
    deserializeJson(body, static_cast<const char*>(telemetry));
    body["device_id"] = deviceId;
    body["applied_version"] = applied.load();
    body["telemetry"]["firmware_md5"] = firmwareMd5;
    body["telemetry"]["sync_stack_min"] = uint32_t(uxTaskGetStackHighWaterMark(nullptr));
    if (progress.stage() != DesignUpdateProgress::Stage::Idle)
      encodeProgress(body["telemetry"]["update_progress"].to<JsonObject>());
    // Own this string before releasing the lock; later worker/main status
    // updates must not mutate ArduinoJson's heartbeat snapshot.
    body["error"] = String(errorState.message());
  }
  // telemetry is nested by updateSync; take strings into a bounded owned body.
  String text;
  serializeJson(body, text);
  heartbeatAt = millis();
  caloriesRefreshPending=false;
  if (request("POST", "/api/device/heartbeat", text.c_str(), response, fast ? 1500 : 8000,
      65536,nullptr,false,nullptr,15000) && response["ok"] == true &&
      response["server_time"].is<uint32_t>()) {
    serverTime = response["server_time"].as<uint32_t>();
    acceptHeartbeatCalories(response);
  }
}
inline void sync() {
  if(powerIdle.load() || busy.load() || NetworkGate::voiceBusy()) return;
  char endpoint[160];
  uint64_t cursor;
  {
    Guard guard;
    if (!guard) return;
    cursor = journal.cursor;
  }
  snprintf(endpoint, sizeof endpoint, "/api/device/sync?device_id=%s&cursor=%llu", deviceId,
           static_cast<unsigned long long>(cursor));
  JsonDocument response(&allocator);
  if (!request("GET", endpoint, nullptr, response)) return;
  if (!response["cursor"].is<uint64_t>() || !response["deleted_ids"].is<JsonArray>()) {
    error("Invalid sync response.");
    return;
  }
  {
    Guard guard;
    if (!guard) return;
    DeletionJournal next = journal;
    for (auto value : response["deleted_ids"].as<JsonArray>()) {
      const char* id = value.as<const char*>();
      if (!validNoteId(id)) {
        errorState.permanent("The server returned an invalid deleted note ID.");
        return;
      }
      const uint32_t number = uint32_t(strtoul(id, nullptr, 16));
      bool found = false;
      for (size_t i = 0; i < next.count; ++i) found |= next.ids[i] == number;
      if (!found) {
        if (next.count >= kMaxPendingDeletions) {
          errorState.permanent("Too many deletions in one sync.");
          return;
        }
        next.ids[next.count++] = number;
      }
    }
    next.cursor = response["cursor"].as<uint64_t>();
    const bool changed = next.cursor != journal.cursor || next.count != journal.count ||
                         memcmp(next.ids, journal.ids, next.count * sizeof(uint32_t));
    if (changed) {
      if (!writeDeletionJournal(kJournal, next)) return;
      journal = next;
    }
  }
  DesignSpec candidate;
  char message[192];
  if (!parseManifest(response["manifest"], candidate, message, sizeof message)) {
    error(message);
    Guard guard;
    if (guard) {
      progress.failed(candidate.version, message);
      progressChanged = true;
    }
    return;
  }
  if (candidate.version == applied.load() || candidate.version == rejected.load()) return;
  {
    Guard guard;
    if (!guard || havePending || progress.stage() == DesignUpdateProgress::Stage::Applying) return;
    progress.begin(candidate, designBusy());
    progressChanged = true;
  }
  if (designBusy() || powerIdle.load()) return;
  heartbeat(true);
  for (int i = 0; i < candidate.assetCount; ++i) {
    if (designBusy() || powerIdle.load()) return;
    bool duplicate = false;
    for (int j = 0; j < i; ++j)
      duplicate |= !strcmp(candidate.assets[i].sha, candidate.assets[j].sha);
    if (duplicate) continue;
    if (!download(candidate.assets[i])) {
      Guard guard;
      if (guard) {
        if (designBusy()) progress.waiting();
        else {
          constexpr auto message = "Could not verify or download the design.";
          errorState.permanent(message);
          progress.failed(candidate.version, message);
        }
        progressChanged = true;
      }
      return;
    }
  }
  {
    Guard guard;
    if (!guard || designBusy()) return;
    progress.verifying();
    progressChanged = true;
  }
  heartbeat(true);
  {
    Guard guard;
    if (!guard || designBusy()) return;
    JsonDocument doc(&allocator);
    encodeDesign(candidate, doc);
    if (!writeJsonFile("/littlefs/design/next.json", doc)) {
      constexpr auto message = "Could not save the downloaded design.";
      progress.failed(candidate.version, message);
      errorState.permanent(message);
      progressChanged = true;
      return;
    }
    pending = candidate;
    havePending = true;
  }
}
inline bool cached(uint32_t id, const uint32_t* ids, size_t count) {
  for (size_t i = 0; i < count; ++i)
    if (ids[i] == id) return true;
  return false;
}
inline bool uploadNotes() {
  if (busy.load()) return true;
  DIR* dir = opendir("/littlefs/notes");
  if (!dir) return true;
  uint32_t candidates[kMaxNotes]{};
  int count = 0;
  while (const auto* item = readdir(dir)) {
    if (strlen(item->d_name) != 13 || item->d_name[0] != 'n' || strcmp(item->d_name + 9, ".txt")) continue;
    char id[9];
    memcpy(id, item->d_name + 1, 8);
    id[8] = 0;
    if (!validNoteId(id)) continue;
    uint32_t number = uint32_t(strtoul(id, nullptr, 16));
    if (!cached(number, sentNotes, kMaxNotes) && count < kMaxNotes) candidates[count++] = number;
  }
  closedir(dir);
  std::sort(candidates, candidates + count);
  const int start =
      count ? int(std::upper_bound(candidates, candidates + count, scanNote) - candidates) % count : 0;
  for (int n = 0, attempts = 0; n < count && attempts < 2 && !busy.load(); ++n) {
    char path[128], marker[128], endpoint[128];
    const uint32_t id = candidates[(start + n) % count];
    scanNote = id;
    snprintf(path, sizeof path, "/littlefs/notes/n%08lx.txt", static_cast<unsigned long>(id));
    snprintf(marker, sizeof marker, "/littlefs/notes/d%08lx.del", static_cast<unsigned long>(id));
    if (fileBytes(marker)) continue;
    struct stat info {};
    if (stat(path, &info) || info.st_size <= 0 || info.st_size > kNoteTextBytes) continue;
    auto* text =
        static_cast<char*>(heap_caps_malloc(size_t(info.st_size) + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!text) return true;
    FILE* file = fopen(path, "rb");
    bool ok = file;
    size_t bytes = file ? fread(text, 1, size_t(info.st_size), file) : 0;
    if (file) {
      ok = bytes == size_t(info.st_size) && !ferror(file) && fgetc(file) == EOF;
      fclose(file);
    }
    text[bytes] = 0;
    if (!ok || memchr(text, 0, bytes) || fileBytes(marker)) {
      free(text);
      continue;
    }
    JsonDocument body(&allocator), response(&allocator);
    body["device_id"] = deviceId;
    body["text"] = text;
    char title[kNoteTitleBytes]{};
    noteUploadTitle(text,bytes,title);
    body["title"] = title;
    const size_t bodyBytes = measureJson(body);
    auto* encoded = static_cast<char*>(heap_caps_malloc(bodyBytes + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!encoded) {
      free(text);
      return true;
    }
    serializeJson(body, encoded, bodyBytes + 1);
    free(text);
    snprintf(endpoint, sizeof endpoint, "/api/device/notes/%08lx", static_cast<unsigned long>(id));
    ++attempts;
    ok = request("PUT", endpoint, encoded, response);
    free(encoded);
    if (ok && response["ok"] == true) {
      sentNotes[noteSlot++ % kMaxNotes] = id;
      if (response["deleted"] == true) queueDeletion(id);
    }
  }
  return count>0;
}
inline bool uploadDeletes() {
  if(busy.load()) return true;
  DIR* dir = opendir("/littlefs/notes");
  if (!dir) return true;
  uint32_t first = 0, next = 0;
  while (const auto* item = readdir(dir)) {
    if (strlen(item->d_name) != 13 || item->d_name[0] != 'd' || strcmp(item->d_name + 9, ".del")) continue;
    char id[9];
    memcpy(id, item->d_name + 1, 8);
    id[8] = 0;
    if (!validNoteId(id)) continue;
    uint32_t number = uint32_t(strtoul(id, nullptr, 16));
    if (cached(number, sentDeletes, 128)) continue;
    if (!first || number < first) first = number;
    if (number > scanDelete && (!next || number < next)) next = number;
  }
  closedir(dir);
  const uint32_t id = next ? next : first;
  if (!id) return false;
  scanDelete = id;
  char endpoint[160];
  snprintf(endpoint, sizeof endpoint, "/api/device/notes/%08lx?device_id=%s", static_cast<unsigned long>(id),
           deviceId);
  JsonDocument result(&allocator);
  if (request("DELETE", endpoint, nullptr, result) && result["ok"] == true && queueDeletion(id))
    sentDeletes[deleteSlot++ % 128] = id;
  return true;
}
inline void syncReminders(bool deliveries=true) {
  if(busy.load() || !reminderStorageReady) { reminderWritesPending=true;return; }
  bool haveRequest=false;
  { Guard guard(20);if(!guard) { reminderWritesPending=true;return; }haveRequest=reminderOutbox.next(reminderTransfer); }
  if(haveRequest) reminderWritesPending=true;
  JsonDocument body(&allocator),response(&allocator);String encoded;
  if(haveRequest && !busy.load()) {
    Reminders::encode(reminderTransfer,deviceId,body);serializeJson(body,encoded);
    char endpoint[128];snprintf(endpoint,sizeof endpoint,"/api/device/reminders/%s",reminderTransfer.id);
    if(request("PUT",endpoint,encoded.c_str(),response) && response["ok"]==true &&
       response["reminder_id"].is<const char*>() && !strcmp(response["reminder_id"],reminderTransfer.id) &&
       response["due_at"].is<int64_t>() && response["due_at"].as<int64_t>()==reminderTransfer.dueAt) {
      Guard guard;if(guard && !busy.load()) reminderOutbox.submitted(reminderTransfer.id);
    }
  }
  if(!deliveries) return;
  if(busy.load()) return;
  char ack[20]{};
  { Guard guard(20);if(guard && notificationStore.ackPending()) strcpy(ack,notificationStore.delivery().id); }
  if(*ack) {
    body.clear();response.clear();encoded="";body["device_id"]=deviceId;body["delivery_id"]=ack;body["status"]="dismissed";
    serializeJson(body,encoded);
    if(notificationRequest("POST","/api/device/reminders/ack",encoded.c_str(),response) && response["ok"]==true) {
      Guard guard;if(guard && !busy.load()) notificationStore.acknowledged(ack);
    }
  }
  if(busy.load()) return;
  body.clear();response.clear();encoded="";body["device_id"]=deviceId;serializeJson(body,encoded);
  if(!notificationRequest("POST","/api/device/reminders/due",encoded.c_str(),response) || !response["server_time"].is<uint32_t>()) return;
  serverTime=response["server_time"].as<uint32_t>();
  if(busy.load() || response["delivery"].isNull()) return;
  if(!Notifications::parse(response["delivery"],notificationTransfer)) { error("The server returned an invalid notification.");return; }
  Guard guard;if(!guard) return;
  const bool before=notificationStore.pending();char previous[20]{};
  if(before) strcpy(previous,notificationStore.delivery().id);
  if(!notificationStore.offer(notificationTransfer)) { errorState.permanent("Could not save the notification. Will retry later.");return; }
  if(notificationStore.pending() && (!before || strcmp(previous,notificationStore.delivery().id))) ++notificationRevision;
}
inline bool beginInboxStorage() {
  // Preserve receipt identity across HTTP/HTTPS transport changes. A different
  // storage namespace/device credential still gets an independent journal scope.
  mbedtls_sha256_context sha; mbedtls_sha256_init(&sha);
  uint8_t digest[32]; char scope[65];
  bool ok=mbedtls_sha256_starts(&sha,0)==0 &&
      ServerTransport::updateReceiptScope(ServerConfig::kReceiptScopeBaseUrl,ServerConfig::kToken,
          [&sha](const unsigned char* bytes,size_t count) { return mbedtls_sha256_update(&sha,bytes,count)==0; }) &&
      mbedtls_sha256_finish(&sha,digest)==0;
  mbedtls_sha256_free(&sha);
  if(!ok) return false;
  Inbox::encodeHex(digest,scope,32);
  return inboxDelivery.reserve() && inboxReceipts.begin("/littlefs/sync/inbox-receipts.bin",scope);
}
inline void queueInboxAck(const char* id) {
  // One outstanding ack is enough: GET returns the oldest unacknowledged item,
  // and durable receipts suppress an item if this in-memory ack was lost.
  if(!*inboxAck) strcpy(inboxAck,id);
}
inline void pollInbox() {
  if(!inboxSchedule.due(millis(),inboxStorageReady && !busy.load() &&
      !NetworkGate::voiceBusy() && WiFi.status()==WL_CONNECTED)) return;
  char ack[33]{};
  { Guard guard(20); if(!guard) return; strcpy(ack,inboxAck); }
  JsonDocument response(&allocator);
  if(*ack) {
    char endpoint[96]; snprintf(endpoint,sizeof endpoint,"/api/core/device/inbox/%s/ack",ack);
    int status=0;
    const bool accepted=notificationRequest("POST",endpoint,"{}",response,4096,&status,true) && response["ok"]==true;
    if(!accepted && status!=404) return;
    { Guard guard(20); if(!guard) return; if(!strcmp(inboxAck,ack)) inboxAck[0]=0; }
  }
  { Guard guard(20); if(!guard || inboxPending || busy.load()) return; }
  response.clear();
  if(!notificationRequest("GET","/api/core/device/inbox",nullptr,response,6*size_t(kNoteTextBytes)+4096,nullptr,true)) return;
  if(!response.is<JsonObject>() || response.size()!=1 || response["delivery"].isUnbound()) return;
  if(response["delivery"].isNull()) return;
  Guard guard(20); if(!guard || inboxPending) return;
  if(!Inbox::parse(response["delivery"],inboxDelivery)) {
    errorState.transient("The server returned an invalid inbox message."); return;
  }
  if(inboxReceipts.contains(inboxDelivery.id)) { queueInboxAck(inboxDelivery.id); return; }
  inboxPending=true; inboxApplyFailed=false;
}
inline bool pollCombined() {
  JsonDocument body(&allocator),response(&allocator);
  char coreAck[33]{},reminderAck[20]{};
  {
    Guard guard(20);if(!guard) return false;
    deserializeJson(body,static_cast<const char*>(telemetry));
    body["cursor"]=journal.cursor;
    body["applied_version"]=applied.load();
    body["error"]=String(errorState.message());
    body["telemetry"]["firmware_md5"]=firmwareMd5;
    body["telemetry"]["sync_stack_min"]=uint32_t(uxTaskGetStackHighWaterMark(nullptr));
    if(progress.stage()!=DesignUpdateProgress::Stage::Idle)
      encodeProgress(body["telemetry"]["update_progress"].to<JsonObject>());
    if(inboxStorageReady && *inboxAck) { strcpy(coreAck,inboxAck);body["core_ack"]=coreAck; }
    if(reminderStorageReady && notificationStore.ackPending()) {
      strcpy(reminderAck,notificationStore.delivery().id);body["reminder_ack"]=reminderAck;
    }
  }
  String encoded;serializeJson(body,encoded);
  int status=0;
  // Notification traffic owns a fifteen-second total budget. It yields to a
  // pending voice request and never waits behind a new dark-mode asset transfer.
  if(!notificationRequest("POST","/api/core/device/poll",encoded.c_str(),response,
      6*size_t(kNoteTextBytes)+16384,&status,true)) {
    if(status==404) { pollSchedule.unsupported(millis());hintsKnown=false; }
    return status==404;
  }
  DevicePoll::Response parsed;
  Inbox::Delivery incoming;
  Notifications::Delivery incomingReminder;
  if(!DevicePoll::parse(response.as<JsonVariantConst>(),parsed,incoming,incomingReminder)) return false;
  // Only a completely validated envelope may clear durable acknowledgements or
  // publish deliveries. A truncated/malformed response is retried unchanged.
  {
    Guard guard(20);if(!guard) return false;
    if(parsed.coreAck.matches(coreAck) && !strcmp(inboxAck,coreAck)) inboxAck[0]=0;
    if(parsed.reminderAck.matches(reminderAck)) notificationStore.acknowledged(reminderAck);
    if(parsed.haveCore && inboxStorageReady && !inboxPending) {
      if(inboxReceipts.contains(incoming.id)) queueInboxAck(incoming.id);
      else if(inboxDelivery.reserve()) {
        strcpy(inboxDelivery.id,incoming.id);strcpy(inboxDelivery.heading,incoming.heading);
        strcpy(inboxDelivery.title,incoming.title);inboxDelivery.kind=incoming.kind;inboxDelivery.noteId=incoming.noteId;
        strcpy(inboxDelivery.body.data(),incoming.body.data());inboxPending=true;inboxApplyFailed=false;
      }
    }
    if(parsed.haveReminder && reminderStorageReady) {
      const bool before=notificationStore.pending();char previous[20]{};
      if(before) strcpy(previous,notificationStore.delivery().id);
      if(notificationStore.offer(incomingReminder) && notificationStore.pending() &&
          (!before || strcmp(previous,notificationStore.delivery().id))) ++notificationRevision;
    }
    // Hints deliberately never advance journal.cursor or mark a design applied.
    // Full sync will consume them after wake, before normal asset work resumes.
    hintedVersion=parsed.publishedVersion;hintedDeletions=parsed.deletionsPending;hintsKnown=true;
  }
  serverTime=parsed.epoch;heartbeatAt=millis();pollSchedule.supported();
  acceptHeartbeatCalories(response,parsed.epoch);
  return false;
}
inline void task(void*) {
  uint32_t routineAt=millis()-300000u;
  heartbeatAt = millis() - 10000;
  for (;;) {
    if (ready.load()) {
      // LittleFS info walks the flash tree under its own mutex. Keep it off
      // the display loop and skip it while recording/audio storage has priority.
      if(!designBusy() && uint32_t(millis()-filesystemSampleAt)>=(powerIdle.load()?60000u:10000u)) {
        filesystemSampleAt=millis();
        sampleFilesystemSpace();
      }
      const bool allowed=backgroundAllowed() && WiFi.status()==WL_CONNECTED;
      // Explicit refresh events coalesce independently of the cache's pending
      // state. A failed attempt leaves that state pending but retries on the
      // ordinary minute cadence, rather than forcing a permanent request loop.
      const bool refresh=refreshPollRequested.exchange(false);
      const bool progressUpdate=progressChanged.exchange(false);
      if(refresh || progressUpdate) pollSchedule.requestRefresh();
      if(pollSchedule.pollDue(millis(),powerIdle.load(),allowed)) {
        bool legacy=pollSchedule.legacy(millis());
        if(!legacy) legacy=pollCombined();
        if(legacy) {
          // Old servers retain both delivery channels. The outer schedule bounds
          // this fallback to once a minute; retry feature discovery after 5 min.
          pollInbox();syncReminders();heartbeat();
        }
      }
      if(pollSchedule.writesDue(millis(),localWritesPending.load() || reminderWritesPending.load(),allowed)) {
        if(reminderWritesPending.exchange(false)) syncReminders(false);
        if(localWritesPending.exchange(false)) {
          const bool deletes=uploadDeletes(),notes=uploadNotes();
          if(deletes || notes) localWritesPending=true;
        }
      }
      if(pollSchedule.maintenanceDue(millis(),powerIdle.load(),allowed)) {
        if(DevicePoll::routineNeeded(hintsKnown,hintedVersion,applied.load(),hintedDeletions,routineAt,millis())) {
          routineAt=millis();sync();
        }
        if(!busy.load()) { uploadDeletes();uploadNotes(); }
      }
    }
    const uint32_t pause=pollSchedule.waitMilliseconds(millis(),powerIdle.load(),
        localWritesPending.load() || reminderWritesPending.load(),backgroundAllowed() && WiFi.status()==WL_CONNECTED);
    ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(pause));
  }
}
}  // namespace Detail

inline bool readStoredDesign(DesignSpec& spec, bool previous = false) {
  if (!Detail::loadDesign(previous ? "/littlefs/design/previous.json" : "/littlefs/design/active.json", spec))
    return false;
  for (int i = 0; i < spec.assetCount; ++i) {
    char path[144];
    snprintf(path, sizeof path, "/littlefs%s", spec.assets[i].path);
    if (!Detail::hashFile(path, spec.assets[i])) return false;
  }
  return true;
}
inline bool beginReminderStorage() {
  using namespace Detail;
  if(reminderStorageAttempted) return reminderStorageReady;
  if(!lock) lock=xSemaphoreCreateMutex();
  if(!lock) return false;
  Guard guard;if(!guard) return false;
  reminderStorageAttempted=true;
  mkdir("/littlefs/sync",0777);
  reminderStorageReady=reminderOutbox.begin("/littlefs/reminders") && notificationStore.begin("/littlefs/sync/notification.bin");
  return reminderStorageReady;
}
inline bool stageReminder(const Reminders::Request& request) {
  Detail::Guard guard;
  const bool saved=guard && Detail::reminderStorageReady && Detail::reminderOutbox.stage(request,AudioFile::kPendingPath);
  if(saved) { Detail::reminderWritesPending=true;if(Detail::worker) xTaskNotifyGive(Detail::worker); }
  return saved;
}
inline int recoverReminderRecording() {
  Detail::Guard guard;
  if(!guard) return -1;
  // A committed claim may outlive server submission and reset before WAV ACK.
  // Reinsert the exact UUID/deadline, then consume source only after persistence.
  const auto audio=AudioFile::recoverPending();
  if(audio==AudioFile::PendingStatus::Missing || audio==AudioFile::PendingStatus::Empty) return 0;
  if(audio!=AudioFile::PendingStatus::Ready) return -1;
  char claim[256];AudioFile::sidecarPath(AudioFile::kPendingPath,".reminder",claim);
  struct stat claimInfo{};
  if(stat(claim,&claimInfo)!=0) return errno==ENOENT?0:-1;
  if(!Detail::reminderStorageReady) return -1;
  const int recovered=Detail::reminderOutbox.recoverClaim(AudioFile::kPendingPath);
  if(recovered<=0) return recovered;
  return AudioFile::acknowledgeSaved()?1:-1;
}
inline uint32_t notificationRevision() { return Detail::notificationRevision.load(); }
inline bool notificationSnapshot(Notifications::Delivery& out,bool& pending) {
  Detail::Guard guard(20);if(!guard) return false;
  pending=Detail::notificationStore.pending();if(pending) out=Detail::notificationStore.delivery();return true;
}
inline bool dismissNotification(const char* id) {
  Detail::Guard guard;
  if(!guard || !Detail::notificationStore.dismiss(id)) return false;
  ++Detail::notificationRevision;return true;
}
inline bool beginSync(const DesignSpec* actuallyApplied = nullptr) {
  using namespace Detail;
  if (worker) return true;
  if (!ServerTransport::configured() || !*ServerConfig::kToken)
    return false;
  mkdir("/littlefs/sync", 0777);
  mkdir(kDirectory, 0777);
  if(!lock) lock = xSemaphoreCreateMutex();
  if (!lock) return false;
  if(!calories) {
    void* memory=heap_caps_malloc(sizeof(Calories::Summary),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(memory) calories=new(memory) Calories::Summary{};
    else caloriesStatus=Calories::Status::Error;
  }
  beginReminderStorage();
  inboxStorageReady=beginInboxStorage();
  if(!inboxStorageReady) Serial.println("[INBOX] Receipt storage unavailable; deliveries remain on server");
  snprintf(deviceId, sizeof deviceId, "lcd-%012llx", static_cast<unsigned long long>(ESP.getEfuseMac()));
  ESP.getSketchMD5().toCharArray(firmwareMd5, sizeof firmwareMd5);
  audioPending = AudioFile::pendingBytes() > 0;
  readDeletionJournal(kJournal, journal);
  if (actuallyApplied)
    active = *actuallyApplied;
  else
    resetDesign(active);
  // A startup fallback may be playing previous.json. Promote that successfully
  // applied manifest before GC can discard previous to reserve a long recording.
  if (actuallyApplied) {
    JsonDocument stored(&allocator);
    encodeDesign(active, stored);
    if (!writeJsonFile("/littlefs/design/active.json", stored)) {
      vSemaphoreDelete(lock);
      lock = nullptr;
      return false;
    }
  }
  collect(false);
  sampleFilesystemSpace(); // One initial sample during startup, before rendering.
  filesystemSampleAt=millis();
  ready = true;
  if (xTaskCreatePinnedToCore(task, "device-sync", 16384, nullptr, 1, &worker, 0) != pdPASS) {
    worker = nullptr;
    ready = false;
    vSemaphoreDelete(lock);
    lock = nullptr;
    return false;
  }
  return true;
}
inline void updateSync(const JsonDocument& telemetry, bool busy, bool audioPending = false) {
  const bool wasBusy=Detail::busy.exchange(busy);
  Detail::audioPending = audioPending;
  static bool previousOnline=false;
  const bool online=WiFi.status()==WL_CONNECTED;
  if((wasBusy!=busy || previousOnline!=online) && Detail::worker) xTaskNotifyGive(Detail::worker);
  previousOnline=online;
  // This is main-loop owned. Counts change after successful local saves/deletes;
  // a dark screen must not postpone these durable user writes until routine sync.
  static int previousNotes=-1;
  const int notes=NotesDetail::runtime.store.count();
  if(notes!=previousNotes) {
    previousNotes=notes;Detail::localWritesPending=true;
    if(Detail::worker) xTaskNotifyGive(Detail::worker);
  }
  if (!Detail::lock || telemetry.isNull() || !telemetry.size()) return;
  Detail::Guard guard(0);
  if (!guard) return;
  JsonDocument packet(&Detail::allocator);
  packet["telemetry"] = telemetry.as<JsonVariantConst>();
  const size_t bytes = measureJson(packet);
  if (bytes < sizeof Detail::telemetry) serializeJson(packet, Detail::telemetry, sizeof Detail::telemetry);
}
inline void showCalories(bool visible,bool clockTrusted) {
  Detail::caloriesVisible.store(visible);
  Detail::caloriesClockTrusted.store(clockTrusted);
}
inline void refreshCalories() {
  Detail::Guard guard(0);
  if(!guard || Calories::needsHeartbeat(Detail::calories,Detail::caloriesReceivedAt.load(),millis(),
      int64_t(time(nullptr)),Detail::caloriesClockTrusted.load())) {
    Detail::caloriesRefreshPending=true;Detail::refreshPollRequested=true;
    if(Detail::worker) xTaskNotifyGive(Detail::worker);
  }
  ++Detail::caloriesChanged;
}
inline bool caloriesCacheReady(uint32_t& age) {
  Detail::Guard guard(0);if(!guard) { age=0;return false; }
  age=Detail::calories && Detail::calories->text[0]?uint32_t(millis()-Detail::caloriesReceivedAt.load()):0;
  return Calories::current(Detail::calories,int64_t(time(nullptr)),Detail::caloriesClockTrusted.load());
}
inline uint32_t caloriesRevision() { return Detail::caloriesChanged.load(); }
inline bool caloriesBody(char* output,size_t capacity,int64_t epoch,bool trusted,bool online) {
  Detail::Guard guard(0);if(!guard) return false;
  return Calories::format(Detail::calories,Detail::caloriesStatus,epoch,trusted,online,output,capacity);
}
// Main-loop only: publish the receipt after a synchronous voice result was
// durably saved/displayed. No network call, WAV access or new voice request.
inline bool markResultApplied(const char* id) {
  if(!Inbox::lowerHex(id,32)) return false;
  Detail::Guard guard(20);
  if(!guard || !Detail::inboxStorageReady || !Detail::inboxReceipts.markApplied(id)) return false;
  Detail::queueInboxAck(id); return true;
}
template<class Save,class Show>
inline bool consumeInbox(bool busy,bool pointerDown,bool readerOccupied,const char* erroredJob,
                         Save save,Show show,bool& recoveredError) {
  recoveredError=false;
  Detail::Guard guard(0);
  if(!guard || !Detail::inboxStorageReady || !Detail::inboxPending) return false;
  auto& delivery=Detail::inboxDelivery;
  const bool matching=Inbox::matchesError(erroredJob && *erroredJob,erroredJob,delivery.id);
  if(!Inbox::canApply(delivery.kind,busy,pointerDown,readerOccupied,matching)) return false;
  if(Detail::inboxApplyFailed && uint32_t(millis()-Detail::inboxApplyAt)<1000) return false;
  const auto deletion=delivery.noteId?Inbox::deletionState("/littlefs/notes",delivery.noteId):NoteDeletions::State::Clear;
  const auto applied=Inbox::consume(delivery,Detail::inboxReceipts,save,show,deletion);
  if(applied==Inbox::Applied::Failed) {
    Detail::inboxApplyFailed=true; Detail::inboxApplyAt=millis(); return false;
  }
  Detail::queueInboxAck(delivery.id); Detail::inboxPending=false; Detail::inboxApplyFailed=false;
  recoveredError=matching;
  return applied==Inbox::Applied::New || matching;
}
inline bool takeDesign(DesignSpec& spec) {
  Detail::Guard guard(0);
  if (!guard || Detail::designBusy() || !Detail::havePending) return false;
  spec = Detail::pending;
  Detail::havePending = false;
  Detail::progress.applying(spec.version);
  Detail::progressChanged = true;
  return true;
}
inline bool commitDesign(const DesignSpec& spec) {
  Detail::Guard guard;
  if (!guard || Detail::busy.load()) return false;
  JsonDocument current(&Detail::allocator);
  if (Detail::active.version) {
    Detail::encodeDesign(Detail::active, current);
    if (!Detail::writeJsonFile("/littlefs/design/previous.json", current)) return false;
  }
  Detail::encodeDesign(spec, current);
  if (!Detail::writeJsonFile("/littlefs/design/active.json", current)) return false;
  Detail::active = spec;
  remove("/littlefs/design/next.json");
  Detail::collect(false);
  return true;
}
inline void markApplied(uint32_t version, const char* error = nullptr) {
  Detail::applied = version;
  Detail::Guard guard;
  if (guard) {
    Detail::errorState.applied(error);
    if (error && *error) Detail::progress.failed(version, error);
    else Detail::progress.applied(version);
    Detail::progressChanged = true;
  }
}
inline void rejectDesign(uint32_t version, const char* error) {
  Detail::rejected = version;
  Detail::Guard guard;
  if (guard) {
    Detail::errorState.permanent(error);
    Detail::progress.failed(version, error);
    Detail::progressChanged = true;
  }
}
inline bool nextDeletion(uint32_t& id) {
  Detail::Guard guard(0);
  if (!guard || !Detail::journal.count) return false;
  id = Detail::journal.ids[0];
  return true;
}
inline bool ackDeletion(uint32_t id) {
  Detail::Guard guard;
  if (!guard || !Detail::journal.count || Detail::journal.ids[0] != id) return false;
  // The outgoing marker is transport state, not permanent deletion knowledge.
  // Commit the latter first: an older inbox response may already be in RAM or
  // still in flight, even though the server has now acknowledged this deletion.
  if(!NoteDeletions::remember("/littlefs/notes",id)) return false;
  char marker[128];
  snprintf(marker, sizeof marker, "/littlefs/notes/d%08lx.del", static_cast<unsigned long>(id));
  if (remove(marker) != 0 && errno != ENOENT) return false;
  auto& journal = Detail::journal;
  for (size_t i = 1; i < journal.count; ++i) journal.ids[i - 1] = journal.ids[i];
  --journal.count;
  if (!writeDeletionJournal(Detail::kJournal, journal)) {
    // The old file remains authoritative after a failed atomic write. Restore
    // the small in-memory edit so the same deletion will be retried.
    for (size_t i = journal.count; i > 0; --i) journal.ids[i] = journal.ids[i - 1];
    journal.ids[0] = id;
    ++journal.count;
    return false;
  }
  return true;
}
inline uint32_t takeServerTime() { return Detail::serverTime.exchange(0); }
inline void setPowerIdle(bool idle) {
  if(Detail::powerIdle.exchange(idle)!=idle && Detail::worker) xTaskNotifyGive(Detail::worker);
}
// Display sleep must not interrupt an in-flight design transfer/activation.
// Main-loop snapshot: ordinary heartbeat lock contention must not count as
// user activity and indefinitely postpone dimming every ten seconds.
inline bool updatingDesign() {
  if(!Detail::ready.load()) return false;
  static bool previous=false;
  Detail::Guard guard(0);
  if(!guard) return previous;
  const auto stage=Detail::progress.stage();
  previous=stage==DesignUpdateProgress::Stage::Downloading || stage==DesignUpdateProgress::Stage::Verifying ||
      stage==DesignUpdateProgress::Stage::Applying || Detail::havePending;
  return previous;
}
inline bool filesystemFreeSnapshot(uint32_t& bytes) { return Detail::filesystemSpace.snapshot(bytes); }
inline void printDiagnostics() {
  const uint32_t now=millis();
  const auto gate=NetworkGate::gate.snapshot();
  bool locked=false,pending=false; const char* stage="locked"; uint32_t version=0,bytes=0,total=0;
  {
    Detail::Guard guard(0); locked=bool(guard);
    if(guard) {
      pending=Detail::havePending; stage=Detail::progress.stageName();
      version=Detail::progress.version();bytes=Detail::progress.bytes();total=Detail::progress.total();
    }
  }
  const auto ip=WiFi.localIP();
  // Print::printf allocates for lines longer than its 64 B scratch buffer.
  // Keep diagnostics usable while TLS is failing from internal-heap pressure.
  char line[512];
  snprintf(line,sizeof line,"[SYNC-DIAG] uptime_ms=%lu applied=%lu ready=%u busy=%u audio=%u lock_ok=%u pending=%u worker=%08lx worker_state=%d stack=%lu wifi=%d ip=%u.%u.%u.%u rssi=%d epoch=%lld gate=%08lx wait_voice=%u voice_owner=%u\n",
      (unsigned long)now,(unsigned long)Detail::applied.load(),unsigned(Detail::ready.load()),
      unsigned(Detail::busy.load()),unsigned(Detail::audioPending.load()),unsigned(locked),unsigned(pending),
      (unsigned long)reinterpret_cast<uintptr_t>(Detail::worker),
      Detail::worker?int(eTaskGetState(Detail::worker)):-1,
      Detail::worker?(unsigned long)uxTaskGetStackHighWaterMark(Detail::worker):0UL,
      int(WiFi.status()),unsigned(ip[0]),unsigned(ip[1]),unsigned(ip[2]),unsigned(ip[3]),int(WiFi.RSSI()),
      (long long)time(nullptr),(unsigned long)gate.owner,gate.waitingVoice,unsigned(gate.voiceOwner));
  Serial.print(line);
  snprintf(line,sizeof line,"[SYNC-DESIGN] stage=%s version=%lu bytes=%lu/%lu\n",stage,
      (unsigned long)version,(unsigned long)bytes,(unsigned long)total);
  Serial.print(line);
  const auto printTrace=[now,&line](const char* name,const SyncRequestSnapshot& value) {
    snprintf(line,sizeof line,"[SYNC-%s] endpoint=%s stage=%s age_ms=%lu phase_ms=%lu status=%ld tls=%ld\n",name,
        syncEndpointName(value.endpoint),syncStageName(value.stage),(unsigned long)(now-value.startedAt),
        (unsigned long)(now-value.changedAt),(long)value.status,(long)value.tlsError);
    Serial.print(line);
  };
  printTrace("HTTP",Detail::requestTrace.snapshot()); printTrace("ASSET",Detail::downloadTrace.snapshot());
  snprintf(line,sizeof line,"[RECORD-STORAGE] lock_last_us=%lu lock_max_us=%lu reclaim_count=%lu reclaim_last_us=%lu\n",
      (unsigned long)Detail::recordingLockWaitUs.load(),(unsigned long)Detail::recordingLockWaitMaxUs.load(),
      (unsigned long)Detail::recordingGcCount.load(),(unsigned long)Detail::recordingGcLastUs.load());
  Serial.print(line);
}
inline void beforeRecording() {
  // Main-loop publication only: no semaphore, file cleanup or collection before
  // notifying voice_ai. Asset work observes this flag between transport calls.
  Detail::busy.store(true,std::memory_order_release);
  if(Detail::worker) xTaskNotifyGive(Detail::worker);
}
inline bool prepareRecording(size_t requiredBytes) {
  using namespace Detail;
  const uint32_t started=micros();
  Guard guard(250);
  const uint32_t waited=uint32_t(micros()-started);
  recordingLockWaitUs.store(waited);
  if(waited>recordingLockWaitMaxUs.load()) recordingLockWaitMaxUs.store(waited);
  if(!guard) return false;
  return RecordingStorage::prepare(requiredBytes,[] {
    if(!closeAssetPart(true)) return false;
    havePending=false;
    if(progress.stage()==DesignUpdateProgress::Stage::Downloading ||
       progress.stage()==DesignUpdateProgress::Stage::Verifying) {
      progress.waiting();progressChanged=true;
    }
    return true;
  },[] {
    size_t total=0,used=0;
    if(esp_littlefs_info(kFilesystemPartitionLabel,&total,&used)!=ESP_OK)
      return RecordingStorage::Space{};
    const RecordingStorage::Space space{total,used};
    filesystemSpace.accept(space.total,space.used);
    return space;
  },[] {
    const uint32_t at=micros();
    collect(true);
    recordingGcLastUs.store(uint32_t(micros()-at));
    recordingGcCount.fetch_add(1);
    return true;
  });
}
}  // namespace Tamagotchi::ServerSync
#endif
