#pragma once
#include "display_touch.h"
#include "state_info.h"
#include "character_animation.h"
#include "menu.h"
#include "ai.h"
#include "notes.h"
#include "device_sync.h"
#include "recorder_ui.h"
#include "menu_pages.h"
#include "power.h"
#include "power_ui.h"
#include "power_runtime.h"
#include "power_management.h"

namespace Tamagotchi::AppDetail {
enum class StoredVoiceResult { SaveFailed,Saved,DisplayFailed };
inline bool voiceBlocksInbox(AiState state,bool active,bool characterActive) {
  // A worker may publish Done after the main loop sampled aiResultReady.
  // The synchronous final must publish its receipt before inbox delivery.
  return active || state==AiState::Done || characterActive;
}
// The server's acknowledgement never substitutes for this device's durable
// note save. Preview dismissal affects presentation only, not persistence.
inline StoredVoiceResult applyStoredVoiceResult(const char* text,uint32_t noteId,const char* title,
                                                const char* confirmation,bool shopping,bool present) {
  if(!saveVoiceNote(text,false,noteId)) return StoredVoiceResult::SaveFailed;
  if(!present) return StoredVoiceResult::Saved;
  const char* heading=shopping?ShoppingNotes::kHeading:"Note";
  const char* body=shopping?ShoppingNotes::body(text):confirmation;
  if(!body || !*body) body=shopping?text:"Note saved.";
  return showAssistantAnswer(title && *title?title:heading,body,"",heading)?
      StoredVoiceResult::Saved:StoredVoiceResult::DisplayFailed;
}
} // namespace Tamagotchi::AppDetail

#ifdef ARDUINO
#include <esp_ota_ops.h>
namespace Tamagotchi {
namespace AppDetail {
struct Runtime {
  Power::Controller power;
  Power::View powerView{Power::Stage::Active,100,true};
  PowerUi::Settings powerSettings;
  PowerUi::View powerPage;
  HoldButton minusButton;
  DisplayTouchDetail::VerticalScroll scroll, notesScroll, pageScroll;
  MenuGesture menuGesture;
  TapGesture notesGesture, aiGesture, pageGesture;
  MenuPages::View page;
  DailyWeather::Snapshot weather;
  char weatherBody[2048]{};
  uint32_t weatherRevision=UINT32_MAX,configuredPageRevision=UINT32_MAX;
  uint32_t caloriesRevision=UINT32_MAX,caloriesFormattedAt=0;
  int displayedPageOffset=-1;
  bool wasPage=false;
  RecorderUi::View recorder;
  bool wasRecorder=false;
  Notifications::View notificationView;
  Notifications::Delivery notification;
  uint32_t configuredNotificationRevision=UINT32_MAX;
  bool notificationPending=false,wasNotification=false,pointerDown=false,drainTouch=false;
  uint32_t configuredNotesRevision = UINT32_MAX, displayedNotesRevision = UINT32_MAX;
  int displayedNotesOffset = -1, displayedOffset = -1;
  bool wasAiModal = false, memoryReported = false, ready = false;
  bool preserveReaderScroll = false;
  ServerSync::DesignSpec design;
  // Main-only scratch storage keeps large manifests off the 8 KiB loop stack.
  ServerSync::DesignSpec incoming;
  bool customDesign = false;
  uint32_t telemetryAt = 0;
};
inline Runtime runtime;
inline TaskHandle_t inputLoopTask=nullptr;
inline std::atomic<bool> inputWakePending{false};
struct InputWake {
  int pin;
  PowerManagement::WakeLatch latch;
};
inline InputWake plusWake{Board::kPlus,{}},minusWake{Board::kMinus,{}};
inline void ARDUINO_ISR_ATTR wakeInputLoop(void* argument) {
  auto& source=*static_cast<InputWake*>(argument);
  // Light-sleep GPIO wake and ordinary interrupts share the level setting.
  // Mask a held key once; rearm only after release to prevent an IRQ storm.
  gpio_intr_disable(gpio_num_t(source.pin));
  source.latch.fired();
  inputWakePending.store(true,std::memory_order_relaxed);
  BaseType_t higherPriorityWoken=pdFALSE;
  if(inputLoopTask) vTaskNotifyGiveFromISR(inputLoopTask,&higherPriorityWoken);
  if(higherPriorityWoken==pdTRUE) portYIELD_FROM_ISR();
}

inline void configurePower(uint32_t now) {
  auto& state=runtime;
  state.power.setMode(state.powerSettings.rational?Power::Mode::Rational:Power::Mode::Normal,now);
  state.power.setBrightness(state.powerSettings.brightness);
  state.power.setGlance(state.powerSettings.glance);
}
inline void loadPowerSettings() {
  Preferences preferences;
  if(preferences.begin("kibi_power",true)) {
    PowerUi::decode(preferences.getUInt("settings",0),runtime.powerSettings);
    preferences.end();
  }
  runtime.power.begin(runtime.powerSettings.rational?Power::Mode::Rational:Power::Mode::Normal,millis());
  configurePower(millis());
  setDisplayBrightnessPercent(runtime.powerSettings.brightness);
  pinMode(Board::kMinus,INPUT_PULLUP);
}
inline void savePowerSettings() {
  configurePower(millis());
  Preferences preferences;
  const bool opened=preferences.begin("kibi_power",false);
  const bool saved=opened && preferences.putUInt("settings",PowerUi::encode(runtime.powerSettings))==sizeof(uint32_t);
  if(opened) preferences.end();
  if(!saved) Serial.println("[POWER] Settings active; persistent save failed");
}
inline void cancelPowerTouch() {
  auto& state=runtime;
  state.scroll.cancel();state.notesScroll.cancel();state.pageScroll.cancel();
  state.menuGesture.cancel();state.notesGesture.cancel();state.aiGesture.cancel();state.pageGesture.cancel();
  state.recorder.cancelTouch();state.powerPage.cancelTouch();
  state.notificationView.input(Notifications::Input::Cancel,0,0,millis());
  state.pointerDown=false;state.drainTouch=false;
  discardDisplayTouchEvents();
}
inline bool updatePower(uint32_t now) {
  auto& state=runtime;
  const auto& info=StateInfoDetail::runtime.info;
  const bool external=PowerRuntime::confirmedExternalPower(info.chargingKnown && info.charging);
  const bool busy=aiBusy() || characterVoiceActive() || ServerSync::updatingDesign();
  const auto next=state.power.update(now,external || state.powerSettings.alwaysScreen,busy,info.batteryPercent);
  if(next.screenOn) PowerManagement::setInteractive(true);
  const bool changed=next.stage!=state.powerView.stage || next.brightness!=state.powerView.brightness;
  if(state.powerView.screenOn && !next.screenOn) cancelPowerTouch();
  setDisplayBrightnessPercent(next.brightness);
  setDisplayAwake(next.screenOn);
  state.powerView=next;
  const bool ready=tickDisplayPower(now);
  if(!next.screenOn) PowerManagement::setInteractive(false);
  if(ready || changed) state.displayedOffset=-1;
  PowerRuntime::update(state.powerSettings.rational,next.screenOn,aiBusy() || NetworkGate::voiceBusy());
  ServerSync::setPowerIdle(!next.screenOn);
  if(changed) Serial.printf("[POWER] mode=%s stage=%u brightness=%u external=%u override=%u busy=%u battery=%d\n",
      state.powerSettings.rational?"rational":"normal",unsigned(next.stage),unsigned(next.brightness),
      unsigned(external),unsigned(state.powerSettings.alwaysScreen),unsigned(busy),info.batteryPercent);
  return ready || changed;
}

#if defined(KIBI_UI_PROFILE)
// Opt-in USB diagnostic; no code, state or serial command in normal builds.
struct UiPerfSample {
  uint64_t total=0;
  uint32_t count=0,maximum=0,over50=0,over80=0;
  void add(uint32_t microseconds) {
    total+=microseconds;++count;
    if(microseconds>maximum) maximum=microseconds;
    if(microseconds>50000) ++over50;
    if(microseconds>80000) ++over80;
  }
  uint32_t mean() const { return count?uint32_t(total/count):0; }
};
struct UiPerf {
  bool active=false,finishPending=false;
  const char* reason="done";
  uint32_t startedAt=0,elapsed=0,lastFrameAt=0;
  int originalOffset=0,phase=-1;
  UiPerfSample loop,sync,state,character,compose,present,interval;
};
inline UiPerf uiPerf;
inline bool uiPerfHomeReady() {
  return !aiBusy() && !aiModalVisible() && !characterVoiceActive() && !notesVisible() &&
      !runtime.recorder.visible() && !runtime.page.visible() && !runtime.powerPage.visible() && !runtime.notificationView.visible() &&
      !runtime.pointerDown && !runtime.drainTouch;
}
inline void finishUiPerf(const char* reason) {
  if(!uiPerf.active) return;
  uiPerf.elapsed=uint32_t(millis()-uiPerf.startedAt);
  uiPerf.active=false;uiPerf.finishPending=true;uiPerf.reason=reason;
  // Complete the ordinary easing immediately to restore the exact start offset.
  const uint32_t now=millis();
  runtime.scroll.scrollTo(uiPerf.originalOffset,now-300);
  runtime.scroll.tick(now);
  runtime.displayedOffset=-1;
}
inline void tickUiPerf() {
  if(!uiPerf.active) return;
  if(!uiPerfHomeReady()) { finishUiPerf("interrupted");return; }
  const uint32_t age=uint32_t(millis()-uiPerf.startedAt);
  if(age>=8000) { finishUiPerf("done");return; }
  const int phase=int(age/320);
  if(phase!=uiPerf.phase) {
    uiPerf.phase=phase;
    runtime.scroll.scrollTo(phase%2?0:sceneMaxOffset(kScreenHeight),millis());
  }
}
struct UiPerfLoop {
  const uint32_t at=micros();
  const bool sampled=uiPerf.active;
  ~UiPerfLoop() {
    if(sampled) uiPerf.loop.add(uint32_t(micros()-at));
    if(!uiPerf.finishPending) return;
    uiPerf.finishPending=false;
    Serial.setTxTimeoutMs(10); // Only the final diagnostic line may wait briefly.
    Serial.printf("[UI-PERF] result=%s duration_ms=%lu loops=%lu loop_us=%lu/%lu over50=%lu over80=%lu sync_us=%lu/%lu state_us=%lu/%lu character_us=%lu/%lu frames=%lu compose_us=%lu/%lu present_us=%lu/%lu interval_us=%lu/%lu intervals=%lu\n",
        uiPerf.reason,(unsigned long)uiPerf.elapsed,(unsigned long)uiPerf.loop.count,
        (unsigned long)uiPerf.loop.mean(),(unsigned long)uiPerf.loop.maximum,
        (unsigned long)uiPerf.loop.over50,(unsigned long)uiPerf.loop.over80,
        (unsigned long)uiPerf.sync.mean(),(unsigned long)uiPerf.sync.maximum,
        (unsigned long)uiPerf.state.mean(),(unsigned long)uiPerf.state.maximum,
        (unsigned long)uiPerf.character.mean(),(unsigned long)uiPerf.character.maximum,
        (unsigned long)uiPerf.compose.count,(unsigned long)uiPerf.compose.mean(),(unsigned long)uiPerf.compose.maximum,
        (unsigned long)uiPerf.present.mean(),(unsigned long)uiPerf.present.maximum,
        (unsigned long)uiPerf.interval.mean(),(unsigned long)uiPerf.interval.maximum,(unsigned long)uiPerf.interval.count);
    Serial.setTxTimeoutMs(0);
  }
};
#endif

inline const char* backgroundPath(const ServerSync::DesignSpec& design) {
  return design.background >= 0 ? design.assets[design.background].path : theme().backgroundPath;
}

inline bool loadDesignCharacter(const ServerSync::DesignSpec& design) {
  CharacterClipConfig clips[7];
  int count = 0;
  const char* charge = theme().chargeAnimationPath;
  const char* record = nullptr;
  bool chargeEnabled = false;
  for (int i = 0; i < design.animationCount; ++i) {
    const auto& source = design.animations[i];
    if (!strcmp(source.role, "charge")) {
      charge = design.assets[source.asset].path;
      chargeEnabled = source.enabled;
      continue;
    }
    if(!strcmp(source.role,"record")) {
      if(source.enabled) record=design.assets[source.asset].path;
      continue;
    }
    if (!source.enabled || count >= 7) continue;
    auto& clip = clips[count++];
    clip.path = design.assets[source.asset].path;
    clip.rule.enabled = true;
    clip.rule.trigger = source.trigger;
    clip.rule.intervalSeconds = source.intervalSeconds;
    clip.rule.priority = source.priority;
    clip.rule.start = source.start;
    clip.rule.end = source.end;
    clip.rule.repeat = source.repeat;
    const int role=ServerSync::roleIndex(source.role);
    clip.rule.randomized=role>=8 && role<=13;
  }
  return loadCharacterDesign(charge, chargeEnabled, clips, count,
                             design.hero >= 0 ? design.assets[design.hero].path : nullptr, millis(),record);
}

inline bool restoreCharacter() {
  return runtime.customDesign ? loadDesignCharacter(runtime.design)
                              : loadCharacter(theme().chargeAnimationPath, theme().jumpAnimationPath);
}

inline bool applyDesign(const ServerSync::DesignSpec& candidate) {
  // Rendering and asset activation always happen on the main loop.
  if (!loadDesignCharacter(candidate)) {
    restoreCharacter();
    ServerSync::rejectDesign(candidate.version, "Could not open the animation.");
    return false;
  }
  if (!DisplayTouchDetail::loadBackground(backgroundPath(candidate))) {
    restoreCharacter();
    ServerSync::rejectDesign(candidate.version, "Could not open the background.");
    return false;
  }
  if (!ServerSync::commitDesign(candidate)) {
    DisplayTouchDetail::loadBackground(runtime.customDesign ? backgroundPath(runtime.design)
                                                            : theme().backgroundPath);
    restoreCharacter();
    ServerSync::rejectDesign(candidate.version, "Could not save the design.");
    return false;
  }
  runtime.design = candidate;
  runtime.customDesign = true;
  ServerSync::markApplied(candidate.version, nullptr);
  Serial.printf("[SYNC] Applied design version=%lu\n", (unsigned long)candidate.version);
  return true;
}

inline bool applyInbox() {
  const char* failedJob=aiState()==AiState::Error?aiReply().jobId:"";
  const bool occupied=notesDetailVisible() || runtime.recorder.visible() || runtime.powerPage.visible() || runtime.notificationView.visible() || aiModalVisible();
  bool recovered=false;
  const bool applied=ServerSync::consumeInbox(voiceBlocksInbox(aiState(),aiBusy(),characterVoiceActive()),
      runtime.pointerDown || runtime.drainTouch,occupied,failedJob,
      [](uint32_t id,const char* text) {
        const bool saved=saveVoiceNote(text,false,id);
        runtime.preserveReaderScroll=saved && notesDetailVisible();
        return saved;
      },
      [](const char* heading,const char* title,const char* text) {
        const bool shown=showAssistantAnswer(title,text,"",heading);
        if(shown && runtime.recorder.visible()) runtime.recorder.complete(true);
        return shown;
      },recovered);
  if(recovered) {
    if(runtime.recorder.visible() && aiContinuousRecording()) runtime.recorder.complete(false);
    dismissAi();
  }
  if(applied) runtime.power.notify(millis());
  return applied;
}

inline RecorderUi::Snapshot recorderSnapshot() {
  const auto state=aiState();
  return {aiBusy(),aiContinuousRecording(),state==AiState::Starting || state==AiState::Recording,
          state==AiState::Starting,aiRecordingElapsedMs()};
}
inline void openRecorder() {
  runtime.powerPage.close();
  runtime.recorder.open();
  runtime.recorder.update(recorderSnapshot());
  runtime.displayedOffset=-1;
}
inline void openPowerSettings() {
  runtime.page.close();
  runtime.powerPage.open(runtime.powerSettings);
  runtime.displayedOffset=-1;
}

inline bool refreshWeatherBody() {
  return runtime.page.isWeather() && MenuPages::formatWeatherPageBody(runtime.weather,runtime.weatherBody,
      sizeof runtime.weatherBody) && runtime.page.setBody(runtime.weatherBody);
}
inline bool refreshCaloriesBody() {
  return runtime.page.isCalories() && ServerSync::caloriesBody(runtime.weatherBody,sizeof runtime.weatherBody,
      int64_t(time(nullptr)),WifiDetail::timeSynchronized,WiFi.status()==WL_CONNECTED) &&
      runtime.page.setBody(runtime.weatherBody);
}
inline void openMenuPage(int item) {
  const auto* module=menuModule(item);
  if(!module || !runtime.page.open(*module)) return;
  runtime.powerPage.close();
  refreshWeatherBody();
  if(runtime.page.isCalories()) {
    ServerSync::showCalories(true,WifiDetail::timeSynchronized);
    ServerSync::refreshCalories();refreshCaloriesBody();
  }
  runtime.pageScroll.setRange(runtime.page.scrollLimit(kScreenWidth,kScreenHeight),true);
  runtime.displayedOffset=-1;
}
inline bool updateDailyWeather() {
  DailyWeather::update(runtime.powerView.screenOn && !aiBusy() && !characterVoiceActive(),
      WifiDetail::timeSynchronized,!runtime.powerView.screenOn);
  const uint32_t revision=DailyWeather::revision();
  if(runtime.pointerDown || runtime.weatherRevision==revision || !DailyWeather::snapshot(runtime.weather)) return false;
  runtime.weatherRevision=revision;
  return refreshWeatherBody();
}
inline bool updateCalories() {
  const bool visible=runtime.page.isCalories() && !notesVisible() && !runtime.recorder.visible() &&
      !runtime.notificationView.visible() && !aiModalVisible();
  ServerSync::showCalories(visible,WifiDetail::timeSynchronized);
  if(!visible || runtime.pointerDown) return false;
  const uint32_t revision=ServerSync::caloriesRevision(),now=millis();
  // Reformat at most once a second without allocations: Wi-Fi/time status and
  // midnight can change even when no network response has arrived.
  if(revision==runtime.caloriesRevision && uint32_t(now-runtime.caloriesFormattedAt)<1000) return false;
  runtime.caloriesRevision=revision;runtime.caloriesFormattedAt=now;
  return refreshCaloriesBody();
}

inline void updateServerSync() {
  const bool busy = aiBusy() || characterVoiceActive();
  // Pass busy every loop; publish a small telemetry snapshot once per second.
  JsonDocument telemetry;
  if (uint32_t(millis() - runtime.telemetryAt) >= (runtime.powerView.screenOn?1000u:10000u)) {
    runtime.telemetryAt = millis();
    const auto& info = StateInfoDetail::runtime.info;
    telemetry["battery_percent"] = info.batteryPercent;
    telemetry["charging"] = info.chargingKnown && info.charging;
    telemetry["power_pm_enabled"] = PowerManagement::automaticSleepEnabled();
    telemetry["power_stage"] = unsigned(runtime.powerView.stage);
    telemetry["power_wake_cause"] = unsigned(esp_sleep_get_wakeup_cause());
    telemetry["power_cpu_mhz"] = unsigned(getCpuFrequencyMhz());
    telemetry["wifi_level"] = info.wifiLevel;
    telemetry["heap_free"] = ESP.getFreeHeap();
    telemetry["heap_min"] = ESP.getMinFreeHeap();
    telemetry["heap_largest"] = ESP.getMaxAllocHeap();
    const auto tls=TlsDiagnostics::snapshot();
    telemetry["tls_live"] = tls.liveContexts;
    telemetry["tls_peak"] = tls.peakContexts;
    if(tls.heapSamples) {
      telemetry["tls_internal_min"] = tls.minInternalFree;
      telemetry["tls_largest_min"] = tls.minInternalLargest;
    }
    const auto capture=aiRecordingStartSnapshot();
    telemetry["record_start_max_us"] = capture.requestToFirstPcm.maxUs;
    telemetry["record_preflight_max_us"] = capture.preflight.maxUs;
    telemetry["psram_free"] = ESP.getFreePsram();
    telemetry["reset_reason"] = uint32_t(esp_reset_reason());
    telemetry["loop_stack_min"] = uint32_t(uxTaskGetStackHighWaterMark(nullptr));
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
    if(RealtimeVoice::Detail::runtime.task)
      telemetry["realtime_stack_min"] = uint32_t(uxTaskGetStackHighWaterMark(RealtimeVoice::Detail::runtime.task));
    const auto voice=RealtimeVoice::connectionDiagnostics();
    telemetry["voice_phase"]=RealtimeVoice::connectionPhaseName(voice.phase);
    telemetry["voice_phase_ms"]=voice.ageMs;
    telemetry["voice_gate_wait_ms"]=voice.gateWaitMs;
    telemetry["voice_gate_failures"]=voice.gateFailures;
    telemetry["voice_connect_ms"]=voice.connectMs;
    telemetry["voice_tls_error"]=voice.tlsError;
    telemetry["voice_upgrade_status"]=voice.upgradeStatus;
#endif
    uint32_t freeBytes=0;
    if(ServerSync::filesystemFreeSnapshot(freeBytes)) telemetry["fs_free"]=freeBytes;
    telemetry["recording"] = aiRecording();
    telemetry["audio_pending"] = aiHasPendingAudio();
    telemetry["notes"] = NotesDetail::runtime.store.count();
    telemetry["uptime_s"] = millis() / 1000;
    telemetry["power_mode"] = runtime.powerSettings.rational?"rational":"normal";
    telemetry["screen_on"] = runtime.powerView.screenOn;
    telemetry["screen_brightness"] = runtime.powerView.brightness;
  }
  ServerSync::updateSync(telemetry, busy, aiHasPendingAudio());
  if (const uint32_t epoch = ServerSync::takeServerTime()) acceptTrustedServerTime(epoch);
  // File deletion and asset activation can wait until the gesture has settled.
  if (busy || runtime.pointerDown || runtime.drainTouch || runtime.scroll.active() ||
      runtime.notesScroll.active() || runtime.pageScroll.active()) return;
  uint32_t id = 0;
  if (ServerSync::nextDeletion(id) && applyRemoteNoteDeletion(id)) ServerSync::ackDeletion(id);
  if (ServerSync::takeDesign(runtime.incoming) && applyDesign(runtime.incoming)) runtime.displayedOffset = -1;
}
inline void printUiDiagnostics() {
#if KIBI_UI_DIAGNOSTICS
  const auto metrics=UiDiagnostics::snapshot();
  char line[256];
  snprintf(line,sizeof line,"[UI-DIAG] enabled=1 poll_count=%lu enqueue_failures=%lu overflow_cancels=%lu bucket_us=%lu\n",
      (unsigned long)metrics.pollCount,(unsigned long)metrics.enqueueFailures,(unsigned long)metrics.overflowCancels,
      (unsigned long)UiDiagnostics::kBucketWidthUs);
  Serial.print(line);
  const auto print=[&line](const char* name,const UiDiagnostics::HistogramSnapshot& histogram) {
    const auto p95=histogram.percentileUpperBound(95),p99=histogram.percentileUpperBound(99);
    snprintf(line,sizeof line,"[UI-TIMING] metric=%s count=%lu last_us=%lu max_us=%lu p95_upper_us=%lu p95_overflow=%u p99_upper_us=%lu p99_overflow=%u overflow=%lu\n",
        name,(unsigned long)histogram.count,(unsigned long)histogram.lastUs,(unsigned long)histogram.maxUs,
        (unsigned long)p95.upperUs,unsigned(p95.overflow),(unsigned long)p99.upperUs,unsigned(p99.overflow),
        (unsigned long)histogram.overflow);
    Serial.print(line);
  };
  print("compose",metrics.compose);print("present",metrics.present);print("interval",metrics.interval);
  print("i2c",metrics.i2cRead);print("queue-age",metrics.queueAge);print("sample-to-spi",metrics.sampleToSpi);
#else
  Serial.println("[UI-DIAG] enabled=0; build with KIBI_UI_DIAGNOSTICS=1 for timing histograms");
#endif
}
// Printed after startup, or on Serial command 'm', so measurements include Wi-Fi
// and all decoded assets. Internal RAM and external PSRAM are separate heaps.
inline void printMemoryInfo() {
  const auto* app = esp_ota_get_running_partition();
  const uint32_t sketch = ESP.getSketchSize();
  const uint32_t capacity = app ? app->size : 0;
  Serial.printf("[MEMORY] app used=%lu total=%lu free=%lu flash=%lu\n", (unsigned long)sketch,
                (unsigned long)capacity, (unsigned long)(capacity > sketch ? capacity - sketch : 0),
                (unsigned long)ESP.getFlashChipSize());
  Serial.printf("[MEMORY] internal heap free=%lu total=%lu largest=%lu minimum=%lu\n",
                (unsigned long)ESP.getFreeHeap(), (unsigned long)ESP.getHeapSize(),
                (unsigned long)ESP.getMaxAllocHeap(), (unsigned long)ESP.getMinFreeHeap());
  Serial.printf("[MEMORY] PSRAM free=%lu total=%lu largest=%lu\n", (unsigned long)ESP.getFreePsram(),
                (unsigned long)ESP.getPsramSize(), (unsigned long)ESP.getMaxAllocPsram());
  Serial.printf("[MEMORY] LittleFS used=%lu total=%lu free=%lu\n", (unsigned long)LittleFS.usedBytes(),
                (unsigned long)LittleFS.totalBytes(),
                (unsigned long)(LittleFS.totalBytes() - LittleFS.usedBytes()));
  Serial.printf("[AI] microphone=%s state=%u notes=%d\n", AiDetail::runtime.ready ? "ready" : "unavailable",
                unsigned(aiState()), NotesDetail::runtime.store.count());
  Serial.printf("[MEMORY] loop stack minimum free=%lu bytes\n",
                (unsigned long)uxTaskGetStackHighWaterMark(nullptr));
  Serial.printf("[BOOT] reset reason=%u\n",unsigned(esp_reset_reason()));
  if(AiDetail::runtime.task)
    Serial.printf("[MEMORY] voice stack minimum free=%lu bytes\n",
                  (unsigned long)uxTaskGetStackHighWaterMark(AiDetail::runtime.task));
  const auto tls=TlsDiagnostics::snapshot();
  char line[384];
  snprintf(line,sizeof line,"[TLS-DIAG] live_contexts=%lu peak_contexts=%lu connect_attempts=%lu connect_failures=%lu connect_max_ms=%lu sampled_internal_min=%lu sampled_largest_min=%lu heap_samples=%lu\n",
      (unsigned long)tls.liveContexts,(unsigned long)tls.peakContexts,(unsigned long)tls.connectAttempts,
      (unsigned long)tls.connectFailures,(unsigned long)tls.maxConnectMs,(unsigned long)tls.minInternalFree,
      (unsigned long)tls.minInternalLargest,(unsigned long)tls.heapSamples);
  Serial.print(line);
  const auto capture=aiRecordingStartSnapshot();
  snprintf(line,sizeof line,"[RECORD-START] stage=%u attempts=%lu worker_last_us=%lu worker_max_us=%lu preflight_last_us=%lu preflight_max_us=%lu preflight_count=%lu\n",
      unsigned(capture.stage),(unsigned long)capture.attempts,(unsigned long)capture.requestToWorker.lastUs,
      (unsigned long)capture.requestToWorker.maxUs,(unsigned long)capture.preflight.lastUs,
      (unsigned long)capture.preflight.maxUs,(unsigned long)capture.preflight.count);
  Serial.print(line);
  snprintf(line,sizeof line,"[RECORD-PCM] worker_first_last_us=%lu worker_first_max_us=%lu request_first_last_us=%lu request_first_max_us=%lu first_count=%lu\n",
      (unsigned long)capture.workerToFirstPcm.lastUs,(unsigned long)capture.workerToFirstPcm.maxUs,
      (unsigned long)capture.requestToFirstPcm.lastUs,(unsigned long)capture.requestToFirstPcm.maxUs,
      (unsigned long)capture.requestToFirstPcm.count);
  Serial.print(line);
  ServerSync::printDiagnostics();
  printUiDiagnostics();
}

inline void drawFrame(int offsetY) {
  if(!displayReadyToPresent()) return;
#if KIBI_UI_DIAGNOSTICS
  const uint32_t diagnosticComposeAt=micros();
#endif
#if defined(KIBI_UI_PROFILE)
  const uint32_t composeAt=micros();
  if(uiPerf.active) {
    if(uiPerf.compose.count) uiPerf.interval.add(uint32_t(composeAt-uiPerf.lastFrameAt));
    uiPerf.lastFrameAt=composeAt;
  }
#endif
  auto* frame = prepareDisplayFrame(offsetY);
  if (!frame) return;
  if(aiPreviewVisible()) { /* The transient reader is drawn by drawAi below. */ }
  else if(runtime.recorder.visible()) RecorderUi::draw(frame,kScreenWidth,kScreenHeight,runtime.recorder);
  else if(runtime.powerPage.visible()) PowerUi::draw(frame,kScreenWidth,kScreenHeight,runtime.powerPage);
  else if (notesVisible())
    drawNotes(frame, kScreenWidth, kScreenHeight, runtime.notesScroll.offsetY(),
              runtime.notesGesture.pressedTarget());
  else if(runtime.page.visible())
    MenuPages::draw(frame,kScreenWidth,kScreenHeight,runtime.page,runtime.pageScroll.offsetY(),
                    runtime.pageGesture.pressedTarget()==0);
  else {
    const auto* pixels = characterPixels();
    const auto& metadata = characterMetadata();
    if (pixels)
      drawCharacter(frame, kScreenWidth, kScreenHeight, pixels, offsetY, metadata.width, metadata.height,
                    theme().characterX + (256 - metadata.width) / 2 + characterHorizontalCorrection(),
                    theme().characterY + (256 - metadata.height) +
                        (runtime.customDesign ? runtime.design.characterYOffset : 0));
    drawSceneMenu(frame, kScreenWidth, kScreenHeight, offsetY, runtime.menuGesture.pressedItem(),
                  runtime.menuGesture.downPressed());
  }
  if(!runtime.recorder.visible() || aiModalVisible())
    drawAi(frame, kScreenWidth, kScreenHeight, runtime.aiGesture.pressedTarget());
  Notifications::draw(frame,kScreenWidth,kScreenHeight,runtime.notification,runtime.notificationView);
  if (!notesVisible() && !runtime.recorder.visible() && !runtime.page.visible() && !runtime.powerPage.visible() && !aiModalVisible())
    drawStateInfo(frame, kScreenWidth, kScreenHeight);
#if defined(KIBI_UI_PROFILE)
  const uint32_t presentAt=micros();
  if(uiPerf.active) uiPerf.compose.add(uint32_t(presentAt-composeAt));
#endif
#if KIBI_UI_DIAGNOSTICS
  UiDiagnostics::frameComposed(uint32_t(micros()-diagnosticComposeAt));
#endif
  presentDisplayFrame();
#if defined(KIBI_UI_PROFILE)
  if(uiPerf.active) uiPerf.present.add(uint32_t(micros()-presentAt));
#endif
  runtime.notificationView.presented(millis());
  runtime.displayedOffset = offsetY;
  runtime.displayedNotesRevision = notesRevision();
  runtime.displayedNotesOffset = runtime.notesScroll.offsetY();
  runtime.displayedPageOffset = runtime.pageScroll.offsetY();
}
}  // namespace AppDetail

inline bool beginApp() {
  auto& state = AppDetail::runtime;
  if (state.ready) return true;
  PowerManagement::begin();
  AppDetail::loadPowerSettings();
  const bool mounted = LittleFS.begin(false);
  state.customDesign = false;
  if (mounted) {
    for (int attempt = 0; attempt < 2 && !state.customDesign; ++attempt) {
      auto& candidate = state.incoming;
      if (ServerSync::readStoredDesign(candidate, attempt == 1) &&
          AppDetail::loadDesignCharacter(candidate) && beginDisplay(AppDetail::backgroundPath(candidate))) {
        state.design = candidate;
        state.customDesign = true;
      }
    }
  }
  if (!state.customDesign) {
    if (!beginDisplay()) {
      unloadCharacter();
      return false;
    }
    AppDetail::restoreCharacter();
  }
  if (!beginNotes()) Serial.println("[NOTES] Storage unavailable; readable drafts remain available");
  setMenuAction("notes", openNotes);
  setMenuAction("shopping", openShoppingNotes);
  setMenuAction("recorder", AppDetail::openRecorder);
  setMenuAction("settings", AppDetail::openPowerSettings);
  beginStateInfo();
  beginInputBus();
  if(!ServerSync::beginReminderStorage()) Serial.println("[REMINDERS] Storage unavailable; existing voice notes remain available");
  AiDetail::runtime.recoverReminderRecording=ServerSync::recoverReminderRecording;
  AiDetail::runtime.reserveNoteId=[]() { return NotesDetail::runtime.store.reserveId(); };
  beginAi();
  AppDetail::inputLoopTask=xTaskGetCurrentTaskHandle();
  attachInterruptArg(digitalPinToInterrupt(Board::kPlus),AppDetail::wakeInputLoop,&AppDetail::plusWake,ONLOW);
  attachInterruptArg(digitalPinToInterrupt(Board::kMinus),AppDetail::wakeInputLoop,&AppDetail::minusWake,ONLOW);
  PowerManagement::armWakeSources();
  AiDetail::runtime.beforeRecording = ServerSync::beforeRecording;
  AiDetail::runtime.prepareRecording = ServerSync::prepareRecording;
  beginTouch();
  // Provisioned epoch is only a TLS bootstrap floor. The first authenticated
  // heartbeat supplies current time; NTP remains available in parallel.
  if (time(nullptr) < time_t(ServerConfig::kProvisionedEpoch)) {
    timeval initial{time_t(ServerConfig::kProvisionedEpoch), 0};
    settimeofday(&initial, nullptr);
  }
  ServerSync::markApplied(state.customDesign ? state.design.version : 0, nullptr);
  if (!ServerSync::beginSync(state.customDesign ? &state.design : nullptr))
    Serial.println("[SYNC] Server task unavailable");
  if(!DailyWeather::begin()) Serial.println("[WEATHER] Background forecast unavailable");
  state.scroll.setRange(sceneMaxOffset(kScreenHeight), true);
  updateCharacter(StateInfoDetail::runtime.info.chargingKnown && StateInfoDetail::runtime.info.charging,
                  millis());
  state.ready = true;
  lockTheme();
  AppDetail::drawFrame(0);
  Serial.printf("[APP] theme=%s; menu=%d; scroll=0..%d\n", theme().id, menuModuleCount(),
                sceneMaxOffset(kScreenHeight));
  return true;
}

inline void updateApp() {
  using namespace DisplayTouchDetail;
  auto& runtime = AppDetail::runtime;
  if (!runtime.ready) {
    delay(20);
    return;
  }
#if KIBI_UI_DIAGNOSTICS
  UiDiagnostics::beginInputBatch();
#endif
#if defined(KIBI_UI_PROFILE)
  AppDetail::UiPerfLoop profileLoop;
  AppDetail::tickUiPerf();
#endif
  TouchEvent event;
  bool menuChanged = false;
  AiDetail::runtime.clockTrusted.store(WifiDetail::timeSynchronized,std::memory_order_release);
  // Wake is asynchronous. The original button handler sees this same press;
  // no LCD sleep-out wait or second '+' press is inserted into capture.
  const uint32_t inputAt=millis();
  const bool plusDown=digitalRead(Board::kPlus)==LOW;
  const bool minusDown=digitalRead(Board::kMinus)==LOW;
  if(AppDetail::plusWake.latch.rearm(!plusDown)) gpio_intr_enable(gpio_num_t(Board::kPlus));
  if(AppDetail::minusWake.latch.rearm(!minusDown)) gpio_intr_enable(gpio_num_t(Board::kMinus));
  const bool inputEdge=AppDetail::inputWakePending.exchange(false,std::memory_order_relaxed);
  if(plusDown || minusDown || inputEdge) runtime.power.activity(inputAt);
  if(runtime.minusButton.update(minusDown,inputAt)==ButtonEdge::Pressed) runtime.power.activity(inputAt);
  updateAiButton();
  if(aiBusy()) runtime.powerPage.close();
  menuChanged|=AppDetail::updatePower(millis());
  menuChanged|=runtime.recorder.update(AppDetail::recorderSnapshot());
  const bool aiResultReady = aiState() == AiState::Done;
  const bool aiNoticeChanged = updateAiNotice(millis());
  if (aiResultReady) {
    bool consumed = true, safelySaved = false;
    const bool presentFinal=aiResultPresentationAllowed();
    const auto& reply = aiReply();
    if(reply.intent==Assistant::Intent::Reminder) {
      safelySaved=ServerSync::stageReminder(reply.reminder);
      if(safelySaved) {
        char clock[20]{},confirmation[320];Reminders::localClock(reply.reminder.dueAt,true,clock);
        snprintf(confirmation,sizeof confirmation,"Reminder saved on kibi for %s (UTC+7). Will sync when connected.",clock);
        if(presentFinal) showAssistantAnswer(reply.reminder.title,confirmation,"","Reminder");
      } else {
        AiDetail::fail("Could not save the reminder. Tap Retry.");consumed=false;
      }
    } else if(reply.intent==Assistant::Intent::Note || reply.intent==Assistant::Intent::Shopping) {
      const bool shopping=reply.intent==Assistant::Intent::Shopping;
      const auto stored=AppDetail::applyStoredVoiceResult(aiTranscript(),aiNoteId(),reply.title,
          reply.answer,shopping,presentFinal);
      safelySaved=stored!=AppDetail::StoredVoiceResult::SaveFailed;
      runtime.preserveReaderScroll=safelySaved && !presentFinal && notesDetailVisible();
      if(stored!=AppDetail::StoredVoiceResult::Saved) {
        AiDetail::fail(stored==AppDetail::StoredVoiceResult::SaveFailed?
            "Could not save on kibi. Your text is kept as a draft.":shopping?
            "Could not open the list. It is saved in Shopping.":
            "Could not open the confirmation. Your note is saved in Notes.");
        consumed=false;
      }
      Serial.printf("[NOTES] saved=%d count=%d\n",safelySaved,NotesDetail::runtime.store.count());
    } else {
      safelySaved = !presentFinal || showAssistantAnswer(*reply.title ? reply.title : aiTranscript(), reply.text, reply.source,
                                       *reply.heading ? reply.heading : "Answer");
      if (!safelySaved) {
        AiDetail::fail("The response is invalid. Ask again.");
        consumed = false;
      }
    }
    if(safelySaved && Inbox::lowerHex(reply.jobId,32) && !ServerSync::markResultApplied(reply.jobId)) {
      AiDetail::fail("Result saved, but its receipt could not be stored. Check storage.");
      consumed=false;
    }
    ackAiResultSaved(safelySaved);
    if(runtime.recorder.visible() && (safelySaved || (consumed && notesDetailVisible()))) {
      if(notesDetailVisible()) runtime.recorder.complete(true);
      else if(aiContinuousRecording()) runtime.recorder.complete(false);
    }
    if (consumed) dismissAi();
  }
  menuChanged|=AppDetail::updateDailyWeather();
  menuChanged|=AppDetail::updateCalories();
  auto syncViews = [&]() {
    const uint32_t revision=ServerSync::notificationRevision();
    if(runtime.configuredNotificationRevision!=revision && ServerSync::notificationSnapshot(runtime.notification,runtime.notificationPending)) {
      runtime.configuredNotificationRevision=revision;
      if(runtime.notificationPending) runtime.power.notify(millis());
    }
    const bool voiceCard=AiDetail::runtime.notice.stage()!=VoiceNotice::Stage::Hidden;
    menuChanged|=runtime.notificationView.bind(runtime.notification,
        runtime.notificationPending&&!aiBusy()&&!aiModalVisible()&&!voiceCard&&!runtime.recorder.visible(),runtime.pointerDown);
    if(runtime.wasRecorder!=runtime.recorder.visible()) {
      runtime.scroll.cancel(); runtime.notesScroll.cancel(); runtime.menuGesture.cancel();
      runtime.notesGesture.cancel(); runtime.aiGesture.cancel(); runtime.recorder.cancelTouch();
      runtime.pageScroll.cancel();runtime.pageGesture.cancel();
      if(runtime.pointerDown) runtime.drainTouch=true;
      runtime.wasRecorder=runtime.recorder.visible(); menuChanged=true;
    }
    if(runtime.wasPage!=runtime.page.visible()) {
      runtime.scroll.cancel();runtime.notesScroll.cancel();runtime.pageScroll.cancel();
      runtime.menuGesture.cancel();runtime.notesGesture.cancel();runtime.pageGesture.cancel();
      if(runtime.pointerDown) runtime.drainTouch=true;
      runtime.wasPage=runtime.page.visible();menuChanged=true;
    }
    if(runtime.configuredPageRevision!=runtime.page.revision()) {
      runtime.configuredPageRevision=runtime.page.revision();
      runtime.pageScroll.setRange(runtime.page.scrollLimit(kScreenWidth,kScreenHeight),true);
      runtime.pageGesture.cancel();menuChanged=true;
    }
    const bool notificationModal=runtime.notificationView.visible();
    if(notificationModal!=runtime.wasNotification) {
      runtime.scroll.cancel();runtime.notesScroll.cancel();runtime.menuGesture.cancel();runtime.notesGesture.cancel();runtime.aiGesture.cancel();
      runtime.pageScroll.cancel();runtime.pageGesture.cancel();
      runtime.powerPage.cancelTouch();
      if(runtime.pointerDown) runtime.drainTouch=true;
      runtime.wasNotification=notificationModal;
    }
    if (runtime.configuredNotesRevision != notesRevision()) {
      runtime.configuredNotesRevision = notesRevision();
      runtime.notesScroll.setRange(notesScrollLimit(kScreenHeight), !runtime.preserveReaderScroll);
      runtime.preserveReaderScroll = false;
      runtime.notesGesture.cancel();
      runtime.scroll.cancel();
      runtime.pageScroll.cancel();runtime.pageGesture.cancel();
      runtime.powerPage.cancelTouch();
    }
    const bool modal = aiModalVisible();
    if (modal && !runtime.wasAiModal) {
      runtime.scroll.cancel();
      runtime.notesScroll.cancel();
      runtime.menuGesture.cancel();
      runtime.notesGesture.cancel();
      runtime.aiGesture.cancel();
      runtime.recorder.cancelTouch();
      runtime.pageScroll.cancel();runtime.pageGesture.cancel();
    }
    runtime.wasAiModal = modal;
  };
  syncViews();
  while (nextTouchEvent(event)) {
#if KIBI_UI_DIAGNOSTICS
    UiDiagnostics::inputDequeued(event.sampleUs,micros(),event.kind==TouchKind::Cancel);
#endif
#if defined(KIBI_UI_PROFILE)
    AppDetail::finishUiPerf("touch");
#endif
    syncViews();
    if(event.kind!=TouchKind::Cancel) runtime.power.activity(millis());
    if(event.kind==TouchKind::Down) runtime.pointerDown=true;
    else if(event.kind==TouchKind::Up || event.kind==TouchKind::Cancel) runtime.pointerDown=false;
    if(runtime.drainTouch) {
      if(!runtime.pointerDown) runtime.drainTouch=false;
      continue;
    }
    if (aiModalVisible()) {
      const int before = runtime.aiGesture.pressedTarget();
      const int target = aiHit(event.point.x, event.point.y);
      switch (event.kind) {
        case TouchKind::Down:
          runtime.aiGesture.begin(event.point.x, event.point.y, target);
          break;
        case TouchKind::Move:
          runtime.aiGesture.move(event.point.x, event.point.y);
          break;
        case TouchKind::Up: {
          const int action = runtime.aiGesture.release(event.point.x, event.point.y, target);
          if (action == 0)
            dismissAi();
          else if (action == 1)
            retryAi();
          break;
        }
        case TouchKind::Cancel:
          runtime.aiGesture.cancel();
          break;
      }
      menuChanged |= before != runtime.aiGesture.pressedTarget();
      continue;
    }
    if(runtime.notificationView.visible()) {
      Notifications::Input kind=Notifications::Input::Cancel;
      switch(event.kind) {
        case TouchKind::Down:kind=Notifications::Input::Down;break;
        case TouchKind::Move:kind=Notifications::Input::Move;break;
        case TouchKind::Up:kind=Notifications::Input::Up;break;
        case TouchKind::Cancel:break;
      }
      if(runtime.notificationView.input(kind,event.point.x,event.point.y,event.at))
        ServerSync::dismissNotification(runtime.notification.id);
      menuChanged=true;continue;
    }
    if(runtime.recorder.visible()) {
      RecorderUi::Input kind=RecorderUi::Input::Cancel;
      switch(event.kind) {
        case TouchKind::Down: kind=RecorderUi::Input::Down; break;
        case TouchKind::Move: kind=RecorderUi::Input::Move; break;
        case TouchKind::Up: kind=RecorderUi::Input::Up; break;
        case TouchKind::Cancel: break;
      }
      const int before=runtime.recorder.pressedTarget();
      const auto action=runtime.recorder.input(kind,event.point.x,event.point.y,kScreenWidth,kScreenHeight);
      if(action==RecorderUi::Action::Start) runtime.recorder.started(startLongRecording());
      else if(action==RecorderUi::Action::Stop) stopAiRecording();
      menuChanged|=action!=RecorderUi::Action::None || before!=runtime.recorder.pressedTarget();
      continue;
    }
    if(runtime.powerPage.visible()) {
      PowerUi::Input kind=PowerUi::Input::Cancel;
      switch(event.kind) {
        case TouchKind::Down:kind=PowerUi::Input::Down;break;
        case TouchKind::Move:kind=PowerUi::Input::Move;break;
        case TouchKind::Up:kind=PowerUi::Input::Up;break;
        case TouchKind::Cancel:break;
      }
      if(runtime.powerPage.input(kind,event.point.x,event.point.y,kScreenWidth,kScreenHeight)) {
        runtime.powerSettings=runtime.powerPage.settings();
        AppDetail::savePowerSettings();
      }
      menuChanged=true;continue;
    }
    if (notesVisible()) {
      const int before = runtime.notesGesture.pressedTarget();
      const int target = notesHit(event.point.x, event.point.y, runtime.notesScroll.offsetY(), kScreenHeight);
      switch (event.kind) {
        case TouchKind::Down:
          runtime.notesScroll.begin(event.point.y, event.at);
          runtime.notesGesture.begin(event.point.x, event.point.y, target);
          break;
        case TouchKind::Move:
          runtime.notesScroll.move(event.point.y, event.at);
          runtime.notesGesture.move(event.point.x, event.point.y);
          break;
        case TouchKind::Up:
          runtime.notesScroll.release(event.at);
          activateNoteTarget(runtime.notesGesture.release(event.point.x, event.point.y, target));
          break;
        case TouchKind::Cancel:
          runtime.notesScroll.cancel();
          runtime.notesGesture.cancel();
          break;
      }
      menuChanged |= before != runtime.notesGesture.pressedTarget();
      continue;
    }
    if(runtime.page.visible()) {
      const int before=runtime.pageGesture.pressedTarget();
      const int target=PageUi::backHit(event.point.x,event.point.y,kScreenWidth,kScreenHeight)?0:-1;
      switch(event.kind) {
        case TouchKind::Down:
          runtime.pageScroll.begin(event.point.y,event.at);
          runtime.pageGesture.begin(event.point.x,event.point.y,target);break;
        case TouchKind::Move:
          runtime.pageScroll.move(event.point.y,event.at);
          runtime.pageGesture.move(event.point.x,event.point.y);break;
        case TouchKind::Up:
          runtime.pageScroll.release(event.at);
          if(runtime.pageGesture.release(event.point.x,event.point.y,target)==0) runtime.page.close();
          break;
        case TouchKind::Cancel:
          runtime.pageScroll.cancel();runtime.pageGesture.cancel();break;
      }
      menuChanged|=before!=runtime.pageGesture.pressedTarget();
      continue;
    }
    const int pressed = runtime.menuGesture.pressedItem();
    const bool downPressed = runtime.menuGesture.downPressed();
    switch (event.kind) {
      case TouchKind::Down:
        runtime.scroll.begin(event.point.y, event.at);
        runtime.menuGesture.begin(event.point.x, event.point.y, runtime.scroll.offsetY());
        break;
      case TouchKind::Move:
        runtime.scroll.move(event.point.y, event.at);
        runtime.menuGesture.move(event.point.x, event.point.y);
        break;
      case TouchKind::Up: {
        runtime.scroll.release(event.at);
        const int item = runtime.menuGesture.release(event.point.x, event.point.y, runtime.scroll.offsetY());
        if (item == -2)
          runtime.scroll.scrollTo(menuScrollTarget(), event.at);
        else if (item >= 0 && !activateMenuItem(item))
          AppDetail::openMenuPage(item);
        break;
      }
      case TouchKind::Cancel:
        runtime.scroll.cancel();
        runtime.menuGesture.cancel();
        break;
    }
    menuChanged |=
        pressed != runtime.menuGesture.pressedItem() || downPressed != runtime.menuGesture.downPressed();
  }
#if defined(KIBI_UI_PROFILE)
  const uint32_t syncAt=micros();
#endif
  AppDetail::updateServerSync();
#if defined(KIBI_UI_PROFILE)
  if(AppDetail::uiPerf.active) AppDetail::uiPerf.sync.add(uint32_t(micros()-syncAt));
#endif
  menuChanged|=AppDetail::applyInbox();
  syncViews();
  menuChanged|=runtime.notificationView.tick(millis());
  if (!aiModalVisible() && !runtime.notificationView.visible() && !runtime.recorder.visible()) {
    if (notesVisible())
      runtime.notesScroll.tick(millis());
    else if(runtime.page.visible()) {
      const int before=runtime.pageScroll.offsetY();
      runtime.pageScroll.tick(millis());
      menuChanged|=before!=runtime.pageScroll.offsetY();
    }
    else
      runtime.scroll.tick(millis());
  }
  const int offsetY = runtime.scroll.offsetY();
#if defined(KIBI_UI_PROFILE)
  const uint32_t stateAt=micros();
#endif
  const bool stateChanged = updateStateInfo(aiBusy(),!runtime.powerView.screenOn);
  menuChanged|=AppDetail::updatePower(millis());
#if defined(KIBI_UI_PROFILE)
  const uint32_t characterAt=micros();
  if(AppDetail::uiPerf.active) AppDetail::uiPerf.state.add(uint32_t(characterAt-stateAt));
#endif
  const bool characterChanged = displayReadyToPresent() && updateCharacter(
      StateInfoDetail::runtime.info.chargingKnown && StateInfoDetail::runtime.info.charging, millis(),
      characterRenderAllowed(!notesVisible() && !runtime.recorder.visible() && !runtime.page.visible() && !runtime.powerPage.visible(),
          runtime.pointerDown || runtime.drainTouch,runtime.scroll.active(),
          int64_t(theme().characterY)+256-characterMetadata().height+
              (runtime.customDesign?runtime.design.characterYOffset:0)-offsetY,
          characterMetadata().height,kScreenHeight),
      StateInfoDetail::runtime.info.hour, StateInfoDetail::runtime.info.minute,
      aiRecording(), aiBusy());
#if defined(KIBI_UI_PROFILE)
  if(AppDetail::uiPerf.active) AppDetail::uiPerf.character.add(uint32_t(micros()-characterAt));
#endif
  const bool notesChanged = runtime.displayedNotesRevision != notesRevision() ||
                            runtime.displayedNotesOffset != runtime.notesScroll.offsetY();
  const bool pageChanged=runtime.page.visible() && runtime.displayedPageOffset!=runtime.pageScroll.offsetY();
  const bool aiChanged = aiNeedsRedraw() || aiNoticeChanged;
  if (offsetY != runtime.displayedOffset || stateChanged || (!notesVisible() && !runtime.page.visible() && characterChanged) ||
      menuChanged || notesChanged || pageChanged || aiChanged)
    AppDetail::drawFrame(offsetY);
  if (!runtime.memoryReported && millis() >= 5000) {
    runtime.memoryReported = true;
    AppDetail::printMemoryInfo();
  }
  while (Serial.available()) {
    const int command=Serial.read();
    if(command=='e') PowerManagement::printDiagnostics();
    if(command=='e') Serial.printf("[POWER-DIAG] rational=%u stage=%u brightness=%u awake=%u ready=%u charging=%u usb_host=%u override=%u\n",
        unsigned(runtime.powerSettings.rational),unsigned(runtime.powerView.stage),unsigned(runtime.powerView.brightness),
        unsigned(displayIsAwake()),unsigned(displayReadyToPresent()),unsigned(StateInfoDetail::runtime.info.charging),
        unsigned(PowerRuntime::confirmedExternalPower(false)),unsigned(runtime.powerSettings.alwaysScreen));
    if (command == 'm') AppDetail::printMemoryInfo();
    if(command=='c' && !aiBusy() && !notesVisible() && !runtime.recorder.visible() && !runtime.notificationView.visible()) {
      const uint32_t openedAt=millis();
      dismissAi();
      for(int i=0;i<menuModuleCount();++i) if(!strcmp(menuModule(i)->id,"calories")) AppDetail::openMenuPage(i);
      uint32_t age=0;const bool ready=ServerSync::caloriesCacheReady(age);char line[128];
      snprintf(line,sizeof line,"[DIAG] Calories cache_ready=%u cache_age_ms=%lu open_ms=%lu\n",
          unsigned(ready),(unsigned long)age,(unsigned long)(millis()-openedAt));Serial.print(line);
    }
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
    if(command=='v' && !aiBusy()) {
      const bool started=RealtimeVoice::start(UINT32_MAX-1,true);
      Serial.println(started?"[DIAG] Voice probe started; no PCM/commit":"[DIAG] Voice probe unavailable");
    }
#endif
#if defined(KIBI_UI_PROFILE)
    if(command=='p' && !AppDetail::uiPerf.active && AppDetail::uiPerfHomeReady()) {
      AppDetail::uiPerf={};
      AppDetail::uiPerf.active=true;
      AppDetail::uiPerf.startedAt=millis();
      AppDetail::uiPerf.originalOffset=runtime.scroll.offsetY();
    }
#endif
  }
  if(runtime.powerView.screenOn) delay(1);
  else {
    // Buttons interrupt immediately. Otherwise allow long automatic light-sleep
    // intervals; the charge pin also wakes hardware when a charger is inserted.
    // ADC bursts retain their original 2 ms spacing.
    const uint32_t pause=PowerManagement::idlePauseMs(false,StateInfoDetail::runtime.sampling);
    ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(pause));
  }
}

}  // namespace Tamagotchi
#endif
