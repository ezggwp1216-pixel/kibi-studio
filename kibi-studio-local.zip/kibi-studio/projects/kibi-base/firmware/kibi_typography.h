#pragma once

// Optional native typography for user projects. No Arduino, GPIO, LCD driver,
// heap, rasterizer or palette dependency. Include explicitly to use it.
#include "kibi_typography_data.h"
#include <climits>
#include <string_view>

namespace KibiTypography {
using Glyph=Data::Glyph;
enum class Font { Body18, Medium20, Header20, Number32, Number40, Number48 };
struct Face {
  const Glyph* glyphs; size_t glyphCount;
  const uint8_t* bitmap; size_t bitmapBytes;
  int sizePx,weight,ascent,descent,lineHeight;
};
template<size_t N,size_t B>
constexpr Face makeFace(const Glyph (&glyphs)[N],const uint8_t (&bitmap)[B],
                        int size,int weight,int ascent,int descent,int lineHeight) {
  return {glyphs,N,bitmap,B,size,weight,ascent,descent,lineHeight};
}
#define KIBI_NATIVE_FACE(name) makeFace(Data::name::kGlyphs,Data::name::kBitmap,Data::name::kSizePx,Data::name::kWeight,Data::name::kAscent,Data::name::kDescent,Data::name::kLineHeight)
inline constexpr Face kFaces[]={KIBI_NATIVE_FACE(Body18),KIBI_NATIVE_FACE(Medium20),
  KIBI_NATIVE_FACE(Header20),KIBI_NATIVE_FACE(Number32),KIBI_NATIVE_FACE(Number40),KIBI_NATIVE_FACE(Number48)};
#undef KIBI_NATIVE_FACE
inline const Face& getFace(Font font) {
  const unsigned i=static_cast<unsigned>(font);
  return kFaces[i<6?i:0];
}
inline const Glyph* findGlyph(const Face& face,uint32_t code) {
  size_t lo=0,hi=face.glyphCount;
  while(lo<hi) {const size_t m=lo+(hi-lo)/2; if(face.glyphs[m].code<code)lo=m+1;else hi=m;}
  return lo<face.glyphCount && face.glyphs[lo].code==code ? face.glyphs+lo : nullptr;
}
inline unsigned coverage(const Face& face,const Glyph& glyph,int x,int y) {
  if(x<0 || y<0 || x>=glyph.width || y>=glyph.height) return 0;
  const size_t pixel=size_t(y)*glyph.width+size_t(x);
  const uint64_t offset=uint64_t(glyph.bitmapOffset)+pixel/2;
  if(offset>=face.bitmapBytes) return 0;
  const unsigned packed=face.bitmap[size_t(offset)];
  return (pixel&1)?packed&15u:packed>>4;
}
inline uint16_t blend565(uint16_t background,uint16_t foreground,unsigned alpha4) {
  const unsigned a=alpha4>15?15:alpha4,b=15-a;
  const unsigned r=(((background>>11)&31)*b+((foreground>>11)&31)*a+7)/15;
  const unsigned g=(((background>>5)&63)*b+((foreground>>5)&63)*a+7)/15;
  const unsigned blue=((background&31)*b+(foreground&31)*a+7)/15;
  return uint16_t((r<<11)|(g<<5)|blue);
}

namespace Detail {
inline uint32_t next(std::string_view text,size_t& at) {
  const auto first=static_cast<unsigned char>(text[at++]);
  if(first<128) return first;
  const unsigned count=first>=0xc2 && first<=0xdf?1:first>=0xe0 && first<=0xef?2:first>=0xf0 && first<=0xf4?3:0;
  if(!count || text.size()-at<count) return 0xfffd;
  uint32_t value=first&((1u<<(6-count))-1u);
  for(unsigned i=0;i<count;++i) {
    const auto byte=static_cast<unsigned char>(text[at+i]);
    if((byte&0xc0)!=0x80) return 0xfffd;
    value=(value<<6)|(byte&63);
  }
  if(value<(count==1?0x80u:count==2?0x800u:0x10000u) ||
     (value>=0xd800 && value<=0xdfff) || value>0x10ffff) return 0xfffd;
  at+=count;
  return value;
}
inline int integer(int64_t value) {return value<INT_MIN?INT_MIN:value>INT_MAX?INT_MAX:int(value);}
inline int64_t minimum(int64_t a,int64_t b) {return a<b?a:b;}
inline int64_t maximum(int64_t a,int64_t b) {return a>b?a:b;}
inline int64_t advance(int64_t pen,int amount) {
  constexpr int64_t limit=int64_t(INT_MAX)*64;
  return minimum(limit,pen+amount);
}
} // namespace Detail

struct Rect { int x,y,width,height; };
struct Metrics { int64_t advance64=0; Rect ink{0,0,0,0}; int width=0; };
// Single line: LF ends a line, CR is ignored. Malformed/unsupported codepoints
// become '?'. std::string_view prevents reads beyond an explicit byte length.
inline Metrics measure(const Face& face,std::string_view text) {
  Metrics m; int64_t left=0,top=0,right=0,bottom=0; bool ink=false;
  for(size_t at=0;at<text.size();) {
    const uint32_t code=Detail::next(text,at);
    if(code=='\n')break; if(code=='\r')continue;
    const Glyph* glyph=findGlyph(face,code); if(!glyph)glyph=findGlyph(face,'?');
    if(!glyph)continue;
    if(glyph->width && glyph->height) {
      const int64_t x=(m.advance64+32)/64+glyph->left,y=int64_t(face.ascent)+glyph->top;
      if(!ink) {left=x;top=y;right=x+glyph->width;bottom=y+glyph->height;ink=true;}
      else {left=Detail::minimum(left,x);top=Detail::minimum(top,y);
        right=Detail::maximum(right,x+glyph->width);bottom=Detail::maximum(bottom,y+glyph->height);}
    }
    m.advance64=Detail::advance(m.advance64,glyph->advance64);
  }
  m.ink={Detail::integer(left),Detail::integer(top),Detail::integer(right-left),Detail::integer(bottom-top)};
  m.width=Detail::integer(Detail::maximum((m.advance64+63)/64,right)-Detail::minimum(0,left));
  return m;
}
inline int width(const Face& face,std::string_view text) {return measure(face,text).width;}
inline bool supports(const Face& face,std::string_view text) {
  for(size_t at=0;at<text.size();) {
    const auto code=Detail::next(text,at);
    if(!findGlyph(face,code))return false;
  }
  return true;
}
// Returns null when even 32px does not fit, the text is empty, or it contains
// non-numeric glyphs. maxHeight is the complete face line box, in native pixels.
inline const Face* largestNumberThatFits(std::string_view text,int maxWidth,int maxHeight=INT_MAX) {
  if(text.empty() || maxWidth<=0 || maxHeight<=0)return nullptr;
  for(int i=5;i>=3;--i) {
    const auto& face=kFaces[i];
    if(face.lineHeight<=maxHeight && supports(face,text) && width(face,text)<=maxWidth)return &face;
  }
  return nullptr;
}

struct Framebuffer {uint16_t* pixels; size_t pixelCount; int width,height,stride;};
// x/y locate the top of the font line box, NOT the baseline. RGB565 is native
// uint16_t (not SPI byte-swapped). Blend against each existing pixel so arbitrary
// user palettes/backgrounds work. No geometry or LCD access lives in this API.
inline void draw(Framebuffer frame,const Face& face,std::string_view text,int x,int y,
                 uint16_t color,Rect clip={0,0,INT_MAX,INT_MAX}) {
  if(!frame.pixels || frame.width<=0 || frame.height<=0 || frame.stride<frame.width ||
     clip.width<=0 || clip.height<=0)return;
  const uint64_t required=uint64_t(frame.height-1)*unsigned(frame.stride)+unsigned(frame.width);
  if(required>frame.pixelCount)return;
  const int64_t clipLeft=Detail::maximum(0,clip.x),clipTop=Detail::maximum(0,clip.y);
  const int64_t clipRight=Detail::minimum(frame.width,int64_t(clip.x)+clip.width);
  const int64_t clipBottom=Detail::minimum(frame.height,int64_t(clip.y)+clip.height);
  if(clipLeft>=clipRight || clipTop>=clipBottom)return;
  int64_t pen=0;
  for(size_t at=0;at<text.size();) {
    const uint32_t code=Detail::next(text,at);
    if(code=='\n')break; if(code=='\r')continue;
    const Glyph* glyph=findGlyph(face,code);if(!glyph)glyph=findGlyph(face,'?');
    if(!glyph)continue;
    const int64_t gx=int64_t(x)+(pen+32)/64+glyph->left;
    const int64_t gy=int64_t(y)+face.ascent+glyph->top;
    const int64_t left=Detail::maximum(gx,clipLeft),top=Detail::maximum(gy,clipTop);
    const int64_t right=Detail::minimum(gx+glyph->width,clipRight),bottom=Detail::minimum(gy+glyph->height,clipBottom);
    for(int64_t py=top;py<bottom;++py) for(int64_t px=left;px<right;++px) {
      const unsigned alpha=coverage(face,*glyph,int(px-gx),int(py-gy));
      if(alpha) {auto& pixel=frame.pixels[size_t(py)*size_t(frame.stride)+size_t(px)];pixel=blend565(pixel,color,alpha);}
    }
    pen=Detail::advance(pen,glyph->advance64);
  }
}
} // namespace KibiTypography
