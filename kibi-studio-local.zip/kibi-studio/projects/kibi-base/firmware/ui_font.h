#pragma once

#include "ui_font_data.h"
#include <array>

namespace Tamagotchi::UiFont {

// Generated masks and metrics are constexpr flash data. Rendering allocates
// neither a font cache nor a TTF rasterizer in internal RAM or PSRAM.
using Glyph = UiFontData::Glyph;
inline constexpr int kSizePx=UiFontData::kSizePx;
inline constexpr int kWeight=UiFontData::kWeight;

constexpr size_t firstGlyph(uint32_t code) {
  for(size_t index=0;index<UiFontData::kGlyphCount;++index)
    if(UiFontData::kGlyphs[index].code==code) return index;
  return UiFontData::kGlyphCount;
}
inline constexpr size_t kCyrillicFirst=firstGlyph(0x410),kVietnameseFirst=firstGlyph(0x1EA0);
static_assert(UiFontData::kGlyphs[0].code==32 && UiFontData::kGlyphs[94].code==126 &&
    kCyrillicFirst+63<UiFontData::kGlyphCount && UiFontData::kGlyphs[kCyrillicFirst+63].code==0x44F &&
    kVietnameseFirst+89<UiFontData::kGlyphCount && UiFontData::kGlyphs[kVietnameseFirst+89].code==0x1EF9,
    "Direct glyph ranges must stay contiguous");

inline const Glyph* findGlyph(uint32_t code) {
  // Most UI/transcript text belongs to these contiguous ranges. A direct
  // flash lookup avoids a binary search for every letter on every frame.
  if(code>=32 && code<=126) return &UiFontData::kGlyphs[code-32];
  if(code>=0x410 && code<=0x44F) return &UiFontData::kGlyphs[kCyrillicFirst+code-0x410];
  if(code>=0x1EA0 && code<=0x1EF9) return &UiFontData::kGlyphs[kVietnameseFirst+code-0x1EA0];
  size_t low=0,high=UiFontData::kGlyphCount;
  while(low<high) {
    const size_t middle=low+(high-low)/2;
    if(UiFontData::kGlyphs[middle].code<code) low=middle+1;
    else high=middle;
  }
  return low<UiFontData::kGlyphCount && UiFontData::kGlyphs[low].code==code
      ? &UiFontData::kGlyphs[low] : nullptr;
}

inline const Glyph* glyph(uint32_t code) {
  const auto* result=findGlyph(code);
  return result ? result : findGlyph('?');
}

inline unsigned coverage(const Glyph& glyph,int x,int y) {
  if(x<0 || y<0 || x>=glyph.width || y>=glyph.height || glyph.bitmapOffset>=UiFontData::kBitmapBytes) return 0;
  const size_t pixel=size_t(y)*glyph.width+size_t(x);
  const size_t offset=glyph.bitmapOffset+pixel/2;
  if(offset>=UiFontData::kBitmapBytes) return 0;
  const unsigned packed=UiFontData::kBitmap[offset];
  return ((pixel&1) ? packed&15u : packed>>4)*17u;
}

static_assert(UiFontData::kKerningCount<=65535,"Flash kerning index uses 16-bit offsets");
constexpr auto kerningRanges() {
  std::array<uint16_t,UiFontData::kGlyphCount+1> ranges{};
  size_t pair=0;
  for(size_t glyph=0;glyph<UiFontData::kGlyphCount;++glyph) {
    const uint32_t start=uint32_t(UiFontData::kGlyphs[glyph].code)<<16;
    while(pair<UiFontData::kKerningCount && UiFontData::kKerning[pair].pair<start) ++pair;
    ranges[glyph]=uint16_t(pair);
  }
  ranges[UiFontData::kGlyphCount]=uint16_t(UiFontData::kKerningCount);
  return ranges;
}
inline constexpr auto kKerningRanges=kerningRanges();

inline int kerning64(uint32_t left,uint32_t right) {
  if(left>0xFFFF || right>0xFFFF || !left || !right) return 0;
  const auto* first=findGlyph(left);
  if(!first) return 0;
  const size_t index=size_t(first-UiFontData::kGlyphs);
  const uint32_t pair=(left<<16)|right;
  size_t low=kKerningRanges[index],high=kKerningRanges[index+1];
  while(low<high) {
    const size_t middle=low+(high-low)/2;
    if(UiFontData::kKerning[middle].pair<pair) low=middle+1;
    else high=middle;
  }
  return low<UiFontData::kKerningCount && UiFontData::kKerning[low].pair==pair
      ? UiFontData::kKerning[low].amount64 : 0;
}

inline int ascent(bool vietnamese) {
  return vietnamese ? UiFontData::kBaseline : UiFontData::kCommonAscent;
}
inline int height(bool vietnamese) {
  return vietnamese ? UiFontData::kHeight : UiFontData::kCommonHeight;
}

} // namespace Tamagotchi::UiFont
