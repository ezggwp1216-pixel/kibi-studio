#pragma once
#include "fullscreen_page.h"
#include <stdio.h>

namespace Tamagotchi::RecorderUi {
enum class Stage { Ready,Starting,Recording,Processing,Saved };
enum class Action { None,Start,Stop,Back };
enum class Input { Down,Move,Up,Cancel };
struct Snapshot {
  bool busy=false,continuous=false,capturing=false,starting=false;
  uint32_t elapsedMs=0;
};

// The controller owns only the screen and touch gesture. Capture/network state
// comes from the shared AI pipeline; this view never touches a file or socket.
class View {
 public:
  void open() {
    visible_=true; closing_=stopping_=busy_=continuous_=capturing_=false;
    seconds_=0; stage_=Stage::Ready; gesture_.cancel();
  }
  bool visible() const { return visible_; }
  bool closing() const { return closing_; }
  bool stopping() const { return stopping_; }
  Stage stage() const { return stage_; }
  void cancelTouch() { gesture_.cancel(); }
  int pressedTarget() const { return gesture_.pressedTarget(); }
  Action primaryAction() const {
    if(!visible_ || closing_ || stopping_) return Action::None;
    if(stage_==Stage::Ready || stage_==Stage::Saved) return Action::Start;
    return capturing_ && continuous_?Action::Stop:Action::None;
  }
  void timer(char (&out)[6]) const {
    snprintf(out,sizeof out,"%02u:%02u",unsigned(seconds_/60),unsigned(seconds_%60));
  }
  void started(bool success) {
    if(!success) return;
    stage_=Stage::Starting; busy_=continuous_=capturing_=true;
    closing_=stopping_=false; seconds_=0; gesture_.cancel();
  }
  void complete(bool showReader) {
    stage_=Stage::Saved; busy_=capturing_=closing_=stopping_=false;
    if(showReader) visible_=false;
    gesture_.cancel();
  }
  bool update(const Snapshot& state) {
    const auto beforeStage=stage_; const auto beforeAction=primaryAction();
    const auto beforeSeconds=seconds_; const bool beforeVisible=visible_,beforeStopping=stopping_;
    busy_=state.busy; continuous_=state.continuous; capturing_=state.capturing;
    if(!visible_) return false;
    // Stop has only requested capture termination. The worker must close its
    // recorder before Back can release the screen to another touch owner.
    if(closing_ && !capturing_) { visible_=false; gesture_.cancel(); return true; }
    if(busy_) {
      stage_=continuous_ && capturing_?(state.starting?Stage::Starting:Stage::Recording):Stage::Processing;
      if(continuous_) seconds_=state.elapsedMs/1000>kAudioMaxSeconds?kAudioMaxSeconds:state.elapsedMs/1000;
    } else if(stage_!=Stage::Saved) stage_=Stage::Ready;
    if(!capturing_) stopping_=false;
    if(beforeAction!=primaryAction()) gesture_.cancel();
    return beforeStage!=stage_ || beforeSeconds!=seconds_ || beforeVisible!=visible_ || beforeStopping!=stopping_;
  }
  int hit(int x,int y,int width,int height) const {
    if(!visible_ || width<200 || height<280) return -1;
    const auto action=primaryAction();
    if(action!=Action::None && Ui::roundedPixel(x-(width-176)/2,y-190,176,42,12))
      return action==Action::Start?1:3;
    if(!closing_ && PageUi::backHit(x,y,width,height)) return 2;
    return -1;
  }
  Action input(Input kind,int x,int y,int width,int height) {
    if(!visible_) return Action::None;
    const int target=hit(x,y,width,height);
    switch(kind) {
      case Input::Down: gesture_.begin(x,y,target); return Action::None;
      case Input::Move: gesture_.move(x,y); return Action::None;
      case Input::Cancel: gesture_.cancel(); return Action::None;
      case Input::Up: break;
    }
    const int action=gesture_.release(x,y,target);
    if(action==1) return Action::Start;
    if(action==3) { stopping_=true; return Action::Stop; }
    if(action!=2) return Action::None;
    if(capturing_ && continuous_) {
      closing_=true;
      if(stopping_) return Action::None;
      stopping_=true; return Action::Stop;
    }
    visible_=false; return Action::Back;
  }
 private:
  TapGesture gesture_;
  Stage stage_=Stage::Ready;
  uint32_t seconds_=0;
  bool visible_=false,closing_=false,stopping_=false,busy_=false,continuous_=false,capturing_=false;
};

inline void centered(uint16_t* frame,int width,int height,const char* text,int y,int scale=2,uint16_t color=theme().text) {
  Ui::text(frame,width,height,text,Ui::textCenteredX(text,width,scale),y,scale,color,0,height);
}
inline void draw(uint16_t* frame,int width,int height,const View& view) {
  if(!frame || !view.visible() || width<200 || height<280) return;
  PageUi::drawShell(frame,width,height,"Recorder",view.pressedTarget()==2);
  const auto page=PageUi::layout(width,height,"Recorder");
  constexpr const char* description="Voice note";
  centered(frame,width,height,description,Ui::centeredTextTop(description,page.bodyTop,88-page.bodyTop));
  char clock[6]; view.timer(clock);
  centered(frame,width,height,clock,Ui::centeredTextTop(clock,94,38,4),4);
  const uint16_t secondary=Ui::blend(theme().card,theme().text,176);
  char limit[16]; snprintf(limit,sizeof limit,"of %02u:%02u",unsigned(kAudioMaxSeconds/60),unsigned(kAudioMaxSeconds%60));
  centered(frame,width,height,limit,Ui::centeredTextTop(limit,136,22),2,secondary);
  const bool processing=view.stage()==Stage::Processing;
  const char* status=view.closing() || view.stopping()?"Stopping":
      view.stage()==Stage::Starting?"Preparing":view.stage()==Stage::Recording?"Recording":
      processing?"You can leave":view.stage()==Stage::Saved?"Saved":"Up to 5 min";
  centered(frame,width,height,status,Ui::centeredTextTop(status,162,24),2,secondary);
  const auto action=view.primaryAction();
  const bool pressed=view.pressedTarget()==1 || view.pressedTarget()==3;
  Ui::box(frame,width,height,(width-176)/2,190,176,42,12,pressed,44);
  const char* label=action==Action::Stop?"Stop":action==Action::Start?
      (view.stage()==Stage::Saved?"Record again":"Start"):processing?"Processing":"Please wait";
  centered(frame,width,height,label,Ui::centeredTextTop(label,190,42),2,
      action==Action::None?theme().muted:theme().text);
}
} // namespace Tamagotchi::RecorderUi
