#pragma once
#include <atomic>
#include <cstdint>
#ifdef ARDUINO
#include <Arduino.h>
#include <esp_heap_caps.h>
#endif

namespace Tamagotchi::TlsDiagnostics {
struct Heap { uint32_t internalFree,internalLargest; };
struct Snapshot {
  uint32_t liveContexts,peakContexts,connectAttempts,connectFailures,maxConnectMs;
  uint32_t minInternalFree,minInternalLargest,heapSamples;
};
class Tracker {
 public:
  // Independent atomic loads: a concurrent update can span two snapshots.
  // Reading diagnostics never takes the network gate, spins, or allocates.
  Snapshot snapshot() const {
    const uint32_t samples=heapSamples_.load(std::memory_order_acquire);
    return {liveContexts_.load(std::memory_order_relaxed),peakContexts_.load(std::memory_order_relaxed),
            connectAttempts_.load(std::memory_order_relaxed),connectFailures_.load(std::memory_order_relaxed),
            maxConnectMs_.load(std::memory_order_relaxed),
            samples?minInternalFree_.load(std::memory_order_relaxed):0,
            samples?minInternalLargest_.load(std::memory_order_relaxed):0,samples};
  }
 private:
  friend class Context;
  // ESP-IDF can disable hardware atomic RMW instructions. Updates may use
  // its atomic helpers; snapshots only load aligned 32-bit scalar fields.
  std::atomic<uint32_t> liveContexts_{0},peakContexts_{0},connectAttempts_{0},connectFailures_{0},maxConnectMs_{0};
  std::atomic<uint32_t> minInternalFree_{UINT32_MAX},minInternalLargest_{UINT32_MAX},heapSamples_{0};
  static void increment(std::atomic<uint32_t>& value) {
    uint32_t previous=value.load(std::memory_order_relaxed);
    while(previous!=UINT32_MAX && !value.compare_exchange_weak(previous,previous+1,std::memory_order_relaxed)) {}
  }
  static void maximum(std::atomic<uint32_t>& value,uint32_t sample) {
    uint32_t previous=value.load(std::memory_order_relaxed);
    while(sample>previous && !value.compare_exchange_weak(previous,sample,std::memory_order_relaxed)) {}
  }
  static void minimum(std::atomic<uint32_t>& value,uint32_t sample) {
    uint32_t previous=value.load(std::memory_order_relaxed);
    while(sample<previous && !value.compare_exchange_weak(previous,sample,std::memory_order_relaxed)) {}
  }
  void open() {
    maximum(peakContexts_,liveContexts_.fetch_add(1,std::memory_order_relaxed)+1);
  }
  void close() { liveContexts_.fetch_sub(1,std::memory_order_relaxed); }
  void beginConnect() { increment(connectAttempts_); }
  void endConnect(bool success,uint32_t elapsed) {
    maximum(maxConnectMs_,elapsed);
    if(!success) increment(connectFailures_);
  }
  void sample(Heap heap) {
    minimum(minInternalFree_,heap.internalFree); minimum(minInternalLargest_,heap.internalLargest);
    // Publish initialized minima before snapshots expose a nonzero sample count.
    uint32_t previous=heapSamples_.load(std::memory_order_relaxed);
    while(previous!=UINT32_MAX && !heapSamples_.compare_exchange_weak(previous,previous+1,std::memory_order_release)) {}
  }
};
// One object per transport, independent of recursive network gate ownership.
// A live context means an instrumented connect is in progress or its resulting
// transport has not been stopped. It includes handshake time; empty wrappers do
// not count. Heap minima are boundary samples, never an instantaneous TLS peak.
// Like the socket itself, a Context is used by one task at a time.
class Context {
 public:
  using Clock=uint32_t(*)();
  using ReadHeap=Heap(*)();
  Context(Tracker& tracker,Clock now,ReadHeap heap):tracker_(tracker),now_(now),heap_(heap) {}
  ~Context() { release(); }
  Context(const Context&)=delete;
  Context& operator=(const Context&)=delete;
  class Attempt {
   public:
    explicit Attempt(Context& context):context_(context),outer_(context_.connectDepth_++==0) {
      if(!outer_) return;
      started_=context_.clock();
      if(!context_.live_) { context_.live_=true; context_.tracker_.open(); }
      context_.tracker_.beginConnect(); context_.sample();
    }
    ~Attempt() { finish(false); }
    Attempt(const Attempt&)=delete;
    Attempt& operator=(const Attempt&)=delete;
    bool outer() const { return outer_; }
    void finish(bool success) {
      if(finished_) return;
      finished_=true;
      if(outer_) {
        context_.sample();
        context_.tracker_.endConnect(success,uint32_t(context_.clock()-started_));
        if(!success) context_.release();
      }
      --context_.connectDepth_;
    }
   private:
    Context& context_;
    uint32_t started_=0;
    bool outer_,finished_=false;
  };
  // Surround the real SDK stop() so both the still-allocated and freed states
  // are sampled. Repeated close and SDK close during a failed connect are safe.
  class Closing {
   public:
    explicit Closing(Context& context):context_(context),active_(context.live_) {
      if(active_) { outer_=context_.closeDepth_++==0; if(outer_) context_.sample(); }
    }
    ~Closing() {
      if(!active_) return;
      if(outer_) {
        context_.sample();
        // SDK cleanup can call virtual stop() from within connect. The outer
        // attempt still owns that transport until its final success/failure.
        if(!context_.connectDepth_) context_.release();
      }
      --context_.closeDepth_;
    }
    Closing(const Closing&)=delete;
    Closing& operator=(const Closing&)=delete;
   private:
    Context& context_;
    bool active_,outer_=false;
  };
 private:
  Tracker& tracker_;
  Clock now_;
  ReadHeap heap_;
  unsigned connectDepth_=0,closeDepth_=0;
  bool live_=false;
  uint32_t clock() const { return now_?now_():0; }
  void sample() { if(heap_) tracker_.sample(heap_()); }
  void release() { if(live_) { live_=false; tracker_.close(); } }
};
inline Tracker tracker;
inline Snapshot snapshot() { return tracker.snapshot(); }
#ifdef ARDUINO
inline uint32_t clock() { return millis(); }
inline Heap internalHeap() {
  constexpr uint32_t caps=MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT;
  return {uint32_t(heap_caps_get_free_size(caps)),uint32_t(heap_caps_get_largest_free_block(caps))};
}
#endif
} // namespace Tamagotchi::TlsDiagnostics
