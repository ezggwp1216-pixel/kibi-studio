#pragma once
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <type_traits>

namespace Tamagotchi::ServerTransport {
constexpr bool usesTls(const char* url) {
  if(!url) return false;
  constexpr char prefix[]="https://";
  for(size_t i=0;i<sizeof prefix-1;++i) if(url[i]!=prefix[i]) return false;
  return true;
}
template<bool Secure,class PlainClient,class SecureClient>
using ClientFor=std::conditional_t<Secure,SecureClient,PlainClient>;

// Stream and the ESP32 socket have separate millisecond timeout fields.
template<class Client> inline void configureIoTimeout(Client& client,uint32_t milliseconds) {
  client.setTimeout(milliseconds);
  client.setConnectionTimeout(milliseconds);
}
template<class Client> inline int finishPlainConnect(Client& client,int connected) {
  if(connected) client.setNoDelay(true);
  return connected;
}
// A persistent identity namespace is independent from the current HTTP/HTTPS
// transport. Keep the exact historical namespace + newline + token hash input.
template<class Update> inline bool updateReceiptScope(const char* nameSpace,const char* token,Update update) {
  if(!nameSpace || !token) return false;
  return update(reinterpret_cast<const unsigned char*>(nameSpace),std::strlen(nameSpace)) &&
      update(reinterpret_cast<const unsigned char*>("\n"),1) &&
      update(reinterpret_cast<const unsigned char*>(token),std::strlen(token));
}
struct Endpoint { char host[128]{},prefix[128]{}; uint16_t port=80; bool secure=false; };
inline bool parseEndpoint(const char* url,Endpoint& out) {
  if(!url || std::strpbrk(url,"\r\n\t @?#")) return false;
  const bool secure=usesTls(url);
  if(!secure && std::strncmp(url,"http://",7)) return false;
  const char* host=url+(secure?8:7);
  const char* slash=std::strchr(host,'/'); const char* end=slash?slash:host+std::strlen(host);
  const char* colon=static_cast<const char*>(std::memchr(host,':',size_t(end-host)));
  const size_t hostBytes=size_t((colon?colon:end)-host);
  if(!hostBytes || hostBytes>=sizeof out.host || (slash && std::strlen(slash)>=sizeof out.prefix)) return false;
  unsigned port=secure?443:80;
  if(colon) {
    if(colon+1==end) return false;
    port=0;
    for(const char* p=colon+1;p<end;++p) {
      if(*p<'0' || *p>'9' || port>6553) return false;
      port=port*10+unsigned(*p-'0');
    }
    if(!port || port>65535) return false;
  }
  for(size_t i=0;i<hostBytes;++i) if(!((host[i]>='a' && host[i]<='z') || (host[i]>='A' && host[i]<='Z') ||
      (host[i]>='0' && host[i]<='9') || host[i]=='-' || host[i]=='.')) return false;
  out={}; std::memcpy(out.host,host,hostBytes); out.port=uint16_t(port); out.secure=secure;
  if(slash) std::strcpy(out.prefix,slash);
  size_t length=std::strlen(out.prefix); while(length && out.prefix[length-1]=='/') out.prefix[--length]=0;
  return true;
}
inline bool formatHost(const Endpoint& endpoint,char* host,size_t capacity) {
  const int count=endpoint.port==(endpoint.secure?443:80)?std::snprintf(host,capacity,"%s",endpoint.host):
      std::snprintf(host,capacity,"%s:%u",endpoint.host,unsigned(endpoint.port));
  return count>0 && size_t(count)<capacity;
}
} // namespace Tamagotchi::ServerTransport
