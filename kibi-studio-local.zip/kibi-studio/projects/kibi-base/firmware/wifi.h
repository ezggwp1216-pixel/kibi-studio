#pragma once
#ifdef ARDUINO
#include <WiFiMulti.h>
#include <Preferences.h>
#include <time.h>
#include <sys/time.h>
#include <cstring>
#ifdef KIBI_PROJECT_CONFIG
#if __has_include("kibi_project_config.h")
#include "kibi_project_config.h"
#endif
#endif
namespace Tamagotchi {
namespace WifiDetail {
inline bool timeSynchronized=false;
inline bool ntpStarted=false;
}
#ifdef KIBI_PROJECT_CONFIG
inline bool wifiSettingsValid() {
  const size_t ssidLength=std::strlen(KIBI_WIFI_SSID),passwordLength=std::strlen(KIBI_WIFI_PASSWORD);
  if(!ssidLength || ssidLength>32 || passwordLength>64) return false;
  if(passwordLength && passwordLength<8) return false;
  if(passwordLength==64) for(size_t i=0;i<passwordLength;++i) {
    const char c=KIBI_WIFI_PASSWORD[i];
    if(!((c>='0' && c<='9') || (c>='a' && c<='f') || (c>='A' && c<='F'))) return false;
  }
  return true;
}
#endif
// Clean replacement for the private lab module. Never reads old ESP Wi-Fi NVS.
// A new owner's provisioning integration may populate this separate namespace.
inline void beginWifi() {
  WiFi.persistent(false);
#ifdef KIBI_PROJECT_CONFIG
  // This app uses only the trusted site form, never an earlier owner's NVS.
  if(!wifiSettingsValid()) return;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(KIBI_WIFI_SSID,*KIBI_WIFI_PASSWORD?KIBI_WIFI_PASSWORD:nullptr);
#else
  Preferences settings;
  if(!settings.begin("kibi_owner",true)) return;
  const String ssid=settings.getString("ssid","");
  const String password=settings.getString("password","");
  settings.end();
  if(!ssid.length()) return;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(ssid.c_str(),password.c_str());
#endif
}
inline void acceptTrustedServerTime(uint32_t epoch) {
  if(epoch<1700000000u) return;
  timeval value{static_cast<time_t>(epoch),0};
  if(settimeofday(&value,nullptr)==0) WifiDetail::timeSynchronized=true;
}
inline void updateWifi(int& hour,int& minute,int& level) {
  level=0;
  if(WiFi.status()==WL_CONNECTED) {
    const int rssi=WiFi.RSSI();level=rssi>-60?3:rssi>-75?2:1;
    if(!WifiDetail::ntpStarted) {
      configTime(0,0,"pool.ntp.org","time.cloudflare.com");WifiDetail::ntpStarted=true;
    }
  }
  const time_t now=time(nullptr);WifiDetail::timeSynchronized=now>1700000000;
  if(WifiDetail::timeSynchronized) {
    tm t{};localtime_r(&now,&t);hour=t.tm_hour;minute=t.tm_min;
  }
}
}
#else
namespace Tamagotchi { namespace WifiDetail { inline bool timeSynchronized=false; } }
#endif
