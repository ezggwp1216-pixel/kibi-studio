#pragma once
#include <ArduinoJson.h>
#include <cstddef>
#include <cstdint>
#include <cstdlib>

// Portable application state and decisions. The protected hardware adapter and
// native preview both use this exact reducer; no GPIO, networking or Arduino.
namespace KibiApp {
inline constexpr uint8_t kScreenCount=3;
struct Model {uint8_t screenIndex=0;bool moduleOpen=false;bool enabled=false;};
enum class InputKind:uint8_t {Plus,Minus,Tap,Swipe};
struct Input {InputKind kind=InputKind::Tap;int x=-1,y=-1,dx=0,dy=0;uint32_t durationMs=200;};
enum class Action:uint8_t {None,NextScreen,PreviousScreen,OpenModule,CloseModule,Toggle};
inline const char* actionName(Action action) {
 switch(action){case Action::NextScreen:return "nextScreen";case Action::PreviousScreen:return "previousScreen";case Action::OpenModule:return "openModule";case Action::CloseModule:return "closeModule";case Action::Toggle:return "toggle";default:return "none";}
}
// Explicit public-state codec. Add module fields here when Model grows; Studio
// and the native runner deliberately do not know this application's field names.
// Never encode credentials, private configuration or hardware handles.
inline void encodeState(const Model& model,JsonObject out){out["screenIndex"]=model.screenIndex;out["moduleOpen"]=model.moduleOpen;out["enabled"]=model.enabled;}
inline bool decodeState(Model& model,JsonObjectConst in){if(!in["screenIndex"].is<int>()||in["screenIndex"].as<int>()<0||in["screenIndex"].as<int>()>=kScreenCount||!in["moduleOpen"].is<bool>()||!in["enabled"].is<bool>())return false;model.screenIndex=in["screenIndex"].as<uint8_t>();model.moduleOpen=in["moduleOpen"].as<bool>();model.enabled=in["enabled"].as<bool>();return true;}
// nowMs is elapsed monotonic milliseconds. Return true when a timer changes UI
// state; the same portable tick runs in the hardware adapter and native preview.
inline bool tick(Model&,uint32_t){return false;}
inline void normalize(Model& model){if(model.screenIndex>=kScreenCount)model.screenIndex=0;if(model.screenIndex!=1)model.moduleOpen=false;}
namespace Layout {
struct Rect {int x,y,width,height;};
inline constexpr Rect homeModules{24,190,192,44},moduleDemo{24,100,192,62},moduleBack{24,244,192,42},settingToggle{24,104,192,64};
inline bool contains(Rect rect,int x,int y){return x>=rect.x&&y>=rect.y&&x<rect.x+rect.width&&y<rect.y+rect.height;}
}
enum class Target:int8_t {None=-1,HomeModules,ModuleDemo,ModuleBack,SettingToggle};
inline Target hitTarget(const Model& model,int x,int y){
 if(x<0||x>=240||y<0||y>=296)return Target::None;
 if(model.moduleOpen)return Layout::contains(Layout::moduleBack,x,y)?Target::ModuleBack:Target::None;
 if(model.screenIndex==0&&Layout::contains(Layout::homeModules,x,y))return Target::HomeModules;
 if(model.screenIndex==1&&Layout::contains(Layout::moduleDemo,x,y))return Target::ModuleDemo;
 if(model.screenIndex==2&&Layout::contains(Layout::settingToggle,x,y))return Target::SettingToggle;
 return Target::None;
}
inline Action navigate(Model& model,bool next){model.screenIndex=uint8_t((model.screenIndex+(next?1:kScreenCount-1))%kScreenCount);model.moduleOpen=false;return next?Action::NextScreen:Action::PreviousScreen;}
inline Action reduceInput(Model& model,const Input& input){
 normalize(model);
 if(input.kind==InputKind::Plus)return navigate(model,true);
 if(input.kind==InputKind::Minus)return navigate(model,false);
 if(input.durationMs>1200)return Action::None;
 if(input.kind==InputKind::Swipe){if(std::abs(input.dx)<28||std::abs(input.dx)<=std::abs(input.dy))return Action::None;return navigate(model,input.dx<0);}
 if(input.kind!=InputKind::Tap||std::abs(input.dx)>10||std::abs(input.dy)>10)return Action::None;
 const Target target=hitTarget(model,input.x,input.y);
 if(target==Target::None||target!=hitTarget(model,input.x-input.dx,input.y-input.dy))return Action::None;
 switch(target){
 case Target::HomeModules:model.screenIndex=1;return Action::NextScreen;
 case Target::ModuleDemo:model.moduleOpen=true;return Action::OpenModule;
 case Target::ModuleBack:model.moduleOpen=false;return Action::CloseModule;
 case Target::SettingToggle:model.enabled=!model.enabled;return Action::Toggle;
 default:return Action::None;
 }
}
} // namespace KibiApp
