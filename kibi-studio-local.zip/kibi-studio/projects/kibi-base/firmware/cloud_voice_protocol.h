#pragma once
#include "cloud_voice_config.h"
#include "assistant.h"
#include "shopping_notes.h"

namespace Tamagotchi::CloudVoice {
enum class Result { Pending,Complete,Unavailable,Failed,Invalid };
inline bool lowerHex(const char* value,size_t bytes) {
  if(!value || strnlen(value,bytes+1)!=bytes) return false;
  for(size_t i=0;i<bytes;++i) if(!((value[i]>='0' && value[i]<='9') || (value[i]>='a' && value[i]<='f'))) return false;
  return true;
}
inline bool retryableHttp(int status) {
  return status<0 || status==408 || status==425 || status==429 || (status>=500 && status<=599);
}
inline bool canPollAfterUpload(int status,bool valid) {
  // A lost acknowledgement is ambiguous: ask about the original identity,
  // including a successful HTTP response whose JSON body was interrupted.
  return valid || status==200 || status==201 || status==202 || retryableHttp(status);
}
inline uint32_t pollRemaining(uint32_t started,uint32_t now) {
  const uint32_t elapsed=uint32_t(now-started);
  return elapsed>=kPollMilliseconds?0:uint32_t(kPollMilliseconds)-elapsed;
}
inline bool retryInitialMissingJob(int status,bool observed,uint32_t started,uint32_t now,uint32_t grace) {
  return status==404 && !observed && grace && uint32_t(now-started)<grace;
}
inline Result parseResult(JsonVariantConst json,const char* expectedId,char* transcript,size_t transcriptCapacity,
                          Assistant::Reply& reply,char* error,size_t errorCapacity) {
  auto invalid=[&]() { Weather::fail(error,errorCapacity,"The server returned an invalid result. It will not be retried."); return Result::Invalid; };
  const char *id,*status;
  if(!json.is<JsonObjectConst>() || !lowerHex(expectedId,32) ||
     !Assistant::Detail::stringField(json,"job_id",33,id) || strcmp(id,expectedId) ||
     !Assistant::Detail::stringField(json,"status",16,status)) return invalid();
  if(!strcmp(status,"queued") || !strcmp(status,"processing") || !strcmp(status,"retry")) return Result::Pending;
  if(!strcmp(status,"failed")) {
    Weather::fail(error,errorCapacity,"The service could not process the recording. Record again.");
    return Result::Failed;
  }
  if(strcmp(status,"completed") || !transcript || !transcriptCapacity) return invalid();
  const char *text,*kind,*title,*description,*answer;
  const auto command=json["command"];
  if(!Assistant::Detail::stringField(json,"transcript",transcriptCapacity,text) ||
     !Assistant::Detail::validContent(text,transcriptCapacity) || !command.is<JsonObjectConst>() ||
     !Assistant::Detail::stringField(command,"type",16,kind) ||
     !Assistant::Detail::stringField(command,"title",sizeof reply.title,title) ||
     (*title && !Assistant::Detail::validContent(title,sizeof reply.title))) return invalid();
  const bool note=!strcmp(kind,"note"),shopping=!strcmp(kind,"shopping"),
      unavailable=!strcmp(kind,"unavailable"),reminder=!strcmp(kind,"reminder");
  const size_t descriptionCapacity=shopping?size_t(kNoteTextBytes)+1-ShoppingNotes::kPrefixBytes:2049;
  if(!Assistant::Detail::stringField(command,"description",descriptionCapacity,description) ||
     (shopping && (!Assistant::Detail::validContent(description,descriptionCapacity) ||
       transcriptCapacity<=ShoppingNotes::kPrefixBytes ||
       strlen(description)>=transcriptCapacity-ShoppingNotes::kPrefixBytes)) ||
     !Assistant::Detail::stringField(command,"reply",sizeof reply.answer,answer) ||
     !Assistant::Detail::validContent(answer,sizeof reply.answer) ||
     (!command["execute_at"].isNull() && (!command["execute_at"].is<int64_t>() || command["execute_at"].is<bool>()))) return invalid();
  if(!note && !shopping && !unavailable && !reminder && strcmp(kind,"answer") && strcmp(kind,"clarify")) return invalid();
  if(reminder && (!command["execute_at"].is<int64_t>() || command["execute_at"].as<int64_t>()<=0)) return invalid();
  if(!reminder && !command["execute_at"].isNull()) return invalid();
  // Copy only validated strings before the caller releases its JSON document.
  if(shopping) {
    memcpy(transcript,ShoppingNotes::kPrefix,ShoppingNotes::kPrefixBytes);
    strcpy(transcript+ShoppingNotes::kPrefixBytes,description);
  } else strcpy(transcript,text);
  reply.reset();
  strcpy(reply.jobId,expectedId);
  strcpy(reply.title,title);
  // Keep the validated durable acknowledgement separate from note/list text.
  // App may display it only after its own local note save succeeds.
  strcpy(reply.answer,answer);
  if(note) { reply.intent=Assistant::Intent::Note; reply.text=transcript; }
  else if(shopping) {
    reply.intent=Assistant::Intent::Shopping; reply.text=transcript+ShoppingNotes::kPrefixBytes;
    strcpy(reply.heading,ShoppingNotes::kHeading);
  }
  else {
    // Reminder scheduling and bridge insertion have already committed on Core.
    // Returning Reminder here would make App enqueue a second command.
    reply.intent=Assistant::Intent::Answer; reply.text=reply.answer;
    strcpy(reply.heading,reminder?"Reminder":unavailable?"Unavailable":
        !strcmp(kind,"clarify")?"Clarification":"Answer");
  }
  return unavailable?Result::Unavailable:Result::Complete;
}

struct RecordingIdentity {
  char jobId[33]{},sha256[65]{};
  uint32_t bytes=0,noteId=0;
};
enum class IdentityStatus { Missing,Ready,Invalid,Error };
inline uint32_t identityCrc(const char* data,size_t bytes) {
  uint32_t crc=0xffffffff;
  for(size_t i=0;i<bytes;++i) {
    crc^=uint8_t(data[i]);
    for(int bit=0;bit<8;++bit) crc=(crc>>1)^(0xedb88320u & (0u-(crc&1)));
  }
  return ~crc;
}
inline bool validIdentity(const RecordingIdentity& identity) {
  return lowerHex(identity.jobId,32) && lowerHex(identity.sha256,64) && identity.noteId &&
    identity.bytes>=46 && identity.bytes<=44+2*AudioFile::kMaximumSamples && identity.bytes%2==0;
}
inline bool identityMatches(const RecordingIdentity& identity,const char* sha256,size_t bytes) {
  return validIdentity(identity) && sha256 && !strcmp(identity.sha256,sha256) && identity.bytes==bytes;
}
inline size_t encodeIdentity(const RecordingIdentity& identity,char (&data)[160]) {
  if(!validIdentity(identity)) return 0;
  const int bytes=snprintf(data,sizeof data,"cloud-v1\n%s\n%s\n%010lu\n%08lx\n",identity.jobId,identity.sha256,
      static_cast<unsigned long>(identity.bytes),static_cast<unsigned long>(identity.noteId));
  if(bytes<=0 || size_t(bytes)+9>=sizeof data) return 0;
  snprintf(data+bytes,sizeof data-size_t(bytes),"%08lx\n",static_cast<unsigned long>(identityCrc(data,size_t(bytes))));
  return size_t(bytes)+9;
}
inline IdentityStatus readIdentity(const char* wav,RecordingIdentity& out) {
  char path[256]; if(!AudioFile::sidecarPath(wav,".cloud",path)) return IdentityStatus::Error;
  FILE* file=fopen(path,"rb"); if(!file) return errno==ENOENT?IdentityStatus::Missing:IdentityStatus::Error;
  char data[160]{}; const size_t bytes=fread(data,1,sizeof data-1,file);
  const bool complete=!ferror(file) && fgetc(file)==EOF; fclose(file);
  RecordingIdentity parsed; unsigned long wavBytes=0,noteId=0,crc=0; int consumed=0;
  if(!complete || memchr(data,0,bytes) || sscanf(data,"cloud-v1\n%32[0-9a-f]\n%64[0-9a-f]\n%10lu\n%8lx\n%8lx\n%n",
      parsed.jobId,parsed.sha256,&wavBytes,&noteId,&crc,&consumed)!=5 || size_t(consumed)!=bytes ||
      wavBytes>UINT32_MAX || noteId>UINT32_MAX) return IdentityStatus::Invalid;
  parsed.bytes=uint32_t(wavBytes); parsed.noteId=uint32_t(noteId);
  char canonical[160]; const size_t canonicalBytes=encodeIdentity(parsed,canonical);
  if(canonicalBytes!=bytes || memcmp(canonical,data,bytes)) return IdentityStatus::Invalid;
  out=parsed; return IdentityStatus::Ready;
}
inline bool saveIdentity(const char* wav,const RecordingIdentity& identity) {
  char data[160]; const size_t bytes=encodeIdentity(identity,data); if(!bytes) return false;
  RecordingIdentity existing; const auto recovered=readIdentity(wav,existing);
  if(recovered==IdentityStatus::Ready) return !strcmp(existing.jobId,identity.jobId) && existing.noteId==identity.noteId &&
    identityMatches(existing,identity.sha256,identity.bytes);
  if(recovered!=IdentityStatus::Missing) return false;
  char path[256],temporary[256];
  if(!AudioFile::sidecarPath(wav,".cloud",path) || !AudioFile::sidecarPath(wav,".cloud.tmp",temporary)) return false;
  FILE* file=fopen(temporary,"wb"); if(!file) return false;
  const bool wrote=fwrite(data,1,bytes,file)==bytes;
  const bool flushed=fflush(file)==0;
  const bool synced=flushed && fsync(fileno(file))==0;
  const bool closed=fclose(file)==0;
  if(!wrote || !synced || !closed || rename(temporary,path)!=0) { remove(temporary); return false; }
  RecordingIdentity checked;
  return readIdentity(wav,checked)==IdentityStatus::Ready && !strcmp(identity.jobId,checked.jobId) && checked.noteId==identity.noteId;
}
// Called only before a new WAV is created, never on a retained/retried WAV.
inline bool clearIdentity(const char* wav=AudioFile::kPendingPath) {
  char path[256];
  for(const char* suffix:{".cloud",".cloud.tmp"}) {
    if(!AudioFile::sidecarPath(wav,suffix,path) || (remove(path)!=0 && errno!=ENOENT)) return false;
  }
  return true;
}
} // namespace Tamagotchi::CloudVoice
