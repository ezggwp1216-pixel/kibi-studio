#pragma once
#include <stddef.h>
#include <stdint.h>
namespace Tamagotchi {
struct PlaybackRule {
  bool enabled = true;
  uint8_t trigger = 0;
  uint32_t intervalSeconds = 20;
  int priority = 50, start = 1380, end = 420;
  bool repeat = false;
  uint32_t duration = 0;
  bool randomized = false;
};
inline bool inSleepWindow(int minute, int start, int end) {
  if (minute < 0 || minute >= 1440) return false;
  return start < end ? (minute >= start && minute < end) : (minute >= start || minute < end);
}
inline int playbackFrame(const uint16_t* durations, int count, uint32_t start, uint32_t now, bool repeat) {
  if (!durations || count < 1) return 0;
  uint32_t total = 0;
  for (int i = 0; i < count; ++i) total += durations[i];
  if (!total) return 0;
  uint32_t age = uint32_t(now - start);
  if (repeat)
    age %= total;
  else if (age >= total)
    return count - 1;
  for (int i = 0; i < count; ++i) {
    if (age < durations[i]) return i;
    age -= durations[i];
  }
  return count - 1;
}
// Recording advances to the final pose and holds it. Release walks back through
// the same frames; a new press changes direction without changing the pose.
class VoiceRecordingPose {
 public:
  bool update(bool recording,uint32_t now,const uint16_t* durations,int count) {
    const int before=frame_;
    if(!durations || count<1 || count>256) {
      frame_=-1;
      recording_=recording;
      return before!=frame_;
    }
    if(recording && frame_<0) { frame_=0; frameAt_=now; }
    if(recording!=recording_) { recording_=recording; frameAt_=now; }
    if(frame_>=count) frame_=count-1;
    while(frame_>=0) {
      if(recording && frame_==count-1) break;
      const uint32_t duration=durations[frame_]?durations[frame_]:1;
      if(uint32_t(now-frameAt_)<duration) break;
      frameAt_+=duration;
      frame_+=recording?1:-1;
    }
    return frame_!=before;
  }
  int frameIndex() const { return frame_; }
 private:
  int frame_=-1;
  bool recording_=false;
  uint32_t frameAt_=0;
};
class AnimationRules {
 public:
  void configure(const PlaybackRule* values, int count, uint32_t now) {
    count_ = count < 0 ? 0 : (count > 7 ? 7 : count);
    base_=-1;
    for (int i = 0; i < count_; ++i) {
      rules_[i] = values[i];
      last_[i] = now;
      random_[i]=now^(uint32_t(i+1)*0x9E3779B9u);
      wait_[i]=nextInterval(i);
      if(base_<0 && rules_[i].enabled && rules_[i].duration && rules_[i].trigger==3) base_=i;
    }
    active_ = -1;
    started_ = now;
  }
  int update(uint32_t now, bool charging, int hour = -1, int minute = -1, bool chargeOwnsScreen = true) {
    if (charging && chargeOwnsScreen) {
      for (int i = 0; i < count_; ++i) last_[i] = now;
      active_ = -1;
      return -1;
    }
    // New packages keep a base sway underneath finite occasional actions.
    // Complete one action before considering another due action.
    if(base_>=0 && active_>=0 && rules_[active_].trigger==0 &&
        uint32_t(now-started_)<rules_[active_].duration) return active_;
    int selected = -1;
    for (int i = 0; i < count_; ++i) {
      const auto& r = rules_[i];
      if (!r.enabled || !r.duration) continue;
      bool eligible = false;
      if (r.trigger == 2)
        eligible = hour >= 0 && hour < 24 && minute >= 0 && minute < 60 &&
                   inSleepWindow(hour * 60 + minute, r.start, r.end);
      else if (r.trigger == 1)
        eligible = charging;
      else if (r.trigger == 0)
        eligible = (i == active_ && (r.repeat || uint32_t(now - started_) < r.duration)) ||
                   uint32_t(now - last_[i]) >= wait_[i];
      if (eligible && (selected < 0 || r.priority > rules_[selected].priority)) selected = i;
    }
    if(selected<0) selected=base_;
    if (selected != active_) {
      active_ = selected;
      started_ = now;
      if (selected >= 0) { last_[selected] = now;wait_[selected]=nextInterval(selected); }
    }
    return active_;
  }
  uint32_t startedAt() const { return started_; }

 private:
  PlaybackRule rules_[7]{};
  uint32_t last_[7]{},wait_[7]{},random_[7]{}, started_ = 0;
  int count_ = 0, active_ = -1,base_=-1;
  uint32_t nextInterval(int index) {
    const auto& rule=rules_[index];
    const uint32_t base=rule.intervalSeconds*1000;
    if(!rule.randomized || rule.trigger!=0 || !base) return base;
    auto& seed=random_[index];
    seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;
    const uint32_t spread=base/5;
    return base-spread+seed%(2*spread+1);
  }
};
}  // namespace Tamagotchi
