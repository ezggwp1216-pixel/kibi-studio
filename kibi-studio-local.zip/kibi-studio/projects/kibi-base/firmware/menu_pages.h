#pragma once
#include "fullscreen_page.h"
#include "daily_weather.h"

namespace Tamagotchi::MenuPages {
class View {
 public:
  bool open(const MenuModule& module) {
    if(!module.id || !*module.id || !module.label || !*module.label) return false;
    id_=module.id;title_=module.label;visible_=true;++revision_;
    setBody(module.description?module.description:"An integration will appear here.");
    return true;
  }
  bool visible() const { return visible_; }
  bool isWeather() const { return visible_ && !std::strcmp(id_,"weather"); }
  bool isCalories() const { return visible_ && !std::strcmp(id_,"calories"); }
  const char* title() const { return title_; }
  const char* body() const { return body_; }
  bool setBody(const char* value) {
    if(!value) value="";
    size_t bytes=strnlen(value,sizeof body_);
    if(bytes>=sizeof body_) {
      bytes=sizeof body_-1;
      while(bytes && (uint8_t(value[bytes])&0xc0)==0x80) --bytes;
    }
    if(std::strlen(body_)==bytes && !std::memcmp(body_,value,bytes)) return false;
    std::memmove(body_,value,bytes);body_[bytes]=0;++revision_;return true;
  }
  void close() { if(visible_) { visible_=false;++revision_; } }
  uint32_t revision() const { return revision_; }
  int scrollLimit(int width,int height) const {
    return visible_?PageUi::scrollLimit(body_,PageUi::layout(width,height,title_)):0;
  }
 private:
  const char* id_="",*title_="";
  char body_[2048]{};
  uint32_t revision_=0;
  bool visible_=false;
};
// Compact, deterministic content is shared by the physical and virtual display.
inline bool formatWeatherPageBody(const DailyWeather::Snapshot& weather,char* out,size_t capacity,int32_t utcOffset=7*3600) {
  if(!out || !capacity) return false;
  out[0]=0;
  int bytes=0;
  if(weather.hasForecast) {
    const char* city=Weather::sameName(weather.city,"Qui Nhon") || Weather::sameName(weather.city,"Quy Nhon")
        ?"Qui Nhon":weather.city;
    const time_t local=time_t(weather.fetchedAt+utcOffset);
    tm parts{};char clock[6]="--:--";
    if(DailyWeather::validTime(weather.fetchedAt) && gmtime_r(&local,&parts))
      std::strftime(clock,sizeof clock,"%H:%M",&parts);
    bytes=std::snprintf(out,capacity,
        "%s%s, %.2s.%.2s\n%s\nTemp. %+.0f °C\nFeels %+.0f °C\nToday %+.0f…%+.0f °C\nPrecip. up to %d%%\nWind %.0f km/h\n\nUpdated %s\nOpen-Meteo.com%s",
        weather.stale?"Outdated forecast\n":"",city,weather.forecastDate+8,weather.forecastDate+5,
        Weather::condition(weather.weatherCode),weather.currentC,weather.feelsC,weather.minC,weather.maxC,
        weather.precipitationPercent,weather.windKmh,clock,
        weather.refreshing?"\nRefreshing…":weather.status==DailyWeather::Status::Error?"\nNo recent data":"");
  } else {
    const char* message="Waiting for a forecast update.";
    switch(weather.status) {
      case DailyWeather::Status::WaitingForTime:message="Waiting for the clock.\n\nThe forecast will appear automatically.";break;
      case DailyWeather::Status::WaitingForWifi:message="Connect to Wi-Fi.\n\nThe forecast will appear once connected.";break;
      case DailyWeather::Status::Updating:message="Loading today's forecast…\n\nYou can return to the menu.";break;
      case DailyWeather::Status::Error:message="Could not refresh the forecast.";break;
      default:break;
    }
    bytes=weather.status==DailyWeather::Status::Error?
        std::snprintf(out,capacity,"%s\n\n%s\n\nWill retry automatically.",message,weather.error):
        std::snprintf(out,capacity,"%s",message);
  }
  if(bytes<0 || size_t(bytes)>=capacity) { out[0]=0;return false; }
  return true;
}
inline void draw(uint16_t* frame,int width,int height,const View& view,int offset=0,bool pressedBack=false) {
  if(!view.visible()) return;
  const auto page=PageUi::layout(width,height,view.title());
  PageUi::drawShell(frame,width,height,view.title(),pressedBack);
  PageUi::drawBody(frame,width,height,view.body(),page,offset);
  PageUi::drawScrollIndicator(frame,width,height,page,offset,
      Ui::textLineCount(view.body(),page.textColumns)*Ui::textLineHeight(view.body(),page.lineHeight,page.textScale));
}
}
