#pragma once

#include "design.h"
#include "vietnamese_font.h"
#include "ui_font.h"
#include <algorithm>
#include <limits.h>
#include <string.h>

namespace Tamagotchi {

// Custom headers can register a module before beginDisplayTouch():
// addMenuModule({"my_app", "My module", openMyApp});
// Keep id/label strings alive for the lifetime of the sketch.
struct MenuModule {
  const char* id;
  const char* label;
  void (*onSelect)() = nullptr;
  const char* description = nullptr;
};
namespace MenuDetail {
constexpr int kCapacity = 12;
inline MenuModule modules[kCapacity] = {
  {"notes", "Notes"}, {"shopping", "Shopping"},
  {"weather", "Weather", nullptr, "Today's forecast.\n\nUpdates at noon and when kibi starts."},
  {"calories", "Calories", nullptr, "Today's calories.\n\nSay a food and its weight or the calories in your portion."},
  {"news", "News", nullptr, "Your news feed.\n\nA news source has not been connected yet."},
  {"plans", "Plans", nullptr, "Your plans and tasks.\n\nTask integrations will appear here."},
  {"recorder", "Recorder"},
  {"settings", "Settings", nullptr, "Your kibi settings.\n\nEdit appearance and connections in the kibi web app."},
  {"spotify", "Spotify", nullptr, "Music and playlists.\n\nYour Spotify connection will appear here."}
};
inline int count = 9;
}
inline int menuModuleCount() { return MenuDetail::count; }
inline const MenuModule* menuModule(int index) {
  return index>=0 && index<menuModuleCount()?&MenuDetail::modules[index]:nullptr;
}
inline bool addMenuModule(const MenuModule& module) {
  using namespace MenuDetail;
  if (!module.id || !*module.id || !module.label || !*module.label || count >= kCapacity) return false;
  for (int i = 0; i < count; ++i) if (!strcmp(modules[i].id, module.id)) return false;
  modules[count++] = module;
  return true;
}
inline bool setMenuAction(const char* id, void (*action)()) {
  if (!id) return false;
  for (int i=0; i<menuModuleCount(); ++i) if (!strcmp(MenuDetail::modules[i].id,id)) {
    MenuDetail::modules[i].onSelect=action; return true;
  }
  return false;
}
inline bool activateMenuItem(int item) {
  if (item < 0 || item >= menuModuleCount() || !MenuDetail::modules[item].onSelect) return false;
  MenuDetail::modules[item].onSelect();
  return true;
}
inline int menuBottom() { return theme().menu.top + (menuModuleCount()-1)*theme().menu.stride + theme().menu.height; }
inline int menuScrollTarget() { return theme().menu.top-48; }
inline int sceneMaxOffset(int height) {
  const int limit = menuBottom() + kMenuBottomPadding - height;
  return limit > 0 ? limit : 0;
}

namespace Ui {
inline bool roundedPixel(int x, int y, int width, int height, int radius) {
  if (x < 0 || y < 0 || x >= width || y >= height) return false;
  const int dx = x < radius ? radius-x-1 : (x >= width-radius ? x-(width-radius) : 0);
  const int dy = y < radius ? radius-y-1 : (y >= height-radius ? y-(height-radius) : 0);
  return dx*dx + dy*dy <= radius*radius;
}
inline uint16_t blend(uint16_t base, uint16_t color, unsigned alpha) {
  const unsigned inverse = 255-alpha;
  const unsigned r = (((base>>11)&31)*inverse + ((color>>11)&31)*alpha + 127)/255;
  const unsigned g = (((base>>5)&63)*inverse + ((color>>5)&63)*alpha + 127)/255;
  const unsigned b = ((base&31)*inverse + (color&31)*alpha + 127)/255;
  return uint16_t((r<<11)|(g<<5)|b);
}
// A constant color/opacity needs only 128 channel results, not RGB arithmetic
// for every framebuffer pixel. Tables live in the caller's internal stack RAM.
struct Blend565 {
  uint16_t red[32],green[64],blue[32];
  Blend565(uint16_t color,unsigned alpha) {
    const unsigned inverse=255-alpha;
    for(unsigned level=0;level<64;++level) {
      green[level]=uint16_t(((level*inverse+((color>>5)&63)*alpha+127)/255)<<5);
      if(level<32) {
        red[level]=uint16_t(((level*inverse+((color>>11)&31)*alpha+127)/255)<<11);
        blue[level]=uint16_t((level*inverse+(color&31)*alpha+127)/255);
      }
    }
  }
  uint16_t apply(uint16_t base) const {
    return red[base>>11]|green[(base>>5)&63]|blue[base&31];
  }
};
static_assert(sizeof(Blend565)==256,"Bound the blend lookup stack footprint");
inline void blendPixels(uint16_t* pixels,size_t count,const Blend565& lookup) {
  for(size_t i=0;i<count;++i) pixels[i]=lookup.apply(pixels[i]);
}
inline void pixel(uint16_t* frame, int width, int height, int x, int y, uint16_t color, unsigned alpha = 255) {
  if (x >= 0 && x < width && y >= 0 && y < height) {
    auto& output = frame[size_t(y)*width+x];
    output = blend(output, color, alpha);
  }
}
inline int roundedRowInset(int y,int height,int radius) {
  if(radius<=0) return 0;
  const int dy=y<radius?radius-y-1:(y>=height-radius?y-(height-radius):0);
  int inset=0,dx=radius-1;
  while(dx*dx+dy*dy>radius*radius) { ++inset;--dx; }
  return inset;
}
inline void box(uint16_t* frame, int width, int height, int x, int y, int w, int h,
                int radius, bool pressed, int clipTop) {
  if(!frame || width<=0 || height<=0 || w<=0 || h<=0) return;
  int64_t left=0,right=w,top=0,bottom=h;
  if(x<0) left=-int64_t(x);
  if(int64_t(x)+right>width) right=int64_t(width)-x;
  if(int64_t(y)+top<clipTop) top=int64_t(clipTop)-y;
  if(int64_t(y)+top<0) top=-int64_t(y);
  if(int64_t(y)+bottom>height) bottom=int64_t(height)-y;
  if(left>=right || top>=bottom) return;
  const Blend565 fill(pressed?theme().pressed:theme().card,230),edge(theme().border,220);
  for(int yy=int(top);yy<int(bottom);++yy) {
    auto* row=frame+size_t(y+yy)*width;
    // Preserve the old predicate for unusual custom callers outside the
    // validated radius range; ordinary cards use three contiguous spans.
    if(radius<0 || radius>w/2 || radius>h/2) {
      for(int xx=int(left);xx<int(right);++xx) if(roundedPixel(xx,yy,w,h,radius)) {
        auto& output=row[x+xx];
        output=(!roundedPixel(xx-1,yy-1,w-2,h-2,radius-1)?edge:fill).apply(output);
      }
      continue;
    }
    const int outer=roundedRowInset(yy,h,radius);
    const int inner=yy>0 && yy<h-1 && w>2?roundedRowInset(yy-1,h-2,radius-1):-1;
    const int innerLeft=inner<0?w-outer:1+inner,innerRight=inner<0?w-outer:w-1-inner;
    auto paint=[&](int from,int to,const Blend565& lookup) {
      if(from<left) from=int(left);
      if(to>right) to=int(right);
      if(from<to) blendPixels(row+(x+from),size_t(to-from),lookup);
    };
    paint(outer,innerLeft,edge);
    paint(innerLeft,innerRight,fill);
    paint(innerRight,w-outer,edge);
  }
}
inline uint32_t nextCodepoint(const char*& text) {
  return VietnameseText::nextCodepoint(text);
}
inline uint32_t nextTextCodepoint(const char*& text) { return VietnameseText::next(text); }
inline uint32_t nextTextCodepoint(const char*& text,const char* end) { return VietnameseText::next(text,end); }
inline bool usesVietnameseFont(const char* start,const char* end) {
  while(start && start<end && *start)
    if(VietnameseFont::isVietnamese(nextTextCodepoint(start,end))) return true;
  return false;
}
inline bool usesVietnameseFont(const char* value) {
  return value && usesVietnameseFont(value,value+strlen(value));
}
inline int textLineHeight(const char* value,int baseLineHeight=18,int scale=2) {
  if(scale<=0) return baseLineHeight;
  const int pitch=usesVietnameseFont(value)?UiFontData::kVietnameseLineHeight:UiFontData::kCommonLineHeight;
  const int64_t needed=(int64_t(pitch)*scale+1)/2;
  return needed>INT_MAX?INT_MAX:(needed>baseLineHeight?int(needed):baseLineHeight);
}
inline int boundedTextCoordinate(int64_t value) {
  return value<INT_MIN?INT_MIN:(value>INT_MAX?INT_MAX:int(value));
}
inline int textWidth(const char* start,const char* end,int scale=2) {
  if(!start || !end || start>=end || scale<=0) return 0;
  int64_t units=0;uint32_t previous=0;
  while(start<end && *start) {
    const auto* symbol=UiFont::glyph(nextTextCodepoint(start,end));
    if(!symbol) continue;
    units+=symbol->advance64+UiFont::kerning64(previous,symbol->code);
    if(units>(int64_t(INT_MAX)*128-64)/scale) return INT_MAX;
    previous=symbol->code;
  }
  return boundedTextCoordinate((units*scale+64)/128);
}
inline int textWidth(const char* value,int scale=2) {
  return value?textWidth(value,value+strlen(value),scale):0;
}
inline int textInkTop(const char* value,int scale=2) {
  if(!value || !*value || scale<=0) return 0;
  const int64_t cellTop=-(int64_t(UiFontData::kBaseline-UiFont::ascent(usesVietnameseFont(value)))*scale)/2;
  int64_t top=INT64_MAX;
  while(*value) {
    const auto* symbol=UiFont::glyph(nextTextCodepoint(value));
    if(symbol && symbol->height) top=std::min(top,cellTop+(int64_t(UiFontData::kBaseline+symbol->top)*scale+1)/2);
  }
  return top==INT64_MAX?0:boundedTextCoordinate(top);
}
inline int textInkHeight(const char* value,int scale=2) {
  if(!value || !*value || scale<=0) return 0;
  int64_t top=INT64_MAX,bottom=INT64_MIN;
  while(*value) {
    const auto* symbol=UiFont::glyph(nextTextCodepoint(value));
    if(symbol && symbol->height) {
      top=std::min(top,(int64_t(UiFontData::kBaseline+symbol->top)*scale+1)/2);
      bottom=std::max(bottom,(int64_t(UiFontData::kBaseline+symbol->top+symbol->height)*scale+1)/2);
    }
  }
  return top==INT64_MAX?0:boundedTextCoordinate(bottom-top);
}
inline int textCenteredX(const char* value,int width,int scale=2) {
  return boundedTextCoordinate((int64_t(width)-textWidth(value,scale))/2);
}
inline int centeredTextTop(const char* value,int top,int boxHeight,int scale=2) {
  return boundedTextCoordinate(int64_t(top)+(int64_t(boxHeight)-textInkHeight(value,scale))/2-textInkTop(value,scale));
}
// Legacy accessor is retained for custom theme/status-bar compatibility.
// Main text always uses Source Sans 3, including Vietnamese accents.
inline const uint8_t* glyph(uint32_t code, bool preserveCase=false) {
  static constexpr uint8_t unknown[7] = {14,17,1,2,4,0,4};
  static constexpr uint8_t space[7] = {};
  if (code >= 'a' && code <= 'z') {
    if (preserveCase) return theme().font->latinLower[code-'a'];
    code -= 32;
  }
  if (code >= 0x430 && code <= 0x44F) {
    if (preserveCase) return theme().font->cyrillicLower[code-0x430];
    code -= 32;
  }
  if (code == 0x451 && preserveCase) return theme().font->cyrillicLower[32];
  if (code == 0x451) code = 0x401;
  if (code >= 'A' && code <= 'Z') return theme().font->latinUpper[code-'A'];
  if (code >= 0x410 && code <= 0x42F) return theme().font->cyrillicUpper[code-0x410];
  if (code == 0x401) return theme().font->cyrillicUpper[32];
  if (code >= '0' && code <= '9') return theme().font->digits[code-'0'];
  if (code == ' ') return space;
  if (code == '-') return theme().font->digits[11];
  for (size_t i=0; i<sizeof(kTextPunctuationCodes)/sizeof(*kTextPunctuationCodes); ++i)
    if (code==kTextPunctuationCodes[i]) return kTextPunctuationRows[i];
  return unknown;
}
struct TextLine { const char* end; const char* next; };
inline TextLine wrapLine(const char* start, int columns) {
  if (!start || columns<1 || !*start) return {start,start};
  const char* at=start;
  const char* space=nullptr;
  int64_t units=0;uint32_t previous=0;
  const int64_t budget=int64_t(columns)*12*64;
  while (*at && *at!='\n' && *at!='\r') {
    const char* next=at;
    const auto* symbol=UiFont::glyph(nextTextCodepoint(next));
    const uint32_t code=symbol?symbol->code:0;
    const int advance=(symbol?symbol->advance64:64)+UiFont::kerning64(previous,code);
    if(units+advance>budget && at!=start) break;
    if (*at==' ' || *at=='\t') space=at;
    units+=advance;at=next;previous=code;
    if(units>=budget) break;
  }
  const char* end=at;
  if (*at && *at!='\n' && *at!='\r' && space && space>start) end=at=space;
  while (*at==' ' || *at=='\t') ++at;
  if (*at=='\r') ++at;
  if (*at=='\n') ++at;
  return {end,at};
}
inline int textLineCount(const char* text, int columns) {
  if (!text || columns<1) return 0;
  int lines=0;
  while (*text) { text=wrapLine(text,columns).next; ++lines; }
  return lines;
}
inline void textGlyph(uint16_t* frame,int width,int height,uint32_t code,int x,int y,int scale,
                      uint16_t color,int clipTop,int clipBottom,bool vietnamese) {
  if(!frame || width<=0 || height<=0 || scale<=0) return;
  const auto* symbol=UiFont::glyph(code);
  if(!symbol || !symbol->width || !symbol->height) return;
  const int sourceLeft=UiFontData::kRasterOriginX+symbol->left;
  const int sourceTop=UiFontData::kBaseline+symbol->top;
  const int64_t cellLeft=int64_t(x)-int64_t(UiFontData::kRasterOriginX)*scale/2;
  const int64_t cellTop=int64_t(y)-int64_t(UiFontData::kBaseline-UiFont::ascent(vietnamese))*scale/2;
  // Retain the approved full-cell sampling phase, scanning only visible ink.
  const int64_t top=std::max<int64_t>(0,std::max<int64_t>(clipTop,cellTop+(int64_t(sourceTop)*scale+1)/2));
  const int64_t bottom=std::min<int64_t>(height,std::min<int64_t>(clipBottom,cellTop+(int64_t(sourceTop+symbol->height)*scale+1)/2));
  const int64_t left=std::max<int64_t>(0,cellLeft+(int64_t(sourceLeft)*scale+1)/2);
  const int64_t right=std::min<int64_t>(width,cellLeft+(int64_t(sourceLeft+symbol->width)*scale+1)/2);
  for(int64_t py=top;py<bottom;++py) for(int64_t px=left;px<right;++px) {
    const unsigned alpha=UiFont::coverage(*symbol,int((px-cellLeft)*2/scale)-sourceLeft,
        int((py-cellTop)*2/scale)-sourceTop);
    if(alpha) pixel(frame,width,height,int(px),int(py),color,alpha);
  }
}
inline void text(uint16_t* frame,int width,int height,const char* start,const char* end,
                 int x,int y,int scale=2,uint16_t color=theme().text,int clipTop=44,int clipBottom=296,
                 bool forceVietnamese=false) {
  if(!frame || width<=0 || height<=0 || !start || !end || scale<=0) return;
  const bool vietnamese=forceVietnamese || usesVietnameseFont(start,end);
  int64_t cursor=int64_t(x)*128;uint32_t previous=0;
  const int64_t minCursor=int64_t(INT_MIN)*128,maxCursor=int64_t(INT_MAX)*128;
  while (start<end && *start) {
    const auto* symbol=UiFont::glyph(nextTextCodepoint(start,end));
    if(!symbol) continue;
    cursor=std::clamp(cursor+int64_t(UiFont::kerning64(previous,symbol->code))*scale,minCursor,maxCursor);
    const int64_t rounded=cursor>=0?(cursor+64)/128:-((-cursor+64)/128);
    textGlyph(frame,width,height,symbol->code,boundedTextCoordinate(rounded),y,scale,color,clipTop,clipBottom,vietnamese);
    cursor=std::clamp(cursor+int64_t(symbol->advance64)*scale,minCursor,maxCursor);
    previous=symbol->code;
  }
}
inline void text(uint16_t* frame,int width,int height,const char* value,int x,int y,
                 int scale=2,uint16_t color=theme().text,int clipTop=44,int clipBottom=296,
                 bool forceVietnamese=false) {
  if(value) text(frame,width,height,value,value+strlen(value),x,y,scale,color,clipTop,clipBottom,forceVietnamese);
}
inline void wrappedText(uint16_t* frame,int width,int height,const char* value,int x,int top,
                        int columns,int lineHeight,int scale,int clipTop,int clipBottom,int maxLines=4096,bool centered=false) {
  if(!value || columns<1 || scale<=0) return;
  const bool vietnamese=usesVietnameseFont(value);
  lineHeight=textLineHeight(value,lineHeight,scale);
  const int64_t glyphHeight=(int64_t(UiFont::height(vietnamese))*scale+1)/2;
  for(int line=0; *value && line<maxLines; ++line) {
    const auto part=wrapLine(value,columns);
    const int64_t y=int64_t(top)+int64_t(line)*lineHeight;
    if(y>=clipBottom) break;
    if(y+glyphHeight>clipTop && y>=INT_MIN && y<=INT_MAX) {
      int left=x;
      if(centered) {
        const int64_t measure=textWidth(value,part.end,scale);
        const int64_t centeredLeft=(int64_t(width)-measure)/2;
        left=centeredLeft<INT_MIN?INT_MIN:(centeredLeft>INT_MAX?INT_MAX:int(centeredLeft));
      }
      text(frame,width,height,value,part.end,left,int(y),scale,theme().text,clipTop,clipBottom,vietnamese);
    }
    value=part.next;
  }
}
inline void label(uint16_t* frame, int width, int height, const char* text, int top) {
  if(!frame || !text || width<=0 || height<=0) return;
  const bool preserveCase=usesVietnameseFont(text);
  uint32_t codes[64];int count=0,total64=0;uint32_t previous=0;
  int inkTop=UiFontData::kHeight,inkBottom=0;
  while(*text && count<64) {
    uint32_t code=nextTextCodepoint(text);
    if(!preserveCase) {
      if(code>='a' && code<='z') code-=32;
      else if(code>=0x430 && code<=0x44f) code-=32;
      else if(code==0x451) code=0x401;
    }
    const auto* symbol=UiFont::glyph(code);
    if(!symbol) continue;
    const int advance=symbol->advance64+UiFont::kerning64(previous,symbol->code);
    if(total64+advance>(theme().menu.width-24)*64) break;
    total64+=advance;codes[count++]=symbol->code;previous=symbol->code;
    if(symbol->height) {inkTop=std::min(inkTop,int(symbol->top));inkBottom=std::max(inkBottom,int(symbol->top+symbol->height));}
  }
  const int y=boundedTextCoordinate(int64_t(top)+(theme().menu.height-(inkBottom-inkTop))/2-inkTop-UiFontData::kCommonAscent);
  int cursor64=theme().menu.left*64+(theme().menu.width*64-total64)/2;previous=0;
  for(int index=0;index<count;++index) {
    const auto* symbol=UiFont::glyph(codes[index]);
    cursor64+=UiFont::kerning64(previous,codes[index]);
    textGlyph(frame,width,height,codes[index],(cursor64+32)/64,y,2,theme().text,kMenuVisibleTop,height,false);
    cursor64+=symbol->advance64;previous=codes[index];
  }
}
}

inline int menuHit(int x, int y, int offset) {
  if (y < kMenuVisibleTop) return -1;
  const int64_t local = int64_t(y)+offset-theme().menu.top;
  if (local < 0) return -1;
  const int64_t item = local/theme().menu.stride;
  return item < menuModuleCount() && Ui::roundedPixel(x-theme().menu.left,
      int(local%theme().menu.stride),theme().menu.width,theme().menu.height,theme().menu.radius) ? int(item) : -1;
}
inline bool downButtonHit(int x, int y, int offset) {
  const int64_t worldY = int64_t(y)+offset;
  return x >= theme().downX-6 && x < theme().downX+theme().downWidth+6 &&
         y >= kMenuVisibleTop && worldY >= theme().downY-6 && worldY < theme().downY+theme().downHeight+6;
}

// A swipe cancels activation permanently, even if the finger returns to its start.
class TapGesture {
 public:
  void begin(int x,int y,int target) {
    startX_=x; startY_=y; active_=true;
    target_=target;
  }
  void move(int x,int y) {
    const int64_t dx=int64_t(x)-startX_, dy=int64_t(y)-startY_;
    if (dx <= -6 || dx >= 6 || dy <= -4 || dy >= 4) cancel();
  }
  void cancel() { active_=false; target_=-1; }
  int release(int x,int y,int target) {
    move(x,y);
    const int result = active_ && target==target_ ? target_ : -1;
    cancel();
    return result;
  }
  int pressedTarget() const { return target_; }
 private:
  int startX_=0,startY_=0,target_=-1;
  bool active_=false;
};
class MenuGesture {
 public:
  void begin(int x,int y,int offset) { gesture_.begin(x,y,hit(x,y,offset)); }
  void move(int x,int y) { gesture_.move(x,y); }
  void cancel() { gesture_.cancel(); }
  int release(int x,int y,int offset) { return gesture_.release(x,y,hit(x,y,offset)); }
  int pressedItem() const { return gesture_.pressedTarget()>=0 ? gesture_.pressedTarget() : -1; }
  bool downPressed() const { return gesture_.pressedTarget()==-2; }
 private:
  TapGesture gesture_;
  static int hit(int x,int y,int offset) {
    const int item=menuHit(x,y,offset);
    return item>=0 ? item : (downButtonHit(x,y,offset) ? -2 : -1);
  }
};

inline void drawSceneMenu(uint16_t* frame, int width, int height, int offset,
                          int pressedItem=-1, bool downPressed=false) {
  using namespace Ui;
  if (!frame || width <= 0 || height <= 0) return;
  const int64_t buttonTop = int64_t(theme().downY)-offset;
  if (buttonTop+theme().downHeight > kMenuVisibleTop && buttonTop < height) {
    const int radius=theme().downHeight<22?theme().downHeight/2:11;
    box(frame,width,height,theme().downX,int(buttonTop),theme().downWidth,theme().downHeight,radius,downPressed,kMenuVisibleTop);
    for (int x=0; x<11; ++x) for (int t=0; t<2; ++t) {
      const int y=7+(theme().downHeight-kDownButtonHeight)/2+(x<=5 ? x : 10-x)+t;
      if (buttonTop+y >= kMenuVisibleTop)
        pixel(frame,width,height,theme().downX+(theme().downWidth-11)/2+x,int(buttonTop)+y,theme().text);
    }
  }
  for (int item=0; item<menuModuleCount(); ++item) {
    const int64_t top = int64_t(theme().menu.top)+item*theme().menu.stride-offset;
    if (top+theme().menu.height <= kMenuVisibleTop || top >= height) continue;
    box(frame,width,height,theme().menu.left,int(top),theme().menu.width,theme().menu.height,theme().menu.radius,item==pressedItem,kMenuVisibleTop);
    label(frame,width,height,MenuDetail::modules[item].label,int(top));
  }
}
}  // namespace Tamagotchi
