#pragma once

#include "weather.h"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>

namespace Tamagotchi::DailyWeather {

// The known GeoNames location already used by the spoken-weather fixtures.
// The daily page needs one forecast request, rather than geocoding on every refresh.
struct Config {
  Weather::WeatherLocation location{"Qui Nhon","VN",13.813708,109.19117};
  int32_t utcOffsetSeconds=7*3600;
};
enum class Status { WaitingForTime,WaitingForWifi,Waiting,Updating,Ready,Error };
struct Snapshot {
  Status status=Status::WaitingForTime;
  bool hasForecast=false,stale=false,refreshing=false;
  Weather::WeatherReply forecast{};
  char forecastDate[11]{},city[96]{},error[192]{};
  int64_t fetchedAt=0;
  double currentC=0,feelsC=0,minC=0,maxC=0,windKmh=0;
  int precipitationPercent=0,weatherCode=0;
};

inline bool validTime(int64_t epoch) { return epoch>=1704067200 && epoch<=4102444800LL; }
inline bool localDate(int64_t epoch,int32_t offset,char (&out)[11]) {
  out[0]=0;
  if(!validTime(epoch) || offset < -14*3600 || offset > 14*3600) return false;
  const time_t adjusted=time_t(epoch+offset);
  tm local{};
  if(!gmtime_r(&adjusted,&local)) return false;
  return std::strftime(out,sizeof out,"%Y-%m-%d",&local)==10;
}

// Only the worker owns this scheduler. Wall time picks the local date/noon;
// monotonic elapsed time controls retries, including millis() rollover.
class Scheduler {
 public:
  explicit Scheduler(int32_t offset=7*3600):offset_(offset) {}
  bool due(int64_t epoch,uint32_t now,bool trusted,bool online,bool allowed) const {
    if(!trusted || !validTime(epoch) || !online || !allowed || inFlight_) return false;
    if(newWindow(epoch)) return true;
    return retryPending_ && failures_<3 && uint32_t(now-failedAt_)>=retryWait_;
  }
  void started(int64_t epoch) {
    if(inFlight_ || !validTime(epoch)) return;
    if(newWindow(epoch)) failures_=0;
    attemptDay_=day(epoch);
    if(afterNoon(epoch)) noonDay_=attemptDay_;
    retryPending_=false;
    inFlight_=true;
  }
  void finished(bool success,uint32_t now,bool interrupted=false) {
    if(!inFlight_) return;
    inFlight_=false;
    failedAt_=now;
    if(success) { retryPending_=false; failures_=0; return; }
    if(interrupted) { retryPending_=true; retryWait_=1000; return; }
    ++failures_;
    retryPending_=failures_<3;
    retryWait_=failures_==1?60000:300000;
  }
  bool inFlight() const { return inFlight_; }
 private:
  int32_t offset_,attemptDay_=INT32_MIN,noonDay_=INT32_MIN;
  uint32_t failedAt_=0,retryWait_=0;
  unsigned failures_=0;
  bool inFlight_=false,retryPending_=false;
  int32_t day(int64_t epoch) const { return int32_t((epoch+offset_)/86400); }
  bool afterNoon(int64_t epoch) const { return (epoch+offset_)%86400>=43200; }
  bool newWindow(int64_t epoch) const {
    return attemptDay_!=day(epoch) || (afterNoon(epoch) && noonDay_!=day(epoch));
  }
};

inline bool validConfig(const Config& config,char* error,size_t capacity) {
  Weather::WeatherRequest request{};
  std::memcpy(request.city,config.location.name,sizeof request.city);
  std::memcpy(request.country,config.location.country,sizeof request.country);
  char country[3];
  if(!Weather::validateRequest(request,error,capacity) ||
     !Weather::countryCode(config.location.country,country,false))
    return Weather::fail(error,capacity,"Invalid forecast city.");
  if(!std::isfinite(config.location.latitude) || !std::isfinite(config.location.longitude) ||
     config.location.latitude < -90 || config.location.latitude > 90 ||
     config.location.longitude < -180 || config.location.longitude > 180 ||
     config.utcOffsetSeconds < -14*3600 || config.utcOffsetSeconds > 14*3600)
    return Weather::fail(error,capacity,"Invalid location or time zone.");
  return true;
}

inline bool parseForecast(JsonVariantConst document,const Config& config,int64_t now,
                          Snapshot& out,char* error,size_t capacity) {
  out=Snapshot{};
  if(error && capacity) error[0]=0;
  if(!validConfig(config,error,capacity) ||
     !Weather::validateForecastTime(document,now,error,capacity)) return false;
  char today[11];
  const char* timestamp=document["current"]["time"].as<const char*>();
  double latitude,longitude,offset;
  if(!localDate(now,config.utcOffsetSeconds,today) || !timestamp ||
     std::strncmp(timestamp,today,10) ||
     !Weather::number(document["utc_offset_seconds"],-50400,50400,offset) ||
     offset!=config.utcOffsetSeconds ||
     !Weather::number(document["latitude"],-90,90,latitude) ||
     !Weather::number(document["longitude"],-180,180,longitude) ||
     std::fabs(latitude-config.location.latitude)>0.5 ||
     std::fabs(longitude-config.location.longitude)>0.5)
    return Weather::fail(error,capacity,"The forecast does not match today's date or city.");
  Weather::WeatherRequest request{};
  std::memcpy(request.city,config.location.name,sizeof request.city);
  std::memcpy(request.country,config.location.country,sizeof request.country);
  std::strcpy(request.targetDate,today);
  if(!Weather::formatForecast(document,request,config.location,out.forecast,error,capacity)) return false;
  // formatForecast has validated all values, units and daily row dates above.
  // These fields let the small screen present the provider's values compactly.
  out.currentC=document["current"]["temperature_2m"].as<double>();
  out.feelsC=document["current"]["apparent_temperature"].as<double>();
  out.windKmh=document["current"]["wind_speed_10m"].as<double>();
  out.weatherCode=document["current"]["weather_code"].as<int>();
  out.minC=document["daily"]["temperature_2m_min"][0].as<double>();
  out.maxC=document["daily"]["temperature_2m_max"][0].as<double>();
  out.precipitationPercent=int(std::lround(document["daily"]["precipitation_probability_max"][0].as<double>()));
  out.status=Status::Ready;
  out.hasForecast=true;
  out.fetchedAt=now;
  std::strcpy(out.forecastDate,today);
  std::strcpy(out.city,config.location.name);
  return true;
}

inline void refreshStatus(Snapshot& value,int64_t now,bool trusted,bool online,bool allowed,
                          bool inFlight,int32_t offset=7*3600) {
  char today[11];
  value.stale=value.hasForecast && (!trusted || !localDate(now,offset,today) ||
      std::strcmp(today,value.forecastDate));
  value.refreshing=inFlight;
  if(!trusted || !validTime(now)) value.status=Status::WaitingForTime;
  else if(!online) value.status=Status::WaitingForWifi;
  else if(inFlight) value.status=Status::Updating;
  else if(value.error[0]) value.status=Status::Error;
  else if(value.hasForecast) value.status=Status::Ready;
  else value.status=Status::Waiting;
  (void)allowed; // Pausing background work does not invalidate an existing forecast.
}

} // namespace Tamagotchi::DailyWeather

#ifdef ARDUINO
#include <Arduino.h>
#include <WiFiMulti.h> // Resolve the ESP32 library without matching local wifi.h on macOS.
#include <atomic>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

namespace Tamagotchi::DailyWeather {
namespace Detail {
inline Config config;
inline Snapshot state;
inline SemaphoreHandle_t lock=nullptr;
inline TaskHandle_t worker=nullptr;
inline std::atomic<bool> allowed{false},trusted{false};
inline std::atomic<bool> powerIdle{false};
inline std::atomic<uint32_t> changed{0};
inline bool interrupted=false; // Only the weather worker calls the HTTP callback.
inline Https::PsramJsonAllocator allocator;

inline bool keepRunning() {
  const bool keep=allowed.load(std::memory_order_acquire) && trusted.load(std::memory_order_acquire) &&
      !NetworkGate::voiceBusy();
  if(!keep) interrupted=true;
  return keep;
}
inline void status(int64_t now,bool online,bool inFlight) {
  if(!lock || xSemaphoreTake(lock,0)!=pdTRUE) return;
  const Status before=state.status;
  const bool stale=state.stale,refreshing=state.refreshing;
  refreshStatus(state,now,trusted.load(),online,allowed.load(),inFlight,config.utcOffsetSeconds);
  if(before!=state.status || stale!=state.stale || refreshing!=state.refreshing) ++changed;
  xSemaphoreGive(lock);
}
inline bool fetch(Snapshot& out,char* error,size_t capacity) {
  char url[768];
  if(!Weather::makeForecastUrl(config.location,url,sizeof url,error,capacity,false)) return false;
  JsonDocument document(&allocator),filter(&allocator);
  for(const char* key:{"error","timezone","utc_offset_seconds","latitude","longitude"}) filter[key]=true;
  for(const char* key:{"time","temperature_2m","apparent_temperature","weather_code","wind_speed_10m"}) {
    filter["current"][key]=true; filter["current_units"][key]=true;
  }
  for(const char* key:{"time","weather_code","temperature_2m_min","temperature_2m_max","precipitation_probability_max"}) {
    filter["daily"][key]=true; filter["daily_units"][key]=true;
  }
  if(filter.overflowed()) return Weather::fail(error,capacity,"Not enough memory for the forecast.");
  return Http::getPublicForecastJson(url,document,filter,error,capacity,NetworkGate::Priority::Background,20000,keepRunning) &&
      keepRunning() && parseForecast(document.as<JsonVariantConst>(),config,int64_t(std::time(nullptr)),out,error,capacity);
}
inline void task(void*) {
  Scheduler schedule(config.utcOffsetSeconds);
  Snapshot result;
  char error[192];
  for(;;) {
    const int64_t now=int64_t(std::time(nullptr));
    const bool online=WiFi.status()==WL_CONNECTED;
    status(now,online,schedule.inFlight());
    if(schedule.due(now,millis(),trusted.load(),online,allowed.load()) && !NetworkGate::voiceBusy()) {
      // Taking a background lease never waits. A busy network leaves this refresh
      // pending without consuming an attempt; TLS and voice never overlap.
      NetworkGate::Lease lease(NetworkGate::Priority::Background,0);
      if(lease && keepRunning()) {
        schedule.started(now);
        status(now,online,true);
        interrupted=false; error[0]=0;
        const bool ok=fetch(result,error,sizeof error);
        // Voice may queue between the outer lease and the HTTP client's nested
        // lease. In that case transport never starts and its callback is not run.
        if(!ok) keepRunning();
        schedule.finished(ok,millis(),interrupted);
        // No network operation or JSON parsing occurs while the snapshot is locked.
        if(xSemaphoreTake(lock,portMAX_DELAY)==pdTRUE) {
          if(ok) state=result;
          else if(!interrupted) std::snprintf(state.error,sizeof state.error,"%s",error[0]?error:"Could not refresh the forecast.");
          refreshStatus(state,int64_t(std::time(nullptr)),trusted.load(),WiFi.status()==WL_CONNECTED,
                        allowed.load(),false,config.utcOffsetSeconds);
          ++changed;
          xSemaphoreGive(lock);
        }
      }
    }
    // A dark screen defers weather altogether. Wake explicitly when the UI,
    // clock or permission changes rather than checking those flags every second.
    ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(powerIdle.load()?60000:200));
  }
}
} // namespace Detail

inline bool begin(const Config& config=Config{}) {
  if(Detail::worker) return true;
  char error[192];
  if(!validConfig(config,error,sizeof error)) return false;
  if(!Detail::lock) Detail::lock=xSemaphoreCreateMutex();
  if(!Detail::lock) return false;
  Detail::config=config;
  Detail::state=Snapshot{};
  std::strcpy(Detail::state.city,config.location.name);
  ++Detail::changed;
  if(xTaskCreatePinnedToCore(Detail::task,"daily-weather",12288,nullptr,1,&Detail::worker,0)!=pdPASS) {
    Detail::worker=nullptr;
    Detail::state.status=Status::Error;
    std::strcpy(Detail::state.error,"Could not start the forecast update.");
    ++Detail::changed;
    return false;
  }
  return true;
}
inline void update(bool allowNetwork,bool clockTrusted,bool screenOff=false) {
  const bool changedAllowed=Detail::allowed.exchange(allowNetwork,std::memory_order_acq_rel)!=allowNetwork;
  const bool changedTrusted=Detail::trusted.exchange(clockTrusted,std::memory_order_acq_rel)!=clockTrusted;
  const bool changedIdle=Detail::powerIdle.exchange(screenOff,std::memory_order_acq_rel)!=screenOff;
  if(Detail::worker && (changedAllowed || changedTrusted || changedIdle)) xTaskNotifyGive(Detail::worker);
}
inline bool snapshot(Snapshot& out) {
  if(!Detail::lock || xSemaphoreTake(Detail::lock,0)!=pdTRUE) return false;
  out=Detail::state;
  xSemaphoreGive(Detail::lock);
  return true;
}
inline uint32_t revision() { return Detail::changed.load(); }
} // namespace Tamagotchi::DailyWeather
#endif
