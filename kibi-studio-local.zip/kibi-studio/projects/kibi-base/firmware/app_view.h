#pragma once
#include "app_core.h"
#include "kibi_typography.h"
#include <algorithm>
#include <cstdio>

// Native RGB565, Source Sans 3 AA4. This renderer is compiled unchanged for the
// actual display and for Studio; there is no browser reconstruction of the UI.
namespace KibiApp::View {
using namespace KibiTypography;
inline constexpr int kWidth=240,kHeight=296;
inline constexpr uint16_t rgb(unsigned r,unsigned g,unsigned b){return uint16_t(((r>>3)<<11)|((g>>2)<<5)|(b>>3));}
inline constexpr uint16_t kBackground=rgb(15,15,15),kText=rgb(245,245,245),kMuted=rgb(163,163,163),kRule=rgb(58,58,58),kSurface=rgb(27,27,27);
struct Context {uint32_t nowMs=100;bool online=true,loading=false,stale=false;};
inline void pixel(Framebuffer frame,int x,int y,uint16_t color){if(x>=0&&x<kWidth&&y>=0&&y<kHeight)frame.pixels[y*frame.stride+x]=color;}
inline void box(Framebuffer frame,int x,int y,int width,int height,uint16_t color){for(int row=std::max(0,y);row<std::min(kHeight,y+height);++row)for(int col=std::max(0,x);col<std::min(kWidth,x+width);++col)pixel(frame,col,row,color);}
inline void rounded(Framebuffer frame,int x,int y,int width,int height,int radius,uint16_t color){
 for(int row=0;row<height;++row)for(int col=0;col<width;++col){const int cx=col<radius?radius-1:col>=width-radius?width-radius:col,cy=row<radius?radius-1:row>=height-radius?height-radius:row;const int dx=col-cx,dy=row-cy;if(dx*dx+dy*dy<=radius*radius)pixel(frame,x+col,y+row,color);}
}
inline void text(Framebuffer frame,Font font,const char* value,int x,int inkTop,uint16_t color){const auto& face=getFace(font);const auto metrics=measure(face,value);draw(frame,face,value,x-std::min(0,metrics.ink.x),inkTop-metrics.ink.y,color,{0,0,kWidth,kHeight});}
inline void center(Framebuffer frame,Font font,const char* value,int inkTop,uint16_t color){text(frame,font,value,(kWidth-width(getFace(font),value))/2,inkTop,color);}
inline void rule(Framebuffer frame,int y){box(frame,24,y,192,1,kRule);}
inline void arrow(Framebuffer frame,int x,int y,uint16_t color){for(int i=0;i<5;++i){box(frame,x+i,y+i,2,2,color);box(frame,x+i,y+8-i,2,2,color);}}
inline void button(Framebuffer frame,Layout::Rect rect,const char* label){rounded(frame,rect.x,rect.y,rect.width,rect.height,11,kText);center(frame,Font::Body18,label,rect.y+14,kBackground);}
inline void header(Framebuffer frame,const char* title,const char* index){text(frame,Font::Header20,title,32,30,kText);const int w=width(getFace(Font::Body18),index);text(frame,Font::Body18,index,208-w,33,kMuted);}
inline void dots(Framebuffer frame,uint8_t screen){for(int i=0;i<3;++i)rounded(frame,105+i*13,276,5,5,2,i==screen?kText:kRule);}
inline const char* scenarioLabel(const Context& context){if(context.loading)return "Загрузка…";if(!context.online)return "Офлайн-режим";if(context.stale)return "Нет свежих данных";return nullptr;}
inline void footer(Framebuffer frame,const Context& context,const char* defaultText){center(frame,Font::Body18,scenarioLabel(context)?scenarioLabel(context):defaultText,247,kMuted);}
inline void home(Framebuffer frame,const Context& context){
 header(frame,"КИБИ","01 / 03");
 text(frame,Font::Header20,"Твоя идея.",24,74,kText);text(frame,Font::Header20,"Твой Киби.",24,101,kText);
 text(frame,Font::Body18,"Готовая основа",24,141,kMuted);text(frame,Font::Body18,"для приложения",24,164,kMuted);
 button(frame,Layout::homeModules,"Открыть модули");footer(frame,context,"Свайп / + −");
}
inline void modules(Framebuffer frame,const Context& context){
 header(frame,"Модули","02 / 03");text(frame,Font::Body18,"Заготовки для идей",24,70,kMuted);
 rounded(frame,24,100,192,62,10,kSurface);text(frame,Font::Medium20,"Интерфейс",36,113,kText);text(frame,Font::Body18,"Живой пример",36,139,kMuted);arrow(frame,199,125,kText);
 rule(frame,180);text(frame,Font::Medium20,"Новый модуль",32,194,kMuted);text(frame,Font::Body18,"Место для твоего кода",32,221,kMuted);
 footer(frame,context,"");
}
inline void module(Framebuffer frame,const Context& context){
 header(frame,"Интерфейс","ДЕМО");
 text(frame,Font::Body18,"Пример модуля",24,81,kMuted);text(frame,Font::Header20,"Здесь появится",24,120,kText);text(frame,Font::Header20,"твоя логика.",24,148,kText);
 text(frame,Font::Body18,"Без внешних данных",24,192,kMuted);text(frame,Font::Body18,"и подключённых услуг",24,215,kMuted);
 button(frame,Layout::moduleBack,"Назад");
 if(scenarioLabel(context)){box(frame,24,75,192,24,kBackground);center(frame,Font::Body18,scenarioLabel(context),81,kMuted);}
}
inline void settings(Framebuffer frame,const Model& model,const Context& context){
 header(frame,"Настройки","03 / 03");text(frame,Font::Body18,"Пример состояния",24,73,kMuted);
 rule(frame,101);text(frame,Font::Body18,"Функция",32,121,kText);text(frame,Font::Body18,model.enabled?"Включено":"Выключено",32,151,kMuted);
 rounded(frame,164,116,44,25,12,model.enabled?kText:kRule);rounded(frame,model.enabled?186:168,120,17,17,8,model.enabled?kBackground:kText);rule(frame,181);
 text(frame,Font::Body18,"Меняет только",24,197,kMuted);text(frame,Font::Body18,"состояние примера",24,220,kMuted);footer(frame,context,"Связь не требуется");
}
inline void render(uint16_t* pixels,size_t count,const Model& model,const Context& context){
 if(!pixels||count<size_t(kWidth*kHeight))return;
 Framebuffer frame{pixels,count,kWidth,kHeight,kWidth};std::fill(pixels,pixels+kWidth*kHeight,kBackground);
 if(model.moduleOpen&&model.screenIndex==1)module(frame,context);else{if(model.screenIndex==1)modules(frame,context);else if(model.screenIndex==2)settings(frame,model,context);else home(frame,context);dots(frame,model.screenIndex);}
}
} // namespace KibiApp::View
