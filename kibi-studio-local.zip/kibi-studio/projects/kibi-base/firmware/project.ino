/* KIBI_CONFIG
{"schemaVersion":1,"inputs":[{"id":"wifi_ssid","label":"Название Wi-Fi (необязательно)","type":"text","required":false,"maxLength":32},{"id":"wifi_password","label":"Пароль Wi-Fi","type":"password","required":false,"maxLength":64},{"id":"service_api_key","label":"Ключ API (если нужен проекту)","type":"password","required":false,"maxLength":512},{"id":"service_api_base_url","label":"HTTPS-адрес API (если нужен проекту)","type":"text","required":false,"maxLength":512}]}
*/
#if __has_include("kibi_project_config.h")
#include "kibi_project_config.h"
#else
#define KIBI_WIFI_SSID ""
#define KIBI_WIFI_PASSWORD ""
#define KIBI_SERVICE_API_KEY ""
#define KIBI_SERVICE_API_BASE_URL ""
#endif
#define KIBI_PROJECT_CONFIG 1
#include "Feature.h"

SET_LOOP_TASK_STACK_SIZE(12 * 1024);
void setup(){Serial.begin(115200);Serial.setTxTimeoutMs(0);KibiFeature::begin();}
void loop(){KibiFeature::tick(millis());}
