#pragma once

// Protected stock-hardware adapter. Edit app_core/view/feature.h for application
// behavior; retain the proven power, touch, wake and audio-standby lifecycle.

#include "display_touch.h"
#include "state_info.h"
#include "power.h"
#include "power_ui.h"
#include "power_runtime.h"
#include "power_management.h"
#include "microphone_i2s.h"
#include "audio_codec_power.h"
#include "app_core.h"
#include "app_view.h"
#include "app_feature.h"

#ifdef ARDUINO
namespace KibiFeature {
using namespace KibiApp;

class Button {
 public:
  bool update(bool down,uint32_t now) {
    if(!initialized_) {initialized_=true;raw_=stable_=down;changed_=now;return false;}
    if(raw_!=down) {raw_=down;changed_=now;}
    if(stable_==raw_ || uint32_t(now-changed_)<35) return false;
    stable_=raw_;return stable_;
  }
 private:
  bool initialized_=false,raw_=false,stable_=false;
  uint32_t changed_=0;
};
struct Runtime {
  Model model;
  View::Context view;
  Button plus,minus;
  Tamagotchi::Power::Controller power;
  Tamagotchi::Power::View powerView{Tamagotchi::Power::Stage::Active,100,true};
  Tamagotchi::PowerUi::Settings powerSettings;
  uint32_t bootAt=0,frameAt=0,diagnosticsAt=0;
  bool initialized=false,ready=false,dirty=true,touchDown=false;
  int touchTarget=-1,touchX=0,touchY=0;
  uint32_t touchAt=0;
};
inline Runtime runtime;
inline TaskHandle_t inputTask=nullptr;
inline std::atomic<bool> wakePending{false};
struct WakeSource {int pin;Tamagotchi::PowerManagement::WakeLatch latch;};
inline WakeSource plusWake{Tamagotchi::Board::kPlus,{}},minusWake{Tamagotchi::Board::kMinus,{}};
inline void ARDUINO_ISR_ATTR wakeInput(void* argument) {
  auto& source=*static_cast<WakeSource*>(argument);
  gpio_intr_disable(gpio_num_t(source.pin));source.latch.fired();
  wakePending.store(true,std::memory_order_relaxed);
  BaseType_t higher=pdFALSE;
  if(inputTask) vTaskNotifyGiveFromISR(inputTask,&higher);
  if(higher==pdTRUE) portYIELD_FROM_ISR();
}

// Reuse the original codec/I2S lifecycle before the shared touch task starts,
// then leave audio in standby. This application does not start audio capture.
struct CodecBus {
  bool present(uint8_t address) {Wire.beginTransmission(address);return Wire.endTransmission()==0;}
  bool write(uint8_t address,uint8_t reg,uint8_t value) {
    Wire.beginTransmission(address);Wire.write(reg);Wire.write(value);
    return Wire.endTransmission()==0;
  }
};
inline bool initializeAudioStandby() {
  Tamagotchi::MicrophoneI2s::StandardDriver driver;
  Tamagotchi::MicrophoneI2s::Capture capture(driver);
  CodecBus bus;
  Tamagotchi::MicrophonePower::Codecs codecs(bus);
  Tamagotchi::MicrophonePower::Lifecycle lifecycle(capture,codecs);
  const auto dac=codecs.suspendUnusedDac();
  bool clean=false;
  Tamagotchi::MicrophonePower::StandbyScope cleanup(lifecycle,[&](bool okay){clean=okay;});
  const auto result=lifecycle.wake([]{return millis();},[](uint32_t ms){delay(ms);},[]{return false;},millis());
  cleanup.close();
  Serial.printf("[KIBI-AUDIO] boot=%u standby=%u unused_dac=%u\n",unsigned(result),unsigned(clean),unsigned(dac));
  return result==Tamagotchi::MicrophonePower::WakeStatus::Ready && clean;
}
inline void loadPower() {
  auto& state=runtime;Preferences preferences;
  if(preferences.begin("kibi_power",true)) {
    Tamagotchi::PowerUi::decode(preferences.getUInt("settings",0),state.powerSettings);
    preferences.end();
  }
  state.power.begin(state.powerSettings.rational?Tamagotchi::Power::Mode::Rational:Tamagotchi::Power::Mode::Normal,millis());
  state.power.setBrightness(state.powerSettings.brightness);
  state.power.setGlance(state.powerSettings.glance);
  Tamagotchi::setDisplayBrightnessPercent(state.powerSettings.brightness);
}
inline void drawFrame() {
  auto& state=runtime;
  if(!state.ready || !state.powerView.screenOn || !Tamagotchi::displayReadyToPresent()) return;
  uint16_t* frame=Tamagotchi::prepareDisplayFrame(0);
  if(!frame) return;
  View::render(frame,Tamagotchi::kFrameBytes/sizeof(uint16_t),state.model,state.view);
  Tamagotchi::presentDisplayFrame();state.frameAt=millis();state.dirty=false;
}
inline void action(const Input& event,uint32_t now) {
  auto& state=runtime;state.power.activity(now);
  const Action result=reduceInput(state.model,event);
  KibiApp::Feature::input(state.model,event,result);
  if(result!=Action::None)state.dirty=true;
}
inline void input(uint32_t now) {
  using namespace Tamagotchi;
  auto& state=runtime;
  const bool plusDown=digitalRead(Board::kPlus)==LOW,minusDown=digitalRead(Board::kMinus)==LOW;
  if(plusWake.latch.rearm(!plusDown)) gpio_intr_enable(gpio_num_t(Board::kPlus));
  if(minusWake.latch.rearm(!minusDown)) gpio_intr_enable(gpio_num_t(Board::kMinus));
  const bool woke=wakePending.exchange(false,std::memory_order_relaxed);
  if(plusDown || minusDown || woke) state.power.activity(now);
  if(state.plus.update(plusDown,now)) action(Input{InputKind::Plus},now);
  if(state.minus.update(minusDown,now)) action(Input{InputKind::Minus},now);
  DisplayTouchDetail::TouchEvent event;
  // The stock driver's event queue is bounded at 32 items.
  for(int count=0;count<32 && nextTouchEvent(event);++count) {
    using Kind=DisplayTouchDetail::TouchKind;
    if(event.kind!=Kind::Cancel) state.power.activity(now);
    const int x=event.point.x,y=event.point.y;
    if(event.kind==Kind::Down) {
      state.touchDown=true;state.touchX=x;state.touchY=y;state.touchAt=event.at;
      state.touchTarget=int(hitTarget(state.model,x,y));
    } else if(event.kind==Kind::Move) {
      if(std::abs(x-state.touchX)>10 || std::abs(y-state.touchY)>10) state.touchTarget=-1;
    } else if(event.kind==Kind::Up) {
      const int target=state.touchTarget;
      if(state.touchDown) {
        Input gesture{InputKind::Swipe,x,y,x-state.touchX,y-state.touchY,uint32_t(event.at-state.touchAt)};
        if(std::abs(gesture.dx)<=10 && std::abs(gesture.dy)<=10 && target>=0 && target==int(hitTarget(state.model,x,y)))gesture.kind=InputKind::Tap;
        action(gesture,now);
      }
      state.touchDown=false;state.touchTarget=-1;
    } else {state.touchDown=false;state.touchTarget=-1;}
    state.dirty=true;
  }
}
inline void power(uint32_t now) {
  using namespace Tamagotchi;auto& state=runtime;
  const auto& info=StateInfoDetail::runtime.info;
  const bool external=PowerRuntime::confirmedExternalPower(info.chargingKnown && info.charging);
  const auto next=state.power.update(now,external || state.powerSettings.alwaysScreen,state.touchDown,info.batteryPercent);
  if(next.screenOn) PowerManagement::setInteractive(true);
  if(next.stage!=state.powerView.stage || next.brightness!=state.powerView.brightness) state.dirty=true;
  if(state.powerView.screenOn && !next.screenOn) {
    state.touchDown=false;state.touchTarget=-1;
    discardDisplayTouchEvents();
  }
  setDisplayBrightnessPercent(next.brightness);setDisplayAwake(next.screenOn);state.powerView=next;
  if(tickDisplayPower(now)) state.dirty=true;
  if(!next.screenOn) PowerManagement::setInteractive(false);
  // Application ticks must not keep a sleeping screen lit forever.
  PowerRuntime::update(state.powerSettings.rational,next.screenOn,false);
}
inline void diagnostics(uint32_t now) {
  if(uint32_t(now-runtime.diagnosticsAt)<60000) return;
  runtime.diagnosticsAt=now;
  constexpr uint32_t internal=MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT;
  constexpr uint32_t psram=MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT;
  Serial.printf("[KIBI-MEM] internal_free=%u internal_largest=%u internal_min=%u psram_free=%u psram_min=%u loop_stack=%u\n",
      unsigned(heap_caps_get_free_size(internal)),unsigned(heap_caps_get_largest_free_block(internal)),
      unsigned(heap_caps_get_minimum_free_size(internal)),unsigned(heap_caps_get_free_size(psram)),
      unsigned(heap_caps_get_minimum_free_size(psram)),unsigned(uxTaskGetStackHighWaterMark(nullptr)));
}
inline bool begin() {
  using namespace Tamagotchi;auto& state=runtime;
  if(state.initialized) return state.ready;
  state.initialized=true;state.bootAt=millis();
  // The base app has no network requirement and displays no invented telemetry.
  state.view.nowMs=state.bootAt;state.view.online=true;KibiApp::Feature::begin(state.model,state.view);
  PowerManagement::begin();loadPower();
  // Never format, reset owner data, change partitions, or erase NVS.
  LittleFS.begin(false);
  if(!beginDisplay()) {Serial.println("[KIBI] Display initialization failed");return false;}
  state.ready=true;drawFrame();
  beginStateInfo();beginInputBus();initializeAudioStandby();
  pinMode(Board::kPlus,INPUT_PULLUP);pinMode(Board::kMinus,INPUT_PULLUP);
  state.plus.update(digitalRead(Board::kPlus)==LOW,millis());
  state.minus.update(digitalRead(Board::kMinus)==LOW,millis());
  inputTask=xTaskGetCurrentTaskHandle();
  attachInterruptArg(digitalPinToInterrupt(Board::kPlus),wakeInput,&plusWake,ONLOW);
  attachInterruptArg(digitalPinToInterrupt(Board::kMinus),wakeInput,&minusWake,ONLOW);
  PowerManagement::armWakeSources();beginTouch();
  state.dirty=true;Serial.println("[KIBI] Native Source Sans 3 application base; local state and shared input");
  return true;
}
inline void tick(uint32_t now) {
  using namespace Tamagotchi;auto& state=runtime;
  if(!state.ready) {delay(20);return;}
  input(now);updateStateInfo(false,!state.powerView.screenOn);
  state.view.nowMs=now;
  if(KibiApp::tick(state.model,now))state.dirty=true;
  if(KibiApp::Feature::tick(state.model,state.view,now))state.dirty=true;
  power(now);
  if(uint32_t(now-state.frameAt)>=1000u)state.dirty=true;
  if(state.dirty) drawFrame();diagnostics(now);
  if(state.powerView.screenOn) delay(1);
  else ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(PowerManagement::idlePauseMs(false,StateInfoDetail::runtime.sampling)));
}
} // namespace KibiFeature
#endif
