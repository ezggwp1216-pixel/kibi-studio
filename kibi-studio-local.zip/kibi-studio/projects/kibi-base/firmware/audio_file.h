#pragma once
#include "config.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#ifdef ARDUINO
#include <esp_heap_caps.h>
#endif

namespace Tamagotchi {
// Large text lives in PSRAM on the device. Never fall back to internal DRAM.
class BoundedText {
 public:
  BoundedText()=default;
  BoundedText(const BoundedText&)=delete;
  BoundedText& operator=(const BoundedText&)=delete;
  ~BoundedText() { free(data_); }
  bool reserve(size_t capacity) {
    if(data_) return capacity<=capacity_;
#ifdef ARDUINO
    data_=static_cast<char*>(heap_caps_malloc(capacity,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
#else
    data_=static_cast<char*>(malloc(capacity));
#endif
    if(!data_) return false;
    capacity_=capacity; data_[0]=0; return true;
  }
  char* data() { return data_; }
  const char* data() const { return data_?data_:""; }
  size_t capacity() const { return capacity_; }
 private:
  char* data_=nullptr;
  size_t capacity_=0;
};
inline void makeWavHeader(uint8_t (&out)[44],uint32_t dataBytes,uint32_t rate) {
  memset(out,0,sizeof out);
  auto number=[&](int at,uint32_t value,int bytes) { for(int i=0;i<bytes;++i) out[at+i]=uint8_t(value>>(8*i)); };
  memcpy(out,"RIFF",4); number(4,dataBytes+36,4); memcpy(out+8,"WAVEfmt ",8);
  number(16,16,4); number(20,1,2); number(22,1,2); number(24,rate,4);
  number(28,rate*2,4); number(32,2,2); number(34,16,2);
  memcpy(out+36,"data",4); number(40,dataBytes,4);
}
namespace AudioFile {
inline constexpr char kPendingPath[]="/littlefs/audio/pending.wav";
inline constexpr size_t kMaximumSamples=size_t(kAudioSampleRate)*kAudioMaxSeconds;
inline size_t pendingBytes(const char* path=kPendingPath) {
  struct stat info{};
  if(stat(path,&info) || !S_ISREG(info.st_mode) || info.st_size<46 || uint64_t(info.st_size)>44+2*kMaximumSamples || (info.st_size-44)%2) return 0;
  FILE* file=fopen(path,"rb"); if(!file) return 0;
  uint8_t actual[44],expected[44]; const size_t read=fread(actual,1,sizeof actual,file); fclose(file);
  makeWavHeader(expected,uint32_t(info.st_size-44),kAudioSampleRate);
  return read==sizeof actual && !memcmp(actual,expected,sizeof actual) ? size_t(info.st_size) : 0;
}
enum class PendingStatus { Missing,Empty,Ready,Unrecognized,Error };
inline bool sidecarPath(const char* path,const char* suffix,char (&out)[256]) {
  if(!path || !suffix) return false;
  const int bytes=snprintf(out,sizeof out,"%s%s",path,suffix);
  return bytes>0 && size_t(bytes)<sizeof out;
}
inline bool consumedMarker(const char* marker) {
  FILE* file=fopen(marker,"rb"); if(!file) return false;
  char contents[8]; const size_t read=fread(contents,1,sizeof contents,file);
  const bool good=read==sizeof contents && !memcmp(contents,"saved-v1",8) && fgetc(file)==EOF && !ferror(file);
  fclose(file); return good;
}
// A saved marker is published only after App has safely stored/displayed text.
// Keeping it until unlink succeeds prevents a failed cleanup from re-sending
// an already consumed recording after a restart.
inline bool markConsumed(const char* path=kPendingPath) {
  char marker[256],temporary[256];
  if(!sidecarPath(path,".saved",marker) || !sidecarPath(path,".saved.tmp",temporary)) return false;
  struct stat info{};
  if(stat(marker,&info)==0) return S_ISREG(info.st_mode) && consumedMarker(marker);
  if(errno!=ENOENT) return false;
  FILE* file=fopen(temporary,"wb"); if(!file) return false;
  const bool wrote=fwrite("saved-v1",1,8,file)==8;
  const bool flushed=fflush(file)==0;
  const bool synced=flushed && fsync(fileno(file))==0;
  const bool closed=fclose(file)==0;
  if(!wrote || !synced || !closed || rename(temporary,marker)!=0) { remove(temporary); return false; }
  return true;
}
inline PendingStatus recoverPending(const char* path=kPendingPath) {
  char marker[256]; if(!sidecarPath(path,".saved",marker)) return PendingStatus::Error;
  struct stat info{};
  if(stat(marker,&info)==0) {
    if(!S_ISREG(info.st_mode) || !consumedMarker(marker)) return PendingStatus::Error;
    if(remove(path)!=0 && errno!=ENOENT) return PendingStatus::Error;
    if(remove(marker)!=0 && errno!=ENOENT) return PendingStatus::Error;
    return PendingStatus::Missing;
  }
  if(errno!=ENOENT) return PendingStatus::Error;
  if(stat(path,&info)!=0) return errno==ENOENT?PendingStatus::Missing:PendingStatus::Error;
  if(!S_ISREG(info.st_mode) || info.st_size<44 || uint64_t(info.st_size)>44+2*kMaximumSamples) return PendingStatus::Unrecognized;
  FILE* file=fopen(path,"r+b"); if(!file) return PendingStatus::Error;
  uint8_t actual[44],expected[44];
  if(fread(actual,1,sizeof actual,file)!=sizeof actual) { fclose(file); return PendingStatus::Error; }
  makeWavHeader(expected,0,kAudioSampleRate);
  for(size_t i=0;i<sizeof actual;++i) {
    if((i>=4 && i<8) || i>=40) continue;
    if(actual[i]!=expected[i]) { fclose(file); return PendingStatus::Unrecognized; }
  }
  // Stdio/FS can leave the last PCM sample incomplete. Retain every complete
  // sample, never interpret unrelated data as a WAV or exceed the 300s bound.
  const uint32_t dataBytes=uint32_t(info.st_size-44)&~uint32_t(1);
  makeWavHeader(expected,dataBytes,kAudioSampleRate);
  const bool trim=uint64_t(info.st_size)!=44+uint64_t(dataBytes);
  const bool patch=memcmp(actual,expected,sizeof actual)!=0;
  bool repaired=true;
  if(trim) repaired=ftruncate(fileno(file),44+dataBytes)==0;
  if(repaired && patch) repaired=fseek(file,0,SEEK_SET)==0 && fwrite(expected,1,sizeof expected,file)==sizeof expected;
  if(repaired && (trim || patch)) repaired=fflush(file)==0 && fsync(fileno(file))==0;
  const bool closed=fclose(file)==0;
  if(!repaired || !closed) return PendingStatus::Error;
  return dataBytes?PendingStatus::Ready:PendingStatus::Empty;
}
inline bool acknowledgeSaved(const char* path=kPendingPath) {
  // Voice capture is single use: neither a failed request nor reboot can
  // revive its PCM or attach its old job/reminder identity to a new capture.
  // Restrict cleanup to files owned by this recording; keep notes and assets.
  bool removed=true;
  constexpr const char* suffixes[]={"",".cloud",".cloud.tmp",".reminder",".reminder.part",".saved",".saved.tmp"};
  for(const char* suffix:suffixes) {
    char file[256];
    if(!sidecarPath(path,suffix,file) || (unlink(file)!=0 && errno!=ENOENT)) removed=false;
  }
  return removed;
}
class Recorder {
 public:
  ~Recorder() { if(file_) finish(); }
  bool begin(const char* path=kPendingPath) {
    if(file_ || !path || strnlen(path,sizeof path_)>=sizeof path_) return false;
    const auto previous=recoverPending(path);
    if(previous!=PendingStatus::Missing && previous!=PendingStatus::Empty) return false;
    // A reminder claim belongs to the previous WAV and must never be inherited
    // by a new recording, even if the PCM content happens to be identical.
    char claim[256];
    if(!sidecarPath(path,".reminder",claim) || (remove(claim)!=0 && errno!=ENOENT)) return false;
    strcpy(path_,path);
    file_=fopen(path,"wb"); samples_=lastSynced_=0;
    if(!file_) return false;
    uint8_t header[44]; makeWavHeader(header,0,kAudioSampleRate);
    good_=fwrite(header,1,sizeof header,file_)==sizeof header && checkpoint();
    return good_;
  }
  bool append(const int16_t* mono,size_t count) {
    if(!file_ || !good_ || !mono || count>kMaximumSamples-samples_) return false;
    const size_t written=fwrite(mono,sizeof(int16_t),count,file_);
    samples_+=written;
    if(written!=count) { good_=false; return false; }
    // Commit bounded progress once per second. The header intentionally stays
    // recoverable from real PCM length; a power cut loses at most the unsynced
    // tail rather than the entire recording.
    if(samples_-lastSynced_>=kAudioSampleRate) {
      if(!checkpoint()) { good_=false; return false; }
      lastSynced_=samples_;
    }
    return true;
  }
  bool finish() {
    if(!file_) return false;
    // Even after a partial fwrite/I2S error, flush and close whatever reached
    // the file, then derive the final header from its actual bounded length.
    fflush(file_);
    fclose(file_); file_=nullptr;
    return recoverPending(path_)==PendingStatus::Ready;
  }
  size_t samples() const { return samples_; }
 private:
  FILE* file_=nullptr;
  char path_[256]{};
  size_t samples_=0,lastSynced_=0;
  bool good_=false;
  bool checkpoint() { return fflush(file_)==0 && fsync(fileno(file_))==0; }
};
} // namespace AudioFile

// Reads the WAV directly from its file through HTTPClient's bounded upload
// buffer. Only multipart headers and a single caller-supplied chunk occupy RAM.
class FileMultipartPayload {
 public:
  FileMultipartPayload(const char* head,size_t headBytes,FILE* file,size_t fileBytes,const char* tail,size_t tailBytes)
      :head_(head),tail_(tail),file_(file),lengths_{headBytes,fileBytes,tailBytes},remaining_(headBytes+fileBytes+tailBytes) {}
  size_t remaining() const { return remaining_; }
  bool failed() const { return failed_; }
  int peek() {
    normalize();
    if(part_==3 || failed_) return -1;
    if(part_!=1) return uint8_t((part_==0?head_:tail_)[offset_]);
    const int value=fgetc(file_);
    if(value==EOF || ungetc(value,file_)==EOF) { failed_=true; return -1; }
    return value;
  }
  size_t read(uint8_t* out,size_t capacity) {
    size_t used=0;
    while(used<capacity && !failed_) {
      normalize(); if(part_==3) break;
      const size_t available=lengths_[part_]-offset_,count=available<capacity-used?available:capacity-used;
      size_t read=count;
      if(part_==1) { read=fread(out+used,1,count,file_); if(read!=count) failed_=true; }
      else memcpy(out+used,(part_==0?head_:tail_)+offset_,count);
      used+=read; offset_+=read; remaining_-=read;
    }
    return used;
  }
 private:
  const char *head_,*tail_; FILE* file_;
  size_t lengths_[3],remaining_,offset_=0;
  int part_=0; bool failed_=false;
  void normalize() { while(part_<3 && offset_==lengths_[part_]) { ++part_; offset_=0; } }
};
} // namespace Tamagotchi
