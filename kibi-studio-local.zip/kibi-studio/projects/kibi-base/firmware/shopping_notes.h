#pragma once
#include "config.h"
#include <cstring>

namespace Tamagotchi::ShoppingNotes {
inline constexpr char kHeading[]="Shopping";
// Internal storage marker: retain these exact bytes for existing note files.
// Display kHeading to users; never display or translate this reserved prefix.
inline constexpr char kPrefix[]="Нужно купить\n";
inline constexpr size_t kPrefixBytes=sizeof kPrefix-1;
// A reserved, exact first line keeps categories persistent in the existing
// plain-text note format. A similar sentence remains an ordinary note.
inline const char* body(const char* text) {
  if(!text || std::strncmp(text,kPrefix,kPrefixBytes)) return nullptr;
  const char* value=text+kPrefixBytes;
  for(const auto* at=reinterpret_cast<const unsigned char*>(value);*at;++at)
    if(*at>32) return value;
  return nullptr;
}
}
