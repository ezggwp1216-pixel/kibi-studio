#pragma once

#include "menu.h"
#include "audio_file.h"
#include "microphone_filter.h"
#include "microphone_i2s.h"
#include "audio_codec_power.h"
#include "power_management.h"
#include "cloud_voice_config.h"
#include "voice_preview.h"
#include "recording_start.h"
#include <math.h>
#include <stdio.h>

namespace Tamagotchi {

enum class ButtonEdge { None,Pressed,Released };
enum class AiState : uint8_t { Idle,Starting,Recording,Transcribing,Thinking,Done,Error };
enum class AiRecordingMode : uint8_t { Command30,Dictation300 };
inline bool aiCanStart(AiState state) { return state==AiState::Idle || state==AiState::Error; }
inline constexpr uint32_t recordingLimitSeconds(AiRecordingMode mode) {
  return mode==AiRecordingMode::Dictation300?kAudioMaxSeconds:kAudioCommandMaxSeconds;
}
inline constexpr size_t recordingMaximumSamples(AiRecordingMode mode) {
  return size_t(kAudioSampleRate)*recordingLimitSeconds(mode);
}
inline constexpr size_t recordingRequiredFreeBytes(AiRecordingMode mode) {
  return 44+recordingMaximumSamples(mode)*2+4096;
}
inline bool recordingHasCapacity(size_t total,size_t used,AiRecordingMode mode) {
  return total>=used && total-used>=recordingRequiredFreeBytes(mode);
}
inline bool recordingLimitReached(size_t samples,uint32_t started,uint32_t now,
                                  AiRecordingMode mode=AiRecordingMode::Command30) {
  return samples>=recordingMaximumSamples(mode) || uint32_t(now-started)>=recordingLimitSeconds(mode)*1000;
}
inline bool recordingReleaseStops(AiRecordingMode mode,ButtonEdge edge) {
  return edge==ButtonEdge::Released && mode!=AiRecordingMode::Dictation300;
}
class HoldButton {
 public:
  ButtonEdge update(bool pressed,uint32_t now) {
    if (!initialized_) { initialized_=true; raw_=stable_=pressed; changedAt_=now; return ButtonEdge::None; }
    if (pressed!=raw_) { raw_=pressed; changedAt_=now; }
    if (raw_!=stable_ && uint32_t(now-changedAt_)>=35) {
      stable_=raw_; return stable_?ButtonEdge::Pressed:ButtonEdge::Released;
    }
    return ButtonEdge::None;
  }
 private:
  bool initialized_=false,raw_=false,stable_=false;
  uint32_t changedAt_=0;
};

enum class MicrophoneStartStatus { Ready,Cancelled,TimedOut,ReadError };
struct MicrophoneStart {
  MicrophoneStartStatus status=MicrophoneStartStatus::ReadError;
  size_t frames=0,discardedFrames=0;
  uint32_t elapsedMs=0;
};
struct MicrophoneRefresh { bool operator()() const { return true; } };
// Drain analog/bias startup before looking for fresh PCM, never for speech.
// 400 ms is an initial engineering settling allowance, not a measured guarantee.
// File setup may overlap settling only after the codec initialization succeeded.
// The shared 600 ms local budget includes I2S/codec and overlapping file setup.
// The first live block after settling remains in the caller's buffer in full.
template<class Reader,class Clock,class Cancelled,class Refresh=MicrophoneRefresh>
MicrophoneStart prepareMicrophoneCapture(int16_t* stereo,size_t capacity,
                                        Reader read,Clock clock,Cancelled cancelled,
                                        uint32_t setupElapsedMs=0,Refresh refresh={},
                                        uint32_t settlingElapsedMs=0) {
  constexpr uint32_t timeoutMs=MicrophonePower::kReadyBudgetMs,settleMs=400;
  MicrophoneStart result;
  const uint32_t enteredAt=clock(),started=enteredAt-setupElapsedMs;
  const uint32_t settlingAt=enteredAt-settlingElapsedMs;
  bool refreshed=false;
  if(!stereo || !capacity || settlingElapsedMs>setupElapsedMs) return result;
  for(;;) {
    result.elapsedMs=uint32_t(clock()-started);
    if(cancelled()) { result.status=MicrophoneStartStatus::Cancelled; return result; }
    if(result.elapsedMs>=timeoutMs) { result.status=MicrophoneStartStatus::TimedOut; return result; }
    const uint32_t remaining=timeoutMs-result.elapsedMs;
    const bool settled=uint32_t(clock()-settlingAt)>=settleMs;
    if(settled && !refreshed) {
      const bool ok=refresh();
      result.elapsedMs=uint32_t(clock()-started);
      if(cancelled()) { result.status=MicrophoneStartStatus::Cancelled; return result; }
      if(result.elapsedMs>=timeoutMs) { result.status=MicrophoneStartStatus::TimedOut; return result; }
      if(!ok) return result;
      refreshed=true;
      continue; // Re-check cancellation and the deadline after the driver call.
    }
    size_t count=0;
    const bool ok=read(stereo,capacity,count,remaining<80?remaining:80);
    result.elapsedMs=uint32_t(clock()-started);
    if(cancelled()) { result.status=MicrophoneStartStatus::Cancelled; return result; }
    if(!ok || count>capacity) return result;
    if(result.elapsedMs>=timeoutMs) { result.status=MicrophoneStartStatus::TimedOut; return result; }
    // A block spanning the settling boundary may still contain the transient.
    // Only accept a block whose read began after the complete allowance.
    if(settled) {
      for(size_t i=0;i<count;++i) if(stereo[2*i]!=0 || stereo[2*i+1]!=0) {
        result.status=MicrophoneStartStatus::Ready; result.frames=count; return result;
      }
    }
    result.discardedFrames+=count;
  }
}

struct MicrophoneSummary {
  struct Channel { double rms=0,dc=0; uint32_t peak=0,clipped=0; } channel[2];
  size_t frames=0;
  double correlation=0,monoAttenuationDb=0;
  bool correlationValid=false,attenuationValid=false;
};
// Bounded raw-slot measurements only. No audio buffers, filters, channel
// selection or automatic gain changes are introduced by these statistics.
class MicrophoneDiagnostics {
 public:
  void observe(const int16_t* stereo,size_t count) {
    constexpr size_t maximum=size_t(kAudioSampleRate)*3;
    if(!stereo || frames_>=maximum) return;
    if(count>maximum-frames_) count=maximum-frames_;
    for(size_t i=0;i<count;++i) {
      const int32_t value[2]={stereo[2*i],stereo[2*i+1]};
      for(unsigned channel=0;channel<2;++channel) {
        const int32_t sample=value[channel];
        sum_[channel]+=sample; square_[channel]+=int64_t(sample)*sample;
        const uint32_t magnitude=uint32_t(sample<0?-sample:sample);
        if(magnitude>peak_[channel]) peak_[channel]=magnitude;
        if(sample==-32768 || sample==32767) ++clipped_[channel];
      }
      cross_+=int64_t(value[0])*value[1];
      const int32_t mixed=(value[0]+value[1])/2;
      mixedSum_+=mixed; mixedSquare_+=int64_t(mixed)*mixed;
    }
    frames_+=count;
  }
  MicrophoneSummary summary() const {
    MicrophoneSummary value; value.frames=frames_;
    if(!frames_) return value;
    double variance[2];
    for(unsigned channel=0;channel<2;++channel) {
      auto& result=value.channel[channel];
      result.dc=double(sum_[channel])/frames_;
      result.rms=sqrt(double(square_[channel])/frames_);
      result.peak=peak_[channel]; result.clipped=clipped_[channel];
      const double centered=double(square_[channel])/frames_-result.dc*result.dc;
      variance[channel]=centered>0?centered:0;
    }
    if(variance[0]>0 && variance[1]>0) {
      value.correlationValid=true;
      value.correlation=(double(cross_)/frames_-value.channel[0].dc*value.channel[1].dc)/sqrt(variance[0]*variance[1]);
      if(value.correlation>1) value.correlation=1;
      if(value.correlation<-1) value.correlation=-1;
    }
    const double strongest=variance[0]>variance[1]?variance[0]:variance[1];
    if(strongest>0) {
      value.attenuationValid=true;
      const double mean=double(mixedSum_)/frames_;
      const double mixed=double(mixedSquare_)/frames_-mean*mean;
      // A finite floor represents complete phase cancellation, not a DSP gate.
      value.monoAttenuationDb=mixed>strongest*1e-12?10*log10(mixed/strongest):-120;
    }
    return value;
  }
 private:
  size_t frames_=0;
  int64_t sum_[2]{},cross_=0,mixedSum_=0;
  uint64_t square_[2]{},mixedSquare_=0;
  uint32_t peak_[2]{},clipped_[2]{};
};

struct MicrophoneCaptureDiagnostics {
  struct Timing {
    uint64_t totalUs=0;
    uint32_t calls=0,maximumUs=0;
    void observe(uint32_t started,uint32_t finished) {
      const uint32_t duration=uint32_t(finished-started);
      totalUs+=duration; ++calls;
      if(duration>maximumUs) maximumUs=duration;
    }
  } read,append;
  uint32_t framesTotal=0;
  explicit MicrophoneCaptureDiagnostics(uint32_t started,size_t firstFrames=0)
      :framesTotal(uint32_t(firstFrames)),startedUs_(started) {}
  void observeRead(uint32_t started,uint32_t finished,size_t frames) {
    read.observe(started,finished); framesTotal+=uint32_t(frames);
  }
  void observeAppend(uint32_t started,uint32_t finished) { append.observe(started,finished); }
  uint32_t elapsedUs(uint32_t now) const { return uint32_t(now-startedUs_); }
 private:
  uint32_t startedUs_;
};

inline uint32_t convertMicrophoneBlock(const int16_t* stereo,int16_t* mono,size_t count,float& dc,
                                     MicrophoneAudio::VoiceFilter& filter) {
  uint64_t square=0;
  for(size_t i=0;i<count;++i) {
    const int32_t raw=(int32_t(stereo[2*i])+stereo[2*i+1])/2;
    dc+=0.005f*(float(raw)-dc);
    int32_t sample=int32_t(filter.process(float(raw)-dc)*2);
    if(sample>32767) sample=32767;
    if(sample<-32768) sample=-32768;
    mono[i]=int16_t(sample); square+=int64_t(sample)*sample;
  }
  return count ? uint32_t(sqrt(double(square)/count)) : 0;
}

// Streams three existing buffers without duplicating the PCM recording.
class MultipartPayload {
 public:
  MultipartPayload(const char* head,size_t headBytes,const uint8_t* audio,size_t audioBytes,const char* tail,size_t tailBytes)
      :data_{reinterpret_cast<const uint8_t*>(head),audio,reinterpret_cast<const uint8_t*>(tail)},
       lengths_{headBytes,audioBytes,tailBytes},remaining_(headBytes+audioBytes+tailBytes) {}
  size_t remaining() const { return remaining_; }
  int peek() const {
    for(int part=part_;part<3;++part) {
      const size_t offset=part==part_?offset_:0;
      if(offset<lengths_[part]) return data_[part][offset];
    }
    return -1;
  }
  size_t read(uint8_t* out,size_t capacity) {
    size_t used=0;
    while(part_<3 && used<capacity) {
      const size_t available=lengths_[part_]-offset_;
      const size_t count=available<capacity-used ? available : capacity-used;
      if(count) memcpy(out+used,data_[part_]+offset_,count);
      used+=count; offset_+=count; remaining_-=count;
      if(offset_==lengths_[part_]) { ++part_; offset_=0; }
    }
    return used;
  }
 private:
  const uint8_t* data_[3];
  size_t lengths_[3],remaining_,offset_=0;
  int part_=0;
};
// Main-loop owned. Only in-flight work needs a transient card;
// the answer reader or persistent note holds the completed result.
class VoiceNotice {
 public:
  enum class Stage { Hidden,Processing };
  bool update(AiState state,bool recordingActive,uint32_t now) {
    const Stage before=stage_;
    const uint8_t oldPhase=phase_;
    const bool processing=state==AiState::Transcribing || state==AiState::Thinking ||
        (state==AiState::Recording && !recordingActive);
    stage_=processing?Stage::Processing:Stage::Hidden;
    if(processing) phase_=uint8_t(now/100%8);
    return stage_!=before || (processing && phase_!=oldPhase);
  }
  Stage stage() const { return stage_; }
  unsigned phase() const { return phase_; }
 private:
  Stage stage_=Stage::Hidden;
  uint8_t phase_=0;
};
struct AiView {
  AiState state=AiState::Idle;
  const char* error="";
  bool retryAvailable=false;
  const VoiceNotice* notice=nullptr;
  const VoicePreview::Card* preview=nullptr;
};
// The error card has a fixed body viewport. Keep the visible line budget and
// show an explicit ellipsis instead of cutting a larger font through a line.
inline void drawAiErrorMessage(uint16_t* frame,int width,int height,const char* message) {
  if(!message) return;
  constexpr int left=36,top=124,bottom=226,columns=14,scale=2;
  const int pitch=Ui::textLineHeight(message,18,scale);
  const bool vietnamese=Ui::usesVietnameseFont(message);
  if(pitch<=0) return;
  const int lines=(bottom-top)/pitch;
  const char* at=message;
  for(int line=0;line<lines && *at;++line) {
    const auto part=Ui::wrapLine(at,columns);
    const int y=top+line*pitch;
    if(line+1<lines || !*part.next) {
      Ui::text(frame,width,height,at,part.end,left,y,scale,theme().text,top,bottom,vietnamese);
    } else {
      char clipped[384]{};
      size_t bytes=0;
      const int ellipsisWidth=Ui::textWidth("…",scale);
      const char* glyph=at;
      while(glyph<part.end) {
        const char* next=glyph;
        Ui::nextTextCodepoint(next,part.end);
        const size_t count=size_t(next-glyph);
        if(!count || count>sizeof clipped-5-bytes) break;
        memcpy(clipped+bytes,glyph,count);
        clipped[bytes+count]=0;
        if(Ui::textWidth(clipped,scale)+ellipsisWidth>columns*6*scale) break;
        bytes+=count;
        glyph=next;
      }
      while(bytes && (clipped[bytes-1]==' ' || clipped[bytes-1]=='\t')) --bytes;
      memcpy(clipped+bytes,"…",4);
      Ui::text(frame,width,height,clipped,left,y,scale,theme().text,top,bottom,vietnamese);
    }
    at=part.next;
  }
}
inline void drawAi(uint16_t* frame,int width,int height,const AiView& view,int pressedTarget=-1) {
  if(!frame || width<=0 || height<=0) return;
  if(view.preview && (view.state==AiState::Transcribing || view.state==AiState::Thinking)) {
    VoicePreview::draw(frame,width,height,*view.preview,view.notice?view.notice->phase():0,pressedTarget==0);
    return;
  }
  if(view.state!=AiState::Error) {
    const auto* notice=view.notice;
    if(!notice || notice->stage()==VoiceNotice::Stage::Hidden) return;
    constexpr int cardWidth=192,cardHeight=44;
    const int bottom=height-40<theme().downY-8?height-40:theme().downY-8;
    const int left=(width-cardWidth)/2,top=bottom-cardHeight;
    Ui::box(frame,width,height,left,top,cardWidth,cardHeight,12,false,44);
    static constexpr int8_t points[8][2]={{0,-6},{4,-4},{6,0},{4,4},{0,6},{-4,4},{-6,0},{-4,-4}};
    for(int dot=0;dot<8;++dot) for(int y=0;y<2;++y) for(int x=0;x<2;++x)
      Ui::pixel(frame,width,height,left+37+points[dot][0]+x,top+22+points[dot][1]+y,
          unsigned(dot)==notice->phase()?theme().text:theme().muted);
    Ui::text(frame,width,height,"Processing",left+56,
        Ui::centeredTextTop("Processing",top,cardHeight),2,theme().text,top,bottom);
    return;
  }
  for(int y=44;y<height;++y) for(int x=0;x<width;++x) Ui::pixel(frame,width,height,x,y,theme().overlay,150);
  Ui::box(frame,width,height,20,76,200,196,16,false,44);
  Ui::text(frame,width,height,"Couldn't finish",Ui::textCenteredX("Couldn't finish",width),
      Ui::centeredTextTop("Couldn't finish",88,30));
  drawAiErrorMessage(frame,width,height,view.error);
  const auto buttonLabel=[&](const char* label,int left,int top,int buttonWidth,int scale) {
    Ui::text(frame,width,height,label,left+(buttonWidth-Ui::textWidth(label,scale))/2,
        Ui::centeredTextTop(label,top,32,scale),scale,theme().text,top,top+32);
  };
  if(view.retryAvailable) {
    Ui::box(frame,width,height,28,232,88,32,10,pressedTarget==0,44);
    Ui::box(frame,width,height,124,232,88,32,10,pressedTarget==1,44);
    buttonLabel("Close",28,232,88,1);
    buttonLabel("Retry",124,232,88,1);
  } else {
    Ui::box(frame,width,height,60,232,120,32,10,pressedTarget==0,44);
    buttonLabel("Close",60,232,120,2);
  }
}
}  // namespace Tamagotchi

#ifdef ARDUINO
#include <Arduino.h>
#include <Wire.h>
#include <WiFiMulti.h>  // Resolves the library despite this project's wifi.h on macOS.
#include <esp_heap_caps.h>
#include <esp_random.h>
#include <atomic>
#include <time.h>
#include <LittleFS.h>
#if !KIBI_CLOUD_VOICE_ENABLED
#error "Direct provider mode is not public: keep keys on the service and KIBI_CLOUD_VOICE_ENABLED=1"
#endif
#include "assistant.h"
#include "http_json.h"
#include "cloud_voice.h"
#include "realtime_voice.h"

namespace Tamagotchi {
namespace AiDetail {
inline constexpr char kHost[]="https://api.groq.com/openai/v1/audio/transcriptions";
inline constexpr char kModel[]="whisper-large-v3-turbo";
struct CodecBus {
  bool present(uint8_t address) {
    Wire.beginTransmission(address);return Wire.endTransmission()==0;
  }
  bool write(uint8_t address,uint8_t reg,uint8_t value) {
    Wire.beginTransmission(address);Wire.write(reg);Wire.write(value);
    return Wire.endTransmission()==0;
  }
};
struct Runtime {
  std::atomic<AiState> state{AiState::Idle};
  std::atomic<AiRecordingMode> recordingMode{AiRecordingMode::Command30};
  std::atomic<bool> stop{false},attemptActive{false},pending{false},awaitingReminderSave{false},clockTrusted{false};
  std::atomic<uint32_t> elapsed{0};
  TaskHandle_t task=nullptr;
  MicrophoneI2s::StandardDriver microphoneDriver;
  MicrophoneI2s::Capture<MicrophoneI2s::StandardDriver> microphone{microphoneDriver};
  CodecBus codecBus;
  MicrophonePower::Codecs<CodecBus> codecs{codecBus};
  MicrophonePower::Lifecycle<decltype(microphone),decltype(codecs)> microphonePower{microphone,codecs};
  uint32_t microphoneWakeCount=0,microphoneStandbyCount=0,microphoneStandbyFailures=0;
  bool ready=false;
  HoldButton button;
  VoiceNotice notice;
  BoundedText transcript;
  RecordingStartDiagnostics recordingStart;
  // Main-loop callback must only publish the busy/cancellation request.
  void (*beforeRecording)()=nullptr;
  // Worker-only locking/cleanup; success means the exact selected WAV capacity
  // was checked before any microphone/network capture work.
  bool (*prepareRecording)(size_t requiredBytes)=nullptr;
  int (*recoverReminderRecording)()=nullptr;
  uint32_t (*reserveNoteId)()=nullptr;
  uint32_t cloudNoteId=0;
  Assistant::Reply reply;
  char error[192]{};
};
inline Runtime runtime;
inline bool busy(AiState state) {
  return state==AiState::Starting || state==AiState::Recording || state==AiState::Transcribing || state==AiState::Thinking;
}
inline void fail(const char* text) {
  snprintf(runtime.error,sizeof runtime.error,"%s",text);
  // Workers publish their final state only after closing and deleting PCM.
  // A quick second press must not race the previous attempt's cleanup.
  if(!runtime.attemptActive.load(std::memory_order_acquire))
    runtime.state.store(AiState::Error,std::memory_order_release);
}

inline void reportMicrophoneStandby(bool ok) {
  ++runtime.microphoneStandbyCount;
  if(!ok) {
    ++runtime.microphoneStandbyFailures;
    fail("Could not turn off the microphone. Try again.");
  }
  Serial.printf("[AI_POWER] standby=%u attempts=%lu failures=%lu\n",unsigned(ok),
      (unsigned long)runtime.microphoneStandbyCount,(unsigned long)runtime.microphoneStandbyFailures);
}
inline bool beginMicrophone() {
  // Boot initializes before the touch worker, then immediately enters standby.
  // All later lifecycle operations belong to the notified voice worker.
  const auto dac=runtime.codecs.suspendUnusedDac();
  Serial.printf("[AI_POWER] unused_dac=%u\n",unsigned(dac));
  const uint32_t started=millis();
  MicrophonePower::StandbyScope standby(runtime.microphonePower,reportMicrophoneStandby);
  const auto result=runtime.microphonePower.wake([] { return millis(); },
      [](uint32_t ms) { delay(ms); },[] { return false; },started);
  return result==MicrophonePower::WakeStatus::Ready && standby.close();
}

#if !KIBI_CLOUD_VOICE_ENABLED
class PayloadStream final : public Stream {
 public:
  explicit PayloadStream(FileMultipartPayload& payload):payload_(payload) {}
  int available() override { return int(payload_.remaining()); }
  int peek() override { return payload_.peek(); }
  int read() override { uint8_t value; return payload_.read(&value,1)?value:-1; }
  size_t readBytes(char* out,size_t bytes) override { return payload_.read(reinterpret_cast<uint8_t*>(out),bytes); }
  void flush() override {}
  size_t write(uint8_t) override { return 0; }
 private:
  FileMultipartPayload& payload_;
};
inline bool transcribe() {
  const auto recovered=AudioFile::recoverPending();
  const size_t bytes=recovered==AudioFile::PendingStatus::Ready?AudioFile::pendingBytes():0;
  if(!bytes) { runtime.pending=false; fail("The audio recording is invalid. Record again."); return false; }
  runtime.pending=true;
  FILE* audio=fopen(AudioFile::kPendingPath,"rb");
  if(!audio) { fail("Could not open the saved audio."); return false; }
  struct Close { FILE* file; ~Close() { fclose(file); } } close{audio};
  if(WiFi.status()!=WL_CONNECTED) { fail("No Wi-Fi. Connect, then record again."); return false; }
  const uint32_t started=millis();
  while(time(nullptr)<1735689600) {
    if(uint32_t(millis()-started)>=12000) { fail("Wait for the clock before connecting."); return false; }
    delay(30);
  }
  Https::DeadlineClient client(90000,NetworkGate::Priority::Voice);
  client.useBuiltinCACertBundle(); client.setTimeout(8000); client.setHandshakeTimeout(8);
  HTTPClient http;
  http.setUserAgent("Tamagotchi/1.0");
  http.setConnectTimeout(6000); http.setTimeout(8000); http.setReuse(false);
  if(!http.begin(client,kHost)) { fail("Could not connect to Groq."); return false; }
  char boundary[48],head[512],tail[64];
  snprintf(boundary,sizeof boundary,"----Tama%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random());
  const int headBytes=snprintf(head,sizeof head,
      "--%s\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\n%s\r\n"
      "--%s\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\nen\r\n"
      "--%s\r\nContent-Disposition: form-data; name=\"response_format\"\r\n\r\ntext\r\n"
      "--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voice.wav\"\r\nContent-Type: audio/wav\r\n\r\n",
      boundary,kModel,boundary,boundary,boundary);
  const int tailBytes=snprintf(tail,sizeof tail,"\r\n--%s--\r\n",boundary);
  if(headBytes<0 || size_t(headBytes)>=sizeof head || tailBytes<0 || size_t(tailBytes)>=sizeof tail) {
    http.end(); fail("Could not prepare the audio request."); return false;
  }
  http.addHeader("Authorization",String("Bearer ")+kGroqApiKey);
  http.addHeader("Content-Type",String("multipart/form-data; boundary=")+boundary);
  http.addHeader("Accept","text/plain"); http.addHeader("Accept-Encoding","identity");
  FileMultipartPayload payload(head,size_t(headBytes),audio,bytes,tail,size_t(tailBytes));
  const size_t contentBytes=payload.remaining(); PayloadStream stream(payload);
  const int status=http.sendRequest("POST",&stream,contentBytes);
  Serial.printf("[AI] Groq HTTP=%d; audio bytes=%lu\n",status,(unsigned long)bytes);
  if(status!=200 || payload.failed() || payload.remaining()) {
    http.end();
    if(status==401 || status==403) fail("Groq denied access. Check ai_secrets.h.");
    else if(status==429) fail("Groq limit reached. Try again later.");
    else if(status<0) fail("Could not connect to Groq. Check your connection.");
    else fail("Groq could not transcribe the recording. Try again.");
    return false;
  }
  Https::BoundedStream response(runtime.transcript.data(),runtime.transcript.capacity());
  const bool tooLarge=http.getSize()>kNoteTextBytes;
  const int received=tooLarge ? -1 : http.writeToStream(&response);
  http.end();
  if(client.timedOut()) { fail("Groq timed out. Record again."); return false; }
  if(tooLarge || response.overflow || received<0) {
    fail(tooLarge || response.overflow ? "The text is too long. Record a shorter note." : "The Groq response was interrupted. Record again.");
    return false;
  }
  char* text=runtime.transcript.data();
  size_t first=0,last=strlen(text);
  while(first<last && (text[first]==' ' || text[first]=='\n' || text[first]=='\r' || text[first]=='\t')) ++first;
  while(last>first && (text[last-1]==' ' || text[last-1]=='\n' || text[last-1]=='\r' || text[last-1]=='\t')) --last;
  memmove(text,text+first,last-first); text[last-first]=0;
  if(!*text) { fail("No speech recognized. Speak closer to the microphone."); return false; }
  return true;
}
#else
// A recording has one upload and one job identity. Provider keys and the direct
// assistant request are excluded entirely from this build.
inline bool transcribe() {
  if(AudioFile::recoverPending()!=AudioFile::PendingStatus::Ready) {
    fail("Could not read the audio. Record again."); return false;
  }
  runtime.pending=true;
  if(!CloudVoice::process(runtime.cloudNoteId,runtime.transcript.data(),runtime.transcript.capacity(),
      runtime.reply,runtime.error,sizeof runtime.error)) {
    return false;
  }
  return true;
}
#endif

inline bool prepareCloudNoteId() {
#if KIBI_CLOUD_VOICE_ENABLED
  // This callback runs on the main loop, the owner of NoteStore. The worker
  // only receives the reserved value and never mutates note storage.
  runtime.cloudNoteId=runtime.reserveNoteId?runtime.reserveNoteId():0;
  if(!runtime.cloudNoteId) { fail("Could not reserve a note. Check storage."); return false; }
#endif
  return true;
}

inline bool captureAndTranscribe(AiRecordingMode mode) {
  MicrophonePower::StandbyScope standby(runtime.microphonePower,reportMicrophoneStandby);
  const size_t maxSamples=recordingMaximumSamples(mode);
  const char* shortMessage=mode==AiRecordingMode::Dictation300?
      "The recording is too short. Record a little longer.":"The recording is too short. Hold + and speak.";
  if(runtime.stop.load(std::memory_order_relaxed)) { fail(shortMessage); return false; }
  AudioFile::Recorder recording;
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  const bool realtime=mode==AiRecordingMode::Command30;
  bool realtimeJoined=false;
  struct CloseRealtime {
    bool enabled; bool& joined;
    ~CloseRealtime() { if(enabled && !joined) RealtimeVoice::cancel(); }
  } closeRealtime{false,realtimeJoined};
#endif
  auto abortRecording=[&](const char* message) {
    runtime.stop.store(true,std::memory_order_relaxed);
    const bool poweredDown=standby.close();
    recording.finish();
    runtime.pending.store(AudioFile::pendingBytes()!=0,std::memory_order_release);
    fail(poweredDown?message:"Could not turn off the microphone. Try again."); return false;
  };
  int16_t stereo[512],mono[256]; size_t receivedFrames=0;
  const auto readMicrophone=[](int16_t* out,size_t capacity,size_t& count,uint32_t timeout) {
    return runtime.microphone.read(out,capacity,count,timeout)!=MicrophoneI2s::ReadStatus::Error;
  };
  const auto cancelled=[] { return runtime.stop.load(std::memory_order_relaxed); };
  if(cancelled()) return abortRecording(shortMessage);
  const uint32_t microphoneWakeAt=millis();
  ++runtime.microphoneWakeCount;
  const auto wake=runtime.microphonePower.wake([] { return millis(); },
      [](uint32_t ms) { delay(ms); },cancelled,microphoneWakeAt);
  if(wake!=MicrophonePower::WakeStatus::Ready) {
    Serial.printf("[AI_POWER] wake=%u elapsed_ms=%lu attempt=%lu\n",unsigned(wake),
        (unsigned long)uint32_t(millis()-microphoneWakeAt),(unsigned long)runtime.microphoneWakeCount);
    return abortRecording(wake==MicrophonePower::WakeStatus::Cancelled?shortMessage:
        "Could not turn on the microphone. Try again.");
  }
  const uint32_t analogReadyAt=millis();
  if(cancelled()) return abortRecording(shortMessage);
  // Keep the complete analog settling allowance, but let file creation/header
  // sync use that same interval instead of delaying microphone wake first.
  if(!recording.begin()) return abortRecording("Could not create the audio file.");
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  if(realtime) {
    if(!RealtimeVoice::start(runtime.cloudNoteId))
      return abortRecording("Voice chat is unavailable. Record again.");
    closeRealtime.enabled=true;
    strcpy(runtime.reply.jobId,RealtimeVoice::jobId());
  }
#endif
  const uint32_t capturePreparedAt=millis();
  const auto startup=prepareMicrophoneCapture(stereo,256,readMicrophone,
      [] { return millis(); },cancelled,uint32_t(capturePreparedAt-microphoneWakeAt),
      [] { return runtime.microphone.stop() && runtime.microphone.start(); },
      uint32_t(capturePreparedAt-analogReadyAt));
  Serial.printf("[AI_POWER] wake=%u elapsed_ms=%lu attempt=%lu\n",unsigned(startup.status),
      (unsigned long)startup.elapsedMs,(unsigned long)runtime.microphoneWakeCount);
  if(startup.status!=MicrophoneStartStatus::Ready || runtime.stop.load(std::memory_order_relaxed)) {
    if(startup.status==MicrophoneStartStatus::Cancelled || runtime.stop.load(std::memory_order_relaxed))
      return abortRecording(shortMessage);
    return abortRecording(startup.status==MicrophoneStartStatus::TimedOut?
        "The microphone sent no audio. Record again.":"Microphone capture was interrupted. Record again.");
  }
  runtime.recordingStart.firstLivePcm(micros());
  MicrophoneDiagnostics diagnostics;
  MicrophoneAudio::VoiceFilter voiceFilter;
  float dc=0; uint32_t peak=0;
  MicrophoneCaptureDiagnostics capture(micros(),startup.frames);
  const uint32_t started=millis();
  runtime.state.store(AiState::Recording,std::memory_order_release);
  auto appendBlock=[&](size_t count) {
    diagnostics.observe(stereo,count);
    const uint32_t rms=convertMicrophoneBlock(stereo,mono,count,dc,voiceFilter);
    const uint32_t appendStarted=micros();
    const bool appended=recording.append(mono,count);
    capture.observeAppend(appendStarted,micros());
    if(!appended) return false;
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
    // This bounded copy never waits for a network call or TLS handshake. A full
    // ring aborts the whole attempt rather than silently dropping microphone PCM.
    if(realtime && !RealtimeVoice::append(mono,count)) return false;
#endif
    if(rms>peak) peak=rms;
    runtime.elapsed.store(uint32_t(millis()-started),std::memory_order_relaxed);
    return true;
  };
  // Startup's first live DMA block is the first recorded block, never a throwaway.
  if(!appendBlock(startup.frames))
    return abortRecording("Storage or voice chat could not keep up. Record again.");
  while(!recordingLimitReached(recording.samples(),started,millis(),mode) && !runtime.stop.load(std::memory_order_relaxed)) {
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
    if(realtime && RealtimeVoice::shouldStopCapture()) break;
#endif
    const size_t want=maxSamples-recording.samples()<256 ? maxSamples-recording.samples() : 256;
    const uint32_t readStarted=micros();
    const auto error=runtime.microphone.read(stereo,want,receivedFrames,80);
    capture.observeRead(readStarted,micros(),receivedFrames);
    if(error!=MicrophoneI2s::ReadStatus::Ok || !receivedFrames) {
      return abortRecording("Microphone capture was interrupted. Record again.");
    }
    if(!appendBlock(receivedFrames))
      return abortRecording("Storage or voice chat could not keep up. Record again.");
  }
  runtime.stop.store(true,std::memory_order_relaxed);
  const uint32_t captureUs=capture.elapsedUs(micros());
  const auto counters=runtime.microphone.snapshot();
  const float microphoneSampleRate=runtime.microphone.sampleRate();
  if(!standby.close()) return abortRecording("Could not turn off the microphone. Try again.");
  Serial.printf("[AI_CAPTURE] driver=std iram_safe=1 dma_frames=512 dma_desc=8 frames_total=%lu capture_us=%lu i2s_hz=%.2f "
      "read_calls=%lu read_us=%llu read_max_us=%lu append_calls=%lu append_us=%llu append_max_us=%lu "
      "rx_done=%lu rx_overflow=%lu\n",
      (unsigned long)capture.framesTotal,(unsigned long)captureUs,double(microphoneSampleRate),
      (unsigned long)capture.read.calls,(unsigned long long)capture.read.totalUs,(unsigned long)capture.read.maximumUs,
      (unsigned long)capture.append.calls,(unsigned long long)capture.append.totalUs,(unsigned long)capture.append.maximumUs,
      (unsigned long)counters.rxDone,(unsigned long)counters.rxOverflow);
  Serial.printf("[AI] recorded=%lums; peak_rms=%lu\n",(unsigned long)runtime.elapsed.load(),(unsigned long)peak);
  const auto measured=diagnostics.summary();
  Serial.printf("[AI_MIC] frames=%lu startup_ms=%lu discarded_frames=%lu "
      "ch0_rms=%.1f ch0_dc=%.1f ch0_peak=%lu ch0_clip=%lu "
      "ch1_rms=%.1f ch1_dc=%.1f ch1_peak=%lu ch1_clip=%lu "
      "corr_valid=%u corr=%.4f mono_db_valid=%u mono_db=%.2f\n",
      (unsigned long)measured.frames,(unsigned long)startup.elapsedMs,
      (unsigned long)startup.discardedFrames,
      measured.channel[0].rms,measured.channel[0].dc,(unsigned long)measured.channel[0].peak,(unsigned long)measured.channel[0].clipped,
      measured.channel[1].rms,measured.channel[1].dc,(unsigned long)measured.channel[1].peak,(unsigned long)measured.channel[1].clipped,
      unsigned(measured.correlationValid),measured.correlation,unsigned(measured.attenuationValid),measured.monoAttenuationDb);
  const size_t samples=recording.samples();
  const bool finished=recording.finish();
  if(!finished) { fail("Could not finish the audio file."); return false; }
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  // A terminal transport error must keep its original job identity even when
  // it stopped capture early; only a healthy short/silent attempt is cancelled.
  if(realtime && RealtimeVoice::shouldStopCapture()) {
    runtime.state.store(AiState::Transcribing,std::memory_order_release);
    const auto result=RealtimeVoice::finish(uint32_t(samples),runtime.transcript.data(),runtime.transcript.capacity(),
        runtime.reply,runtime.error,sizeof runtime.error);
    realtimeJoined=true; return result==RealtimeVoice::Finish::Complete;
  }
#endif
  if(samples<kAudioSampleRate/4) { remove(AudioFile::kPendingPath); fail(shortMessage); return false; }
  if(peak<20) { remove(AudioFile::kPendingPath); fail("No speech detected. Move kibi closer."); return false; }
  runtime.pending.store(true,std::memory_order_release);
  runtime.state.store(AiState::Transcribing,std::memory_order_release);
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  if(realtime) {
    const auto result=RealtimeVoice::finish(uint32_t(samples),runtime.transcript.data(),runtime.transcript.capacity(),
        runtime.reply,runtime.error,sizeof runtime.error);
    realtimeJoined=true;
    if(result!=RealtimeVoice::Finish::Fallback) return result==RealtimeVoice::Finish::Complete;
  }
#endif
  return transcribe();
}
inline bool recordAndTranscribe() {
  PowerManagement::PerformanceLease performance;
  runtime.recordingStart.workerStarted(micros());
  runtime.recordingStart.preflightStarted(micros());
  const auto mode=runtime.recordingMode.load(std::memory_order_acquire);
  const auto result=runPreparedRecordingAttempt(recordingRequiredFreeBytes(mode),
      [] { return runtime.stop.load(std::memory_order_relaxed); },
      [](size_t requiredBytes) {
        if(mkdir("/littlefs/audio",0777)!=0 && errno!=EEXIST) {
          fail("Audio storage is unavailable."); return false;
        }
        if(!AudioFile::acknowledgeSaved()) {
          fail("Could not clear the previous recording. Check storage."); return false;
        }
        runtime.pending.store(false,std::memory_order_release);
        if(runtime.prepareRecording && !runtime.prepareRecording(requiredBytes)) {
          fail("Could not prepare storage. Record again."); return false;
        }
        return true;
      },
      [mode](size_t) {
        // A registered storage preflight succeeds only after checking the exact
        // selected WAV capacity. Avoid an immediate duplicate walk; this is a
        // checked snapshot, not an exclusive FS reservation. Keep the fallback.
        return runtime.prepareRecording || recordingHasCapacity(LittleFS.totalBytes(),LittleFS.usedBytes(),mode);
      },
      [mode] {
        runtime.recordingStart.preflightFinished(micros());
        return captureAndTranscribe(mode);
      });
  if(result==RecordingAttemptStatus::Complete) return true;
  // Successful preflight was already measured before entering capture. Failed
  // or cancelled preparation is measured here, without microphone/network work.
  runtime.recordingStart.preflightFinished(micros());
  runtime.recordingStart.abort(result==RecordingAttemptStatus::Cancelled?
      RecordingStartStage::Cancelled:RecordingStartStage::Failed);
  if(result==RecordingAttemptStatus::Cancelled)
    fail(mode==AiRecordingMode::Dictation300?"The recording is too short. Record a little longer.":
        "The recording is too short. Hold + and speak.");
  else if(result==RecordingAttemptStatus::InsufficientCapacity)
    fail(mode==AiRecordingMode::Dictation300?"Not enough room for a five-minute recording. Free up storage.":
        "Not enough room to record a command. Free up storage.");
  return false;
}
inline void worker(void*) {
  for(;;) {
    ulTaskNotifyTake(pdTRUE,portMAX_DELAY);
    bool ok=recordAndTranscribe();
    if(ok) {
      runtime.state.store(AiState::Thinking,std::memory_order_release);
#if KIBI_CLOUD_VOICE_ENABLED
      // Cloud transcription already includes the durable command result.
#else
      ok=Assistant::respond(runtime.transcript.data(),runtime.reply,runtime.error,sizeof runtime.error,runtime.clockTrusted.load());
#endif
    }
    // No audio survives an attempt, including network/provider/I2S errors.
    // The response text remains in RAM for App to persist; it needs no WAV.
    if(!AudioFile::acknowledgeSaved()) Serial.println("[AI] Audio cleanup failed; a new capture stays blocked until cleanup succeeds");
    runtime.pending.store(false,std::memory_order_release);
    runtime.awaitingReminderSave.store(ok && runtime.reply.intent==Assistant::Intent::Reminder,std::memory_order_release);
    runtime.attemptActive.store(false,std::memory_order_release);
    runtime.state.store(ok?AiState::Done:AiState::Error,std::memory_order_release);
  }
}
}  // namespace AiDetail

inline AiState aiState() { return AiDetail::runtime.state.load(std::memory_order_acquire); }
inline bool aiRecording() {
  return aiState()==AiState::Recording && !AiDetail::runtime.stop.load(std::memory_order_relaxed);
}
inline bool aiBusy() { return AiDetail::runtime.attemptActive.load(std::memory_order_acquire) || AiDetail::busy(aiState()); }
inline const VoicePreview::Card* aiPreview() {
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  return RealtimeVoice::preview();
#else
  return nullptr;
#endif
}
inline bool aiPreviewVisible() { return aiPreview()!=nullptr; }
inline bool aiResultPresentationAllowed() {
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  return RealtimeVoice::allowFinalPresentation();
#else
  return true;
#endif
}
inline bool aiModalVisible() { return aiState()==AiState::Error || aiPreviewVisible(); }
inline void dismissAi() {
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  if(aiPreviewVisible()) {RealtimeVoice::dismissPreview();return;}
#endif
  if(!aiBusy()) AiDetail::runtime.state.store(AiState::Idle,std::memory_order_release);
}
inline bool beginAi() {
  using namespace AiDetail;
  pinMode(Board::kPlus,INPUT_PULLUP); runtime.button.update(digitalRead(Board::kPlus)==LOW,millis());
  // Import only an already structured reminder from older firmware. Never
  // transcribe or upload an interrupted recording after restart.
  const int claimed=runtime.recoverReminderRecording?runtime.recoverReminderRecording():0;
  if(claimed<0) Serial.println("[AI] Previous reminder claim could not be recovered");
  const bool audioCleared=AudioFile::acknowledgeSaved();
  runtime.pending.store(false,std::memory_order_release);
  if(!runtime.transcript.reserve(kNoteTextBytes+1)) { fail("Not enough memory for the transcript."); return false; }
  if(!beginMicrophone()) { Serial.println("[AI] ES7210/I2S initialization failed"); return false; }
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  if(!RealtimeVoice::begin()) Serial.println("[AI] Realtime task or PSRAM buffer unavailable");
#endif
  runtime.ready=xTaskCreatePinnedToCore(worker,"voice_ai",12288,nullptr,1,&runtime.task,0)==pdPASS;
  if(!runtime.ready) runtime.microphone.end();
  Serial.printf("[AI] microphone=%s; model=%s; hold GPIO40 limit=%lus; recorder limit=%lus\n",
      runtime.ready?"ready":"unavailable",CloudVoice::kEnabled?"kibi Core":kModel,
      (unsigned long)kAudioCommandMaxSeconds,(unsigned long)kAudioMaxSeconds);
  if(!audioCleared) fail("Could not clear the previous recording. Check storage.");
  return runtime.ready;
}
inline bool retryAi() {
  using namespace AiDetail;
  if(!aiCanStart(aiState()) || aiBusy() || !runtime.ready || !runtime.task) return false;
  // This retries only local persistence of an already parsed reminder. It
  // neither wakes the voice worker nor sends any audio to a server.
  if(runtime.awaitingReminderSave.load(std::memory_order_acquire)) {
    runtime.state.store(AiState::Done,std::memory_order_release);return true;
  }
  return false;
}
inline void ackAiResultSaved(bool saved) {
  using namespace AiDetail;
  if(saved && aiState()==AiState::Done) {
    runtime.awaitingReminderSave.store(false,std::memory_order_release);
    runtime.pending.store(false,std::memory_order_release);
    if(!AudioFile::acknowledgeSaved()) Serial.println("[AI] Result saved; audio metadata cleanup failed");
  }
}
inline bool aiHasPendingAudio() { return AiDetail::runtime.pending.load(std::memory_order_acquire); }
inline bool aiCanRetryLocalSave() {
  return aiState()==AiState::Error && AiDetail::runtime.awaitingReminderSave.load(std::memory_order_acquire);
}
inline bool aiContinuousRecording() {
  return AiDetail::runtime.recordingMode.load(std::memory_order_acquire)==AiRecordingMode::Dictation300;
}
inline uint32_t aiRecordingLimitSeconds() {
  return recordingLimitSeconds(AiDetail::runtime.recordingMode.load(std::memory_order_acquire));
}
inline uint32_t aiRecordingElapsedMs() { return AiDetail::runtime.elapsed.load(std::memory_order_relaxed); }
inline RecordingStartSnapshot aiRecordingStartSnapshot() { return AiDetail::runtime.recordingStart.snapshot(); }
inline void stopAiRecording() {
  const auto state=aiState();
  if(state==AiState::Starting || state==AiState::Recording)
    AiDetail::runtime.stop.store(true,std::memory_order_relaxed);
}
namespace AiDetail {
// Main-loop entry point shared by the held command button and menu recorder.
// Mode remains stable until the next fresh attempt, including result/error UI.
inline bool startRecording(AiRecordingMode mode) {
  if(!aiCanStart(aiState()) || aiBusy() || runtime.awaitingReminderSave.load(std::memory_order_acquire)) return false;
  runtime.recordingMode.store(mode,std::memory_order_release);
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  RealtimeVoice::resetPreview();
#endif
  runtime.reply.reset();
  if(!runtime.ready || !runtime.task) { fail("The ES7210 microphone is unavailable. Check the connection."); return false; }
#if !KIBI_CLOUD_VOICE_ENABLED
  if(strncmp(kGroqApiKey,"gsk_",4) || strlen(kGroqApiKey)<25 || strchr(kGroqApiKey,'\r') || strchr(kGroqApiKey,'\n')) {
    fail("Add your Groq key in ai_secrets.h."); return false;
  }
#endif
  runtime.pending.store(false,std::memory_order_release);
  if(WiFi.status()!=WL_CONNECTED) { fail("No Wi-Fi. Wait for a connection, then record again."); return false; }
  runtime.recordingStart.requested(micros());
  if(!prepareCloudNoteId()) { runtime.recordingStart.abort(RecordingStartStage::Failed); return false; }
  runtime.stop.store(false,std::memory_order_relaxed); runtime.elapsed=0;
  runtime.transcript.data()[0]=0; runtime.error[0]=0;
  runtime.attemptActive.store(true,std::memory_order_release);
  runtime.state.store(AiState::Starting,std::memory_order_release);
  if(runtime.beforeRecording) runtime.beforeRecording();
  xTaskNotifyGive(runtime.task);
  return true;
}
} // namespace AiDetail
inline bool startLongRecording() { return AiDetail::startRecording(AiRecordingMode::Dictation300); }
inline void updateAiButton() {
  using namespace AiDetail;
  const auto event=runtime.button.update(digitalRead(Board::kPlus)==LOW,millis());
  if(event==ButtonEdge::Released) {
    if(recordingReleaseStops(runtime.recordingMode.load(std::memory_order_acquire),event)) stopAiRecording();
    return;
  }
  if(event!=ButtonEdge::Pressed || !aiCanStart(aiState()) || aiBusy()) return;
  if(runtime.awaitingReminderSave.load(std::memory_order_acquire)) {retryAi();return;}
  startRecording(AiRecordingMode::Command30);
}
inline const char* aiTranscript() { return aiState()==AiState::Done ? AiDetail::runtime.transcript.data() : ""; }
inline const Assistant::Reply& aiReply() { return AiDetail::runtime.reply; }
inline uint32_t aiNoteId() { return CloudVoice::kEnabled?AiDetail::runtime.cloudNoteId:0; }
inline bool updateAiNotice(uint32_t now) {
  const auto state=aiState();
  const bool recording=state==AiState::Recording && !AiDetail::runtime.stop.load(std::memory_order_relaxed);
  bool changed=AiDetail::runtime.notice.update(state,recording,now);
#if KIBI_CLOUD_VOICE_ENABLED && KIBI_REALTIME_VOICE_ENABLED
  changed|=RealtimeVoice::updatePreview(state==AiState::Transcribing || state==AiState::Thinking);
#endif
  return changed;
}
inline bool aiNeedsRedraw() {
  static uint32_t previous=UINT32_MAX;
  const auto state=aiState();
  const uint32_t key=uint32_t(state);
  const bool changed=key!=previous; previous=key; return changed;
}
inline int aiHit(int x,int y) {
  if(aiPreviewVisible()) return PageUi::backHit(x,y,240,296)?0:-1;
  if(aiState()!=AiState::Error || y<232 || y>=264) return -1;
  if(aiCanRetryLocalSave()) return x>=28 && x<116?0:(x>=124 && x<212?1:-1);
  return x>=60 && x<180?0:-1;
}
inline void drawAi(uint16_t* frame,int width,int height,int pressedTarget=-1) {
  const AiView view{aiState(),AiDetail::runtime.error,aiCanRetryLocalSave(),&AiDetail::runtime.notice,aiPreview()};
  drawAi(frame,width,height,view,pressedTarget);
}
}  // namespace Tamagotchi
#endif  // ARDUINO
