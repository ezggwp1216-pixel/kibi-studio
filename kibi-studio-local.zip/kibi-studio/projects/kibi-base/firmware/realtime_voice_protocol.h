#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include "server_endpoint.h"

namespace Tamagotchi::RealtimeVoice {
inline constexpr unsigned kProtocolVersion=2; // v2 opts into read-only text previews.
// One complete short command fits while cold DNS/TLS/provider startup runs.
// The producer still never waits for a network operation or drops PCM.
inline constexpr size_t kPcmRingBytes=1024*1024,kMaximumPcmFrameBytes=4096;
inline constexpr uint32_t kReadyTimeoutMs=12000;
// Single capture producer / single TLS consumer. Their cursors publish only
// complete copied bytes; neither side waits for the other or allocates memory.
class PcmRing {
 public:
  PcmRing(uint8_t* storage,size_t capacity):storage_(storage),capacity_(capacity) {}
  bool push(const uint8_t* data,size_t bytes) {
    const uint32_t head=head_.load(std::memory_order_relaxed),tail=tail_.load(std::memory_order_acquire);
    if(!data || !storage_ || !capacity_ || bytes>capacity_-(head-tail)) { overflow_.store(true); return false; }
    const size_t offset=head%capacity_,first=bytes<capacity_-offset?bytes:capacity_-offset;
    memcpy(storage_+offset,data,first); memcpy(storage_,data+first,bytes-first);
    head_.store(head+uint32_t(bytes),std::memory_order_release); return true;
  }
  size_t pop(uint8_t* out,size_t capacity) {
    const uint32_t tail=tail_.load(std::memory_order_relaxed),head=head_.load(std::memory_order_acquire);
    size_t bytes=head-tail; if(bytes>capacity) bytes=capacity;
    if(!bytes || !out || !storage_) return 0;
    const size_t offset=tail%capacity_,first=bytes<capacity_-offset?bytes:capacity_-offset;
    memcpy(out,storage_+offset,first); memcpy(out+first,storage_,bytes-first);
    tail_.store(tail+uint32_t(bytes),std::memory_order_release); return bytes;
  }
  size_t size() const { return head_.load(std::memory_order_acquire)-tail_.load(std::memory_order_acquire); }
  bool overflowed() const { return overflow_.load(); }
  // Reset only after both owners have stopped the previous session.
  void reset() { head_=0; tail_=0; overflow_=false; }
 private:
  uint8_t* storage_; size_t capacity_;
  std::atomic<uint32_t> head_{0},tail_{0}; std::atomic<bool> overflow_{false};
};
enum class FailureRecovery { Stop,Poll };
class SendLedger {
 public:
  void pcmAttempted() { pcm_=true; }
  bool canFallback() const { return !pcm_ && !commit_; }
  bool claimCommit() { if(commit_) return false; commit_=true; return true; }
  bool committed() const { return commit_; }
  // Core publishes no durable job before commit. PCM still forbids replay,
  // but only an attempted commit can require recovery of an accepted result.
  FailureRecovery failureRecovery() const { return commit_?FailureRecovery::Poll:FailureRecovery::Stop; }
 private:
  bool pcm_=false,commit_=false;
};
enum class InitialConnectRecovery { Stop,Retry,Fallback };
inline InitialConnectRecovery initialLeaseRecovery(bool acquired,const SendLedger& ledger,bool cancelled) {
  return !acquired && !cancelled && ledger.canFallback()?InitialConnectRecovery::Fallback:InitialConnectRecovery::Stop;
}
inline InitialConnectRecovery initialConnectRecovery(unsigned attempt,int error,bool upgradeStarted,
                                                      const SendLedger& ledger,bool cancelled) {
  if(cancelled || upgradeStarted || !ledger.canFallback() || attempt<1 || attempt>2)
    return InitialConnectRecovery::Stop;
  // Core 3.3.12 returns 0 for unresolved DNS and -1 for TCP/handshake timeouts.
  // The remaining codes are mbedTLS network/timeout errors. Certificate,
  // configuration, memory and unknown TLS errors fail closed.
  const bool transient=error==0 || error==-1 || error==-0x0044 || error==-0x004c ||
      error==-0x004e || error==-0x0050 || error==-0x6800;
  if(!transient) return InitialConnectRecovery::Stop;
  return attempt==1?InitialConnectRecovery::Retry:InitialConnectRecovery::Fallback;
}
inline char lower(char c) { return c>='A' && c<='Z'?char(c+'a'-'A'):c; }
inline bool equalInsensitive(const char* a,size_t bytes,const char* b) {
  if(strlen(b)!=bytes) return false;
  for(size_t i=0;i<bytes;++i) if(lower(a[i])!=lower(b[i])) return false;
  return true;
}
inline bool tokenContains(const char* value,size_t bytes,const char* token) {
  size_t offset=0;
  while(offset<bytes) {
    while(offset<bytes && (value[offset]==' ' || value[offset]=='\t' || value[offset]==',')) ++offset;
    size_t end=offset; while(end<bytes && value[end]!=',') ++end;
    size_t last=end; while(last>offset && (value[last-1]==' ' || value[last-1]=='\t')) --last;
    if(equalInsensitive(value+offset,last-offset,token)) return true;
    offset=end+1;
  }
  return false;
}
// Reject incomplete/duplicate upgrade fields and response smuggling. A non-101
// status is returned only for a complete ordinary HTTP response header.
inline int validateUpgrade(const char* headers,const char* expectedAccept) {
  if(!headers || !expectedAccept) return 0;
  const char* first=strstr(headers,"\r\n");
  if(!first || strncmp(headers,"HTTP/1.1 ",9) || first-headers<12 ||
     headers[9]<'1' || headers[9]>'5' || headers[10]<'0' || headers[10]>'9' || headers[11]<'0' || headers[11]>'9' ||
     (first-headers>12 && headers[12]!=' ')) return 0;
  const int status=100*(headers[9]-'0')+10*(headers[10]-'0')+headers[11]-'0';
  bool upgrade=false,connection=false,accept=false;
  const char* line=first+2;
  for(;;) {
    const char* end=strstr(line,"\r\n"); if(!end) return 0;
    if(end==line) return !end[2] && (status!=101 || (upgrade && connection && accept))?status:0;
    const char* colon=static_cast<const char*>(memchr(line,':',size_t(end-line)));
    if(!colon || colon==line || *line==' ' || *line=='\t') return 0;
    const char* value=colon+1; while(value<end && (*value==' ' || *value=='\t')) ++value;
    const char* last=end; while(last>value && (last[-1]==' ' || last[-1]=='\t')) --last;
    const size_t nameBytes=size_t(colon-line),valueBytes=size_t(last-value);
    if(status!=101) { line=end+2; continue; }
    if(equalInsensitive(line,nameBytes,"upgrade")) {
      if(upgrade || !equalInsensitive(value,valueBytes,"websocket")) return 0; upgrade=true;
    } else if(equalInsensitive(line,nameBytes,"connection")) {
      if(connection || !tokenContains(value,valueBytes,"upgrade")) return 0; connection=true;
    } else if(equalInsensitive(line,nameBytes,"sec-websocket-accept")) {
      if(accept || strlen(expectedAccept)!=valueBytes || memcmp(value,expectedAccept,valueBytes)) return 0; accept=true;
    } else if(status==101 && (equalInsensitive(line,nameBytes,"sec-websocket-extensions") ||
                              equalInsensitive(line,nameBytes,"sec-websocket-protocol"))) return 0;
    line=end+2;
  }
}
inline size_t clientFrameHeader(uint8_t opcode,size_t bytes,const uint8_t (&mask)[4],uint8_t (&out)[14]) {
  out[0]=uint8_t(0x80|opcode); size_t used=2;
  if(bytes<126) out[1]=uint8_t(0x80|bytes);
  else if(bytes<=65535) { out[1]=0xfe; out[2]=uint8_t(bytes>>8); out[3]=uint8_t(bytes); used=4; }
  else { out[1]=0xff; for(unsigned i=0;i<8;++i) out[2+i]=uint8_t(uint64_t(bytes)>>(56-8*i)); used=10; }
  memcpy(out+used,mask,4); return used+4;
}
inline void maskBytes(uint8_t* data,size_t bytes,const uint8_t (&mask)[4],size_t offset) {
  for(size_t i=0;i<bytes;++i) data[i]^=mask[(offset+i)%4];
}
inline bool validUtf8(const uint8_t* text,size_t bytes) {
  for(size_t i=0;i<bytes;) {
    const uint8_t first=text[i++]; if(first<0x80) continue;
    const unsigned extra=first>=0xc2 && first<=0xdf?1:first>=0xe0 && first<=0xef?2:first>=0xf0 && first<=0xf4?3:4;
    if(extra==4 || extra>bytes-i) return false;
    uint32_t point=first&((1u<<(6-extra))-1);
    for(unsigned j=0;j<extra;++j) { const uint8_t next=text[i++]; if((next&0xc0)!=0x80) return false; point=(point<<6)|(next&0x3f); }
    if(point<(extra==1?0x80u:extra==2?0x800u:0x10000u) || point>0x10ffff || (point>=0xd800 && point<=0xdfff)) return false;
  }
  return true;
}
enum class FrameResult { More,Text,Binary,Ping,Pong,Closed,Invalid };
struct FrameEvent { const uint8_t* data=nullptr; size_t bytes=0; };
class FrameDecoder {
 public:
  FrameDecoder(char* message,size_t capacity):message_(message),capacity_(capacity) {}
  FrameResult feed(uint8_t byte,FrameEvent& event) {
    if(invalid_) return FrameResult::Invalid;
    if(stage_==0) {
      final_=byte&0x80; opcode_=byte&15;
      if((byte&0x70) || (opcode_!=0 && opcode_!=1 && opcode_!=2 && opcode_!=8 && opcode_!=9 && opcode_!=10) ||
         (opcode_>=8 && !final_) || (opcode_==0 && !fragment_) || (opcode_>0 && opcode_<8 && fragment_)) return reject();
      if(opcode_==1 || opcode_==2) { used_=0; messageOpcode_=opcode_; }
      stage_=1; return FrameResult::More;
    }
    if(stage_==1) {
      if(byte&0x80) return reject();
      marker_=byte; length_=0; received_=0;
      if(opcode_>=8 && marker_>125) return reject();
      if(marker_<126) { length_=marker_; return lengthReady(event); }
      extended_=marker_==126?2:8; stage_=2; return FrameResult::More;
    }
    if(stage_==2) {
      if(extended_==8 && (byte&0x80)) return reject();
      length_=(length_<<8)|byte;
      if(--extended_) return FrameResult::More;
      if((marker_==126 && length_<126) || (marker_==127 && length_<=65535)) return reject();
      return lengthReady(event);
    }
    if(opcode_>=8) control_[received_]=byte;
    else message_[used_++]=char(byte);
    if(++received_<length_) return FrameResult::More;
    return complete(event);
  }
 private:
  char* message_; size_t capacity_,used_=0;
  uint8_t control_[125]{},opcode_=0,messageOpcode_=0,marker_=0,extended_=0,stage_=0;
  uint64_t length_=0,received_=0;
  bool final_=false,fragment_=false,invalid_=false;
  FrameResult reject() { invalid_=true; return FrameResult::Invalid; }
  FrameResult lengthReady(FrameEvent& event) {
    if(opcode_<8 && (!message_ || !capacity_ || used_>=capacity_ || length_>=capacity_-used_)) return reject();
    stage_=3; return length_?FrameResult::More:complete(event);
  }
  FrameResult complete(FrameEvent& event) {
    stage_=0;
    if(opcode_>=8) {
      event={control_,size_t(length_)};
      if(opcode_==9) return FrameResult::Ping;
      if(opcode_==10) return FrameResult::Pong;
      if(length_==1) return reject();
      if(length_>=2) {
        const unsigned code=unsigned(control_[0])*256+control_[1];
        if(!((code>=1000 && code<=1014 && code!=1004 && code!=1005 && code!=1006) || (code>=3000 && code<5000)) ||
           !validUtf8(control_+2,size_t(length_-2))) return reject();
      }
      return FrameResult::Closed;
    }
    fragment_=!final_; if(!final_) return FrameResult::More;
    message_[used_]=0; event={reinterpret_cast<const uint8_t*>(message_),used_};
    if(messageOpcode_==1 && !validUtf8(event.data,event.bytes)) return reject();
    return messageOpcode_==1?FrameResult::Text:FrameResult::Binary;
  }
};
using SecureEndpoint=ServerTransport::Endpoint; // Existing protocol helper callers remain compatible.
using ServerTransport::parseEndpoint;
} // namespace Tamagotchi::RealtimeVoice
