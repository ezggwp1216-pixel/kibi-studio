#pragma once

#include "config.h"
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace Tamagotchi {

constexpr int kStatusScalePercent = 135;
constexpr int kStatusTop = 16;

// Status bar glyphs: digits 0-9, colon and dash (5x7).
inline constexpr uint8_t kStatusFontRows[12][7] = {
  {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},
  {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},
  {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},
  {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E},
  {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02},
  {0x1F,0x10,0x10,0x1E,0x01,0x01,0x1E},
  {0x0E,0x10,0x10,0x1E,0x11,0x11,0x0E},
  {0x1F,0x01,0x02,0x04,0x08,0x08,0x08},
  {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E},
  {0x0E,0x11,0x11,0x0F,0x01,0x01,0x0E},
  {0x00,0x04,0x04,0x00,0x04,0x04,0x00},
  {0x00,0x00,0x00,0x0E,0x00,0x00,0x00}
};
// Three ascending signal bars share a baseline within a 15x12 icon.
inline constexpr uint8_t kStatusWifiBarHeights[3] = {4, 8, 12};
inline constexpr uint32_t kStatusBatteryRows[12] = {
  0x007FFFFE,0x00800001,0x00800001,0x03800001,0x03800001,0x03800001,
  0x03800001,0x03800001,0x03800001,0x00800001,0x00800001,0x007FFFFE
};
constexpr int kBatterySectionCount = 3;
constexpr int kBatteryFillWidth = 20;
constexpr uint32_t kBatteryAnimationStepMs = 500;


// Shared design assets: backgrounds, character frames, fonts and icons.
// Fixed dimensions for every background image in this project.
constexpr int kBackgroundWidth = 240;
constexpr int kBackgroundHeight = 888;
constexpr size_t kBackgroundPixelCount =
    static_cast<size_t>(kBackgroundWidth) * kBackgroundHeight;

// Compressed image stored in the LittleFS data partition.
inline constexpr char kBackgroundPath[] = "/background.jpg";

inline constexpr char kCharacterPath[] = "/antimage.agf";
inline constexpr char kCharacterJumpPath[] = "/antimage_jump.agf";
constexpr uint32_t kCharacterJumpIntervalMs = 20000;
constexpr int kCharacterWidth = 256;
constexpr int kCharacterHeight = 256;
constexpr int kCharacterFrameCount = 9;
constexpr uint32_t kCharacterFrameDurationMs = 130;
constexpr int kCharacterX = -8;
constexpr int kCharacterY = 16;  // Position in the scrollable background.
constexpr size_t kCharacterPixelCount = size_t(kCharacterWidth) * kCharacterHeight;

// The first card begins 10px below the initial viewport.
// Menu geometry in the scrollable scene. The final card has 24px below it.
constexpr int kMenuTop = 306, kMenuLeft = 24, kMenuWidth = 192;
constexpr int kMenuCardHeight = 48, kMenuStride = 60, kMenuRadius = 12;
constexpr int kMenuBottomPadding = 24, kMenuVisibleTop = 44;
constexpr int kMenuScrollTarget = kMenuTop - 48;
constexpr int kDownButtonX = 98, kDownButtonY = 264;
constexpr int kDownButtonWidth = 44, kDownButtonHeight = 24;
constexpr uint16_t kMenuCardColor = 0x18C8, kMenuPressedColor = 0x49D1;
constexpr uint16_t kMenuBorderColor = 0x9BFA, kMenuTextColor = 0xFFFF;

// Compact 5x7 Latin A-Z and Cyrillic А-Я (+Ё) for pixel lettering.
inline constexpr uint8_t kMenuLatinRows[26][7] = {
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
 {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
 {14,17,16,23,17,17,14},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},
 {7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
 {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},
 {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
 {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
 {17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
 {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
};
inline constexpr uint8_t kMenuCyrillicRows[33][7] = {
 {14,17,17,31,17,17,17},{31,16,16,30,17,17,30},{30,17,17,30,17,17,30},
 {31,16,16,16,16,16,16},{6,10,10,10,10,31,17},{31,16,16,30,16,16,31},
 {21,21,14,4,14,21,21},{14,17,1,6,1,17,14},{17,17,19,21,25,17,17},
 {10,4,17,19,21,25,17},{17,18,20,24,20,18,17},{7,9,9,9,9,9,17},
 {17,27,21,21,17,17,17},{17,17,17,31,17,17,17},{14,17,17,17,17,17,14},
 {31,17,17,17,17,17,17},{30,17,17,30,16,16,16},{14,17,16,16,16,17,14},
 {31,4,4,4,4,4,4},{17,17,17,15,1,17,14},{4,14,21,21,14,4,4},
 {17,17,10,4,10,17,17},{18,18,18,18,18,31,1},{17,17,17,15,1,1,1},
 {21,21,21,21,21,21,31},{21,21,21,21,21,31,1},{24,8,8,14,9,9,14},
 {17,17,17,25,21,21,25},{16,16,16,30,17,17,30},{14,17,1,7,1,17,14},
 {18,21,21,29,21,21,18},{15,17,17,15,5,9,17},{10,0,31,16,30,16,31}
};
// Lowercase text glyphs preserve the transcript's original casing.
inline constexpr uint8_t kTextLatinLowerRows[26][7] = {
 {0,0,14,1,15,17,15},{16,16,30,17,17,17,30},{0,0,14,16,16,17,14},
 {1,1,15,17,17,17,15},{0,0,14,17,31,16,14},{6,9,8,28,8,8,8},
 {0,15,17,17,15,1,14},{16,16,30,17,17,17,17},{4,0,12,4,4,4,14},
 {2,0,6,2,2,18,12},{16,16,18,20,24,20,18},{12,4,4,4,4,4,14},
 {0,0,26,21,21,21,21},{0,0,30,17,17,17,17},{0,0,14,17,17,17,14},
 {0,30,17,17,30,16,16},{0,15,17,17,15,1,1},{0,0,22,25,16,16,16},
 {0,0,15,16,14,1,30},{8,8,28,8,8,9,6},{0,0,17,17,17,19,13},
 {0,0,17,17,17,10,4},{0,0,17,17,21,21,10},{0,0,17,10,4,10,17},
 {0,17,17,17,15,1,14},{0,0,31,2,4,8,31}
};
inline constexpr uint8_t kTextCyrillicLowerRows[33][7] = {
 {0,0,14,1,15,17,15},{3,12,16,30,17,17,14},{0,0,30,17,30,17,30},
 {0,0,31,16,16,16,16},{0,0,6,10,10,31,17},{0,0,14,17,31,16,14},
 {0,0,21,14,4,14,21},{0,0,14,1,6,1,14},{0,0,17,19,21,25,17},
 {10,4,17,19,21,25,17},{0,0,17,18,28,18,17},{0,0,7,9,9,9,17},
 {0,0,17,27,21,17,17},{0,0,17,17,31,17,17},{0,0,14,17,17,17,14},
 {0,0,31,17,17,17,17},{0,30,17,17,30,16,16},{0,0,14,17,16,17,14},
 {0,0,31,4,4,4,4},{0,17,17,17,15,1,14},{4,14,21,21,14,4,4},
 {0,0,17,10,4,10,17},{0,0,18,18,18,31,1},{0,0,17,17,15,1,1},
 {0,0,21,21,21,21,31},{0,0,21,21,21,31,1},{0,0,24,8,14,9,14},
 {0,0,17,17,25,21,25},{0,0,16,16,30,17,30},{0,0,14,17,7,17,14},
 {0,0,18,21,29,21,18},{0,0,15,17,15,5,9},{10,0,14,17,31,16,14}
};
inline constexpr uint32_t kTextPunctuationCodes[] = {'.',',','!', '?',':',';','(',')','/','+',0x2026,0x2014,0x00AB,0x00BB,'%',0x00B0,0x2248,0x00B7,0x2019};
inline constexpr uint8_t kTextPunctuationRows[][7] = {
 {0,0,0,0,0,12,12},{0,0,0,0,4,4,8},{4,4,4,4,4,0,4},{14,17,1,2,4,0,4},
 {0,4,4,0,4,4,0},{0,4,4,0,4,4,8},{2,4,8,8,8,4,2},{8,4,2,2,2,4,8},
 {1,2,2,4,8,8,16},{0,4,4,31,4,4,0},{0,0,0,0,0,0,21},{0,0,0,31,0,0,0},
 {0,0,10,20,10,0,0},{0,0,10,5,10,0,0},
 {25,26,2,4,8,11,19},{14,17,17,14,0,0,0},{0,0,9,22,0,9,22},{0,0,0,4,0,0,0},{4,4,8,0,0,0,0}
};
constexpr int kNotesListTop=92, kNotesCardHeight=76, kNotesCardStride=88;
constexpr int kNotesBodyTop=140, kNotesBottomPadding=24;

// Theme data is selected before application startup. No runtime theme editor or
// settings format is introduced; a new style registers another immutable value.
// The registry copies each Theme object. Its strings, PixelFont and glyph tables
// are borrowed: keep those pointees immutable and alive for the entire sketch.
// Declare those assets with static storage; the Theme object itself may be local.
struct PixelFont {
  const uint8_t (*digits)[7];
  const uint8_t (*latinUpper)[7];
  const uint8_t (*cyrillicUpper)[7];
  const uint8_t (*latinLower)[7];
  const uint8_t (*cyrillicLower)[7];
};
inline constexpr PixelFont kPixelFont{kStatusFontRows,kMenuLatinRows,kMenuCyrillicRows,kTextLatinLowerRows,kTextCyrillicLowerRows};
struct MenuLayout { int top,left,width,height,stride,radius; };
struct Theme {
  const char* id;
  const char* backgroundPath;
  const char* chargeAnimationPath;
  const char* jumpAnimationPath;
  const PixelFont* font;
  int characterX,characterY,statusTop,statusScale;
  MenuLayout menu;
  int downX,downY,downWidth,downHeight;
  uint16_t card,pressed,border,text,muted,charging,lowBattery,overlay;
};
inline constexpr Theme kSakuraTheme{
  "sakura",kBackgroundPath,kCharacterPath,kCharacterJumpPath,&kPixelFont,
  kCharacterX,kCharacterY,kStatusTop,kStatusScalePercent,
  {kMenuTop,kMenuLeft,kMenuWidth,kMenuCardHeight,kMenuStride,kMenuRadius},
  kDownButtonX,kDownButtonY,kDownButtonWidth,kDownButtonHeight,
  kMenuCardColor,kMenuPressedColor,kMenuBorderColor,kMenuTextColor,0x528A,0x7FE0,0xFBE0,0x0843
};
namespace ThemeDetail {
inline Theme registry[4]{kSakuraTheme};
inline int count=1;
inline const Theme* selected=&registry[0];
inline bool locked=false;
}
inline const Theme& theme() { return *ThemeDetail::selected; }
inline bool validTheme(const Theme& value) {
  const auto& m=value.menu;
  return value.id && *value.id && value.backgroundPath && *value.backgroundPath &&
      value.chargeAnimationPath && *value.chargeAnimationPath && value.jumpAnimationPath && *value.jumpAnimationPath &&
      value.font && value.font->digits && value.font->latinUpper && value.font->cyrillicUpper &&
      value.font->latinLower && value.font->cyrillicLower &&
      value.characterX>=-1024 && value.characterX<=kScreenWidth && value.characterY>=-1024 && value.characterY<=kBackgroundHeight &&
      value.statusTop>=0 && value.statusTop<=24 && value.statusScale>=90 && value.statusScale<=160 &&
      m.top>=kScreenHeight && m.top<=kBackgroundHeight && m.left>=0 && m.left<=kScreenWidth && m.width>=120 && m.width<=kScreenWidth-m.left &&
      m.height>=32 && m.height<=80 && m.stride>=m.height && m.stride<=100 && m.radius>=0 && m.radius<=m.height/2 &&
      value.downX>=0 && value.downX<=kScreenWidth && value.downWidth>=24 && value.downWidth<=kScreenWidth-value.downX &&
      value.downY>=44 && value.downY<=kScreenHeight && value.downHeight>=16 && value.downHeight<=kScreenHeight-value.downY;
}
inline bool registerTheme(const Theme& value) {
  if (ThemeDetail::locked || !validTheme(value) || ThemeDetail::count>=4) return false;
  for (int i=0;i<ThemeDetail::count;++i) if (!strcmp(ThemeDetail::registry[i].id,value.id)) return false;
  ThemeDetail::registry[ThemeDetail::count++]=value; return true;
}
inline bool selectTheme(const char* id) {
  if (ThemeDetail::locked || !id) return false;
  for (int i=0;i<ThemeDetail::count;++i) if (!strcmp(ThemeDetail::registry[i].id,id)) {
    ThemeDetail::selected=&ThemeDetail::registry[i]; return true;
  }
  return false;
}
inline void lockTheme() { ThemeDetail::locked=true; }

static_assert(kBackgroundPixelCount == 213120, "Background must be 240x888");

}  // namespace Tamagotchi
