#pragma once
#include "reminder.h"
#include "display_touch.h"
#include "menu.h"

namespace Tamagotchi::Notifications {
struct Delivery { char id[20]{};Reminders::Request reminder; };
inline bool validId(const char* id) {
  if(!id || !*id || *id=='0' || strnlen(id,20)>19) return false;
  uint64_t value=0;
  for(const char* p=id;*p;++p) { if(*p<'0'||*p>'9') return false;const unsigned digit=unsigned(*p-'0');
    if(value>(uint64_t(INT64_MAX)-digit)/10) return false;value=value*10+digit; }
  return value>0;
}
inline bool valid(const Delivery& value) { return validId(value.id)&&Reminders::valid(value.reminder); }
inline bool same(const Delivery& a,const Delivery& b) { return !strcmp(a.id,b.id)&&Reminders::same(a.reminder,b.reminder); }
inline bool parse(JsonVariantConst object,Delivery& out) {
  out=Delivery{};
  if(!object.is<JsonObjectConst>() || !Reminders::field(object,"id",out.id,sizeof out.id) || !validId(out.id) ||
     !Reminders::field(object,"reminder_id",out.reminder.id,sizeof out.reminder.id) ||
     !Reminders::field(object,"title",out.reminder.title,sizeof out.reminder.title) ||
     !Reminders::field(object,"description",out.reminder.description,sizeof out.reminder.description,true) ||
     !object["due_at"].is<int64_t>() || object["due_at"].is<bool>()) return false;
  out.reminder.dueAt=object["due_at"].as<int64_t>();return valid(out);
}
class Store {
 public:
  bool begin(const char* path) {
    healthy_=false;if(!path || strnlen(path,sizeof path_)>=sizeof path_) return false;strcpy(path_,path);
    Record loaded;const auto result=Reminders::readRecord(path_,loaded);
    if(result==Reminders::Load::Error || (result==Reminders::Load::Ok && (loaded.state<1 || loaded.state>3 || !valid(loaded.delivery)))) return false;
    record_=result==Reminders::Load::Ok?loaded:Record{};healthy_=true;return true;
  }
  bool offer(const Delivery& value) {
    if(!healthy_ || !valid(value)) return false;
    if(record_.state) {
      // Server IDs follow creation order; a lower ID can become due later.
      // Only the exact receipt is a replay. A different event waits for ACK.
      if(!strcmp(value.id,record_.delivery.id)) return same(record_.delivery,value);
      if(record_.state!=3) return false;
    }
    Record next{};next.delivery=value;next.state=1;return commit(next);
  }
  bool pending() const { return healthy_&&record_.state==1; }
  bool ackPending() const { return healthy_&&record_.state==2; }
  const Delivery& delivery() const { return record_.delivery; }
  bool dismiss(const char* id) {
    if(!healthy_ || !id || strcmp(record_.delivery.id,id) || record_.state!=1) return false;
    auto next=record_;next.state=2;return commit(next);
  }
  bool acknowledged(const char* id) {
    if(!ackPending() || !id || strcmp(id,record_.delivery.id)) return false;
    auto next=record_;next.state=3;return commit(next);
  }
 private:
  struct Record { Delivery delivery;uint8_t state=0; } record_;
  char path_[192]{};bool healthy_=false;
  bool commit(const Record& next) { if(!Reminders::writeRecord(path_,next)) return false;record_=next;return true; }
};
enum class Input { Down,Move,Up,Cancel };
class View {
 public:
  bool bind(const Delivery& delivery,bool allowed,bool pointerDown) {
    bool changed=false;
    if(strcmp(id_,delivery.id)) {
      strcpy(id_,delivery.id);scroll_.setRange(scrollLimit(delivery),true);gesture_.cancel();interactive_=ownsTouch_=false;changed=visible_;
    }
    const bool next=allowed && (visible_ || !pointerDown);
    if(visible_!=next) {visible_=next;scroll_.cancel();gesture_.cancel();interactive_=ownsTouch_=false;changed=true;}
    return changed;
  }
  bool visible() const { return visible_; }
  void presented(uint32_t at) { if(visible_ && !interactive_) {presentedAt_=at;interactive_=true;} }
  int offset() const { return scroll_.offsetY(); }
  bool pressed() const { return gesture_.pressedTarget()==0; }
  bool tick(uint32_t now) { const int before=offset();if(visible_) scroll_.tick(now);return before!=offset(); }
  bool input(Input kind,int x,int y,uint32_t at) {
    if(!visible_) return false;
    if(kind==Input::Down) {
      ownsTouch_=interactive_ && int32_t(at-presentedAt_)>=0;
      if(!ownsTouch_) return false;
    } else if(!ownsTouch_) return false;
    switch(kind) {
      case Input::Down:
        gesture_.begin(x,y,dismissHit(x,y)?0:-1);
        scrolling_=x>=28&&x<212&&y>=78&&y<230;
        if(scrolling_) scroll_.begin(y,at);
        break;
      case Input::Move: gesture_.move(x,y);if(scrolling_) scroll_.move(y,at);break;
      case Input::Up: {
        if(scrolling_) scroll_.release(at);scrolling_=false;ownsTouch_=false;
        return gesture_.release(x,y,dismissHit(x,y)?0:-1)==0;
      }
      case Input::Cancel:gesture_.cancel();scroll_.cancel();scrolling_=false;ownsTouch_=false;break;
    }
    return false;
  }
  static int descriptionTop(const Delivery& delivery) { return 80+Ui::textLineCount(delivery.reminder.title,14)*Ui::textLineHeight(delivery.reminder.title)+12; }
  static int scrollLimit(const Delivery& delivery) {
    const int length=descriptionTop(delivery)-80+(*delivery.reminder.description?
        Ui::textLineCount(delivery.reminder.description,28)*Ui::textLineHeight(delivery.reminder.description,12,1):0);
    return length>150?length-150:0;
  }
 private:
  char id_[20]{};bool visible_=false,scrolling_=false,interactive_=false,ownsTouch_=false;uint32_t presentedAt_=0;TapGesture gesture_;DisplayTouchDetail::VerticalScroll scroll_;
  static bool dismissHit(int x,int y) { return x>=48&&x<192&&y>=240&&y<272; }
};
inline void draw(uint16_t* frame,int width,int height,const Delivery& delivery,const View& view) {
  if(!frame||width<=0||height<=0||!view.visible()) return;
  for(int y=44;y<height;++y) for(int x=0;x<width;++x)
    if(Ui::roundedPixel(x,y,width,height,kScreenCornerRadius)) Ui::pixel(frame,width,height,x,y,theme().overlay,145);
  Ui::box(frame,width,height,20,62,200,220,16,false,44);
  // Both fields retain every valid character; long titles scroll with the body.
  Ui::wrappedText(frame,width,height,delivery.reminder.title,36,80-view.offset(),14,18,2,80,230);
  Ui::wrappedText(frame,width,height,delivery.reminder.description,36,View::descriptionTop(delivery)-view.offset(),28,12,1,80,230);
  Ui::box(frame,width,height,48,240,144,32,10,view.pressed(),44);
  Ui::text(frame,width,height,"Close",48+(144-Ui::textWidth("Close"))/2,
      Ui::centeredTextTop("Close",240,32),2,theme().text,240,272);
  const int limit=View::scrollLimit(delivery);
  if(limit>0) {
    constexpr int track=150;const int thumb=track*track/(track+limit)>10?track*track/(track+limit):10;
    const int top=80+int(int64_t(view.offset())*(track-thumb)/limit);
    for(int y=top;y<top+thumb;++y) for(int x=208;x<210;++x) Ui::pixel(frame,width,height,x,y,theme().muted);
  }
}
} // namespace Tamagotchi::Notifications
