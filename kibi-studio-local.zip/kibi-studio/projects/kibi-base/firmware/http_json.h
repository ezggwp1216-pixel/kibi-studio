#pragma once

#include <ArduinoJson.h>
#include <stddef.h>
#include <stdint.h>
#include <cstring>
#include "audio_file.h"
#include "network_gate.h"
#include "tls_diagnostics.h"
#include "server_endpoint.h"

namespace Tamagotchi::Https {
// 32 KiB UTF-8 dictation can expand when JSON-escaped, plus routing context.
inline constexpr size_t kMaximumRequestBytes=256*1024;
// Plain HTTP is an explicit, unauthenticated GET exception for the public
// forecast endpoint. Credentialed/external API requests retain HTTPS defaults.
inline bool jsonRequestAllowed(bool secure,const char* url,const char* bearer,const char* post) {
  if(!url || std::strpbrk(url,"\r\n\t ")) return false;
  if(secure) return ServerTransport::usesTls(url);
  constexpr char forecast[]="http://api.open-meteo.com/v1/forecast?";
  return !bearer && !post && !std::strncmp(url,forecast,sizeof forecast-1);
}
#ifdef ARDUINO
class PsramJsonAllocator final : public ArduinoJson::Allocator {
 public:
  void* allocate(size_t bytes) override { return heap_caps_malloc(bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT); }
  void deallocate(void* pointer) override { free(pointer); }
  void* reallocate(void* pointer,size_t bytes) override { return heap_caps_realloc(pointer,bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT); }
};
#endif


// Transferred bytes and completed TLS renew the idle limit; socket polling does not.
// Unsigned differences preserve both limits across millis() rollover.
class RequestDeadline {
 public:
  explicit RequestDeadline(uint32_t now,uint32_t maximum=90000):started_(now),progressAt_(now),maximum_(maximum) {}
  bool expired(uint32_t now) {
    timedOut_ |= uint32_t(now-started_)>=maximum_ || uint32_t(now-progressAt_)>=8000;
    return timedOut_;
  }
  void progress(uint32_t now,size_t bytes) {
    if(bytes && !expired(now)) progressAt_=now;
  }
  void transportReady(uint32_t now) {
    timedOut_|=uint32_t(now-started_)>=maximum_;
    progressAt_=now;
  }
  bool timedOut() const { return timedOut_; }
  bool afterConnect(bool connected,uint32_t now) {
    if(!connected) return false;
    // SDK's handshake uses raw TLS BIO rather than wrapper read/write calls.
    // Only the response-idle clock renews; the total request cap still applies.
    transportReady(now);
    return !expired(now);
  }
 private:
  uint32_t started_,progressAt_,maximum_;
  bool timedOut_=false;
};
}  // namespace Tamagotchi::Https

#ifdef ARDUINO
#include <Arduino.h>
#include <HTTPClient.h>
#include <NetworkClientSecure.h>
#include <esp_heap_caps.h>

namespace Tamagotchi::Https {

// HTTPClient 3.3.12 can keep polling an open response socket indefinitely after
// a body read times out. Stop the transport itself so its chunk/body loops exit.
// Existing connect/TLS timeouts also bound an individual blocking transport call.
template<class Transport,bool Secure> class BasicDeadlineClient final : public Transport {
 public:
  static constexpr bool kSecure=Secure;
  using Continue=bool(*)();
  explicit BasicDeadlineClient(uint32_t maximum=90000,NetworkGate::Priority priority=NetworkGate::Priority::Background,
                          Continue keepRunning=nullptr)
      :deadline_(millis(),maximum),gate_(priority,priority==NetworkGate::Priority::Voice?maximum:0),keepRunning_(keepRunning),priority_(priority) {
    if(gate_) deadline_.transportReady(millis());
  }
  // Members are destroyed before the base class. Close TLS explicitly before
  // the lease releases another task, including an early HTTP error/timeout.
  ~BasicDeadlineClient() override { stop(); }
  int connect(IPAddress ip,uint16_t port) override {
    return observedConnect([&] { return Transport::connect(ip,port); });
  }
  int connect(IPAddress ip,uint16_t port,int32_t timeout) override {
    return observedConnect([&] { return Transport::connect(ip,port,timeout); });
  }
  int connect(const char* host,uint16_t port) override {
    return observedConnect([&] { return Transport::connect(host,port); });
  }
  int connect(const char* host,uint16_t port,int32_t timeout) override {
    return observedConnect([&] { return Transport::connect(host,port,timeout); });
  }
  void stop() override {
    if constexpr(Secure) {
      TlsDiagnostics::Context::Closing closing(tlsDiagnostics_);
      Transport::stop();
    } else Transport::stop();
  }
  // Keep Stream and socket timeouts in milliseconds, including after connect()
  // overwrites ESP32 NetworkClient's separate connection/socket timeout field.
  void setTimeout(unsigned long milliseconds) {
    ioTimeoutMs_=uint32_t(milliseconds);
    ServerTransport::configureIoTimeout(static_cast<Transport&>(*this),ioTimeoutMs_);
    if constexpr(Secure) this->sslclient->socket_timeout=ioTimeoutMs_;
  }
  void setCACert(const char* ca) { if constexpr(Secure) Transport::setCACert(ca); }
  void useBuiltinCACertBundle() { if constexpr(Secure) Transport::useBuiltinCACertBundle(); }
  void setHandshakeTimeout(unsigned long seconds) { if constexpr(Secure) Transport::setHandshakeTimeout(seconds); }
  int lastError(char* buffer,size_t capacity) {
    if constexpr(Secure) return Transport::lastError(buffer,capacity);
    else { if(capacity) buffer[0]=0; return 0; }
  }
  uint8_t connected() override { return alive() ? Transport::connected() : 0; }
  int available() override { return alive() ? Transport::available() : 0; }
  int peek() override { return alive() ? Transport::peek() : -1; }
  int read() override { uint8_t value; return read(&value,1)>0 ? value : -1; }
  int read(uint8_t* out,size_t bytes) override {
    if(!alive()) return -1;
    const int received=Transport::read(out,bytes);
    if(received>0) deadline_.progress(millis(),size_t(received));
    return received;
  }
  size_t readBytes(char* out,size_t bytes) override {
    size_t used=0;
    while(used<bytes && alive()) {
      const int received=read(reinterpret_cast<uint8_t*>(out)+used,bytes-used);
      if(received>0) used+=size_t(received);
      else if(!connected()) break;
      else delay(1);
    }
    return used;
  }
  size_t readBytes(uint8_t* out,size_t bytes) override {
    return readBytes(reinterpret_cast<char*>(out),bytes);
  }
  size_t write(uint8_t value) override { return write(&value,1); }
  size_t write(const uint8_t* data,size_t bytes) override {
    if(!alive()) return 0;
    const size_t sent=Transport::write(data,bytes);
    deadline_.progress(millis(),sent);
    return sent;
  }
  bool timedOut() const { return deadline_.timedOut(); }
 private:
  RequestDeadline deadline_;
  NetworkGate::Lease gate_;
  Continue keepRunning_;
  NetworkGate::Priority priority_;
  bool stopped_=false;
  uint32_t ioTimeoutMs_=8000;
  TlsDiagnostics::Context tlsDiagnostics_{TlsDiagnostics::tracker,TlsDiagnostics::clock,TlsDiagnostics::internalHeap};
  template<class Connect> int observedConnect(Connect connect) {
    if(!alive()) return 0;
    if constexpr(Secure) {
      TlsDiagnostics::Context::Attempt attempt(tlsDiagnostics_);
      // Core timeout overloads dispatch virtually to the simpler overloads.
      // Their outer call alone owns the handshake scope/deadline/diagnostics.
      if(!attempt.outer()) { const int connected=connect(); attempt.finish(connected!=0); return connected; }
      NetworkGate::TlsHandshakeScope idle;
      const int connected=finishConnect(connect());
      attempt.finish(connected!=0);
      return connected;
    } else return finishConnect(connect());
  }
  int finishConnect(int connected) {
    if(deadline_.afterConnect(connected!=0,millis()) && alive()) {
      setTimeout(ioTimeoutMs_);
      if constexpr(!Secure) ServerTransport::finishPlainConnect(static_cast<Transport&>(*this),connected);
      return connected;
    }
    stop();
    return 0;
  }
  bool alive() {
    if(!gate_ || stopped_) return false;
    if(NetworkGate::gate.allowsTransport(priority_) && (!keepRunning_ || keepRunning_()) &&
       !deadline_.expired(millis())) return true;
    if(!stopped_) {
      stopped_=true;
      stop();
      // Stream::readStringUntil() owns a polling loop too. Its next failed read
      // must return promptly after this transport has reached its deadline.
      Stream::setTimeout(1);
    }
    return false;
  }
};
using DeadlineClient=BasicDeadlineClient<NetworkClientSecure,true>;
using PlainDeadlineClient=BasicDeadlineClient<NetworkClient,false>;

// A bounded sink also used by speech transcription. HTTPClient handles chunked
// transfer framing; neither parser nor caller can accept a partial response.
class BoundedStream final : public Stream {
 public:
  BoundedStream(char* out,size_t capacity):out_(out),capacity_(capacity) { if(capacity_) out_[0]=0; }
  int available() override { return 0; }
  int peek() override { return -1; }
  int read() override { return -1; }
  void flush() override {}
  size_t write(uint8_t value) override { return write(&value,1); }
  size_t write(const uint8_t* data,size_t bytes) override {
    if(!capacity_ || bytes>capacity_-1-used_ || memchr(data,0,bytes)) { overflow=true; return 0; }
    memcpy(out_+used_,data,bytes); used_+=bytes; out_[used_]=0; return bytes;
  }
  size_t size() const { return used_; }
  bool overflow=false;
 private:
  char* out_; size_t capacity_,used_=0;
};

template<class Client=DeadlineClient>
inline bool jsonRequest(const char* url,const char* bearer,const char* post,
                        JsonDocument& output,const JsonDocument& filter,char* error,size_t capacity,
                        NetworkGate::Priority priority=NetworkGate::Priority::Voice,uint32_t maximum=90000,
                        typename Client::Continue keepRunning=nullptr) {
  auto fail=[&](const char* message) { if(capacity) snprintf(error,capacity,"%s",message); return false; };
  output.clear();
  if(!jsonRequestAllowed(Client::kSecure,url,bearer,post)) return fail("Invalid service address.");
  constexpr size_t responseMaximum=16384;
  auto* buffer=static_cast<char*>(heap_caps_malloc(responseMaximum+1,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(!buffer) return fail("Not enough memory for the service response.");
  struct Release { char* data; ~Release() { free(data); } } release{buffer};
  Client client(maximum,priority,keepRunning);
  // A background forecast yields to voice between transport calls. Keep each
  // indivisible connect/TLS/read call short as well; voice retains its defaults.
  const uint16_t timeout=priority==NetworkGate::Priority::Background?3000:8000;
  client.useBuiltinCACertBundle(); client.setHandshakeTimeout(timeout/1000); client.setTimeout(timeout);
  HTTPClient http;
  http.setUserAgent("Tamagotchi/1.0"); http.setConnectTimeout(timeout<6000?timeout:6000); http.setTimeout(timeout); http.setReuse(false);
  if(!http.begin(client,url)) return fail("Could not connect to the service.");
  http.addHeader("Accept","application/json"); http.addHeader("Accept-Encoding","identity");
  if(bearer) http.addHeader("Authorization",String("Bearer ")+bearer);
  int status=0;
  if(post) {
    http.addHeader("Content-Type","application/json");
    // HTTPClient's legacy signature is mutable, but it only reads the payload.
    status=http.POST(reinterpret_cast<uint8_t*>(const_cast<char*>(post)),strlen(post));
  }
  else status=http.GET();
  if(status!=200) {
    http.end();
    if(status==401 || status==403) return fail("Access denied. Check your settings.");
    if(status==429) return fail("Service limit reached. Try again later.");
    if(status<0) return fail("No service response. Check your connection.");
    return fail("Service unavailable. Try again later.");
  }
  BoundedStream response(buffer,responseMaximum+1);
  const bool tooLarge=http.getSize()>int(responseMaximum);
  const int read=tooLarge ? -1 : http.writeToStream(&response);
  http.end();
  if(client.timedOut()) return fail("The service response timed out.");
  if(tooLarge || response.overflow || read<0) return fail("The service response was too large or interrupted.");
  // A const input makes ArduinoJson own its strings before this scratch buffer
  // is released; mutable input would leave dangling zero-copy pointers.
  const auto parsed=deserializeJson(output,static_cast<const char*>(buffer),response.size(),DeserializationOption::Filter(filter),DeserializationOption::NestingLimit(12));
  if(parsed || output.overflowed()) { output.clear(); return fail("The service returned an unsupported response."); }
  return true;
}
inline bool getJson(const char* url,JsonDocument& output,const JsonDocument& filter,char* error,size_t capacity,
                    NetworkGate::Priority priority=NetworkGate::Priority::Voice,uint32_t maximum=90000,
                    DeadlineClient::Continue keepRunning=nullptr) {
  return jsonRequest(url,nullptr,nullptr,output,filter,error,capacity,priority,maximum,keepRunning);
}
inline bool postJson(const char* url,const char* bearer,const JsonDocument& request,
                     JsonDocument& output,const JsonDocument& filter,char* error,size_t capacity) {
  if(measureJson(request)>kMaximumRequestBytes || request.overflowed()) {
    if(capacity) snprintf(error,capacity,"The question is too long."); return false;
  }
  BoundedText body;
  const size_t bytes=measureJson(request);
  if(!body.reserve(bytes+1) || serializeJson(request,body.data(),body.capacity())!=bytes) {
    if(capacity) snprintf(error,capacity,"Not enough memory for the request."); return false;
  }
  return jsonRequest(url,bearer,body.data(),output,filter,error,capacity);
}
}  // namespace Tamagotchi::Https
namespace Tamagotchi::Http {
inline bool getPublicForecastJson(const char* url,JsonDocument& output,const JsonDocument& filter,
                                 char* error,size_t capacity,
                                 NetworkGate::Priority priority=NetworkGate::Priority::Background,
                                 uint32_t maximum=20000,Https::PlainDeadlineClient::Continue keepRunning=nullptr) {
  return Https::jsonRequest<Https::PlainDeadlineClient>(
      url,nullptr,nullptr,output,filter,error,capacity,priority,maximum,keepRunning);
}
} // namespace Tamagotchi::Http
#endif
