#pragma once

#include "vietnamese_font_data.h"

namespace Tamagotchi {
namespace VietnameseFont {
static_assert(sizeof(Glyph)==42 && sizeof(Mapping)==4,"Keep Vietnamese font tables compact in flash");
inline const Glyph* glyph(uint32_t code) {
  size_t low=0,high=sizeof(kGlyphs)/sizeof(*kGlyphs);
  while(low<high) {
    const size_t middle=low+(high-low)/2;
    if(kGlyphs[middle].code<code) low=middle+1; else high=middle;
  }
  return low<sizeof(kGlyphs)/sizeof(*kGlyphs) && kGlyphs[low].code==code?&kGlyphs[low]:nullptr;
}
template<size_t N> inline uint16_t mapped(const Mapping (&values)[N],uint32_t key) {
  size_t low=0,high=N;
  while(low<high) {
    const size_t middle=low+(high-low)/2;
    if(values[middle].first<key) low=middle+1; else high=middle;
  }
  return low<N && values[low].first==key?values[low].second:0;
}
inline bool isVietnamese(uint32_t code) {
  return code==0x110 || code==0x111 || (code>127 && mapped(kByCode,code));
}
} // namespace VietnameseFont

namespace VietnameseText {
// The optional end makes public substring rendering safe even when a caller
// ends the range inside a multi-byte sequence. Invalid bytes remain visible as
// individual replacement cells; no normalization mutates the stored string.
inline uint32_t nextCodepoint(const char*& text,const char* end=nullptr) {
  if(!text || (end && text>=end)) return 0;
  const auto first=uint8_t(*text++);
  if(first<128) return first;
  const int extra=first>=0xF0 && first<=0xF4?3:(first>=0xE0 && first<=0xEF?2:(first>=0xC2 && first<=0xDF?1:0));
  if(!extra) return '?';
  uint32_t code=first&((1u<<(6-extra))-1);
  const char* cursor=text;
  for(int i=0;i<extra;++i) {
    if(end && cursor>=end) return '?';
    const auto part=uint8_t(*cursor);
    if((part&0xC0)!=0x80) return '?';
    code=(code<<6)|(part&63);
    ++cursor;
  }
  if((extra==1 && code<0x80) || (extra==2 && code<0x800) || (extra==3 && code<0x10000) ||
     code>0x10FFFF || (code>=0xD800 && code<=0xDFFF)) return '?';
  text=cursor;
  return code;
}
inline uint32_t next(const char*& text,const char* end=nullptr) {
  uint32_t code=nextCodepoint(text,end);
  uint16_t key=VietnameseFont::mapped(VietnameseFont::kByCode,code);
  while(key && text && (!end || text<end) && *text) {
    const char* candidate=text;
    const uint32_t mark=nextCodepoint(candidate,end);
    uint16_t shape=0,tone=0;
    switch(mark) {
      case 0x302: shape=1; break;
      case 0x306: shape=2; break;
      case 0x31B: shape=3; break;
      case 0x300: tone=1; break;
      case 0x301: tone=2; break;
      case 0x303: tone=3; break;
      case 0x309: tone=4; break;
      case 0x323: tone=5; break;
      default: return code;
    }
    // A duplicate/unsupported mark is left for the next rendered cell. This
    // prevents accent loss on malformed sequences or non-Vietnamese text.
    if((shape && (key&24)) || (tone && (key&7))) return code;
    const uint16_t combined=key|(shape<<3)|tone;
    const uint16_t composed=VietnameseFont::mapped(VietnameseFont::kByKey,combined);
    if(!composed) return code;
    key=combined; code=composed; text=candidate;
  }
  return code;
}
} // namespace VietnameseText
} // namespace Tamagotchi
