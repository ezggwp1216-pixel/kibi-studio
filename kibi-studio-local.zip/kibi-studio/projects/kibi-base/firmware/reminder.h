#pragma once
#include "config.h"
#include "audio_file.h"
#include "weather.h"
#include <ArduinoJson.h>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctime>
#include <new>

namespace Tamagotchi::Reminders {
constexpr size_t kTitleBytes=128,kDescriptionBytes=2048,kOutboxCapacity=16;
constexpr int64_t kHorizon=366LL*86400,kTimezoneSeconds=7*3600;
struct Request {
  char id[33]{},title[kTitleBytes+1]{},description[kDescriptionBytes+1]{};
  int64_t dueAt=0;
};
inline bool validText(const char* text,size_t maximum,bool empty=false) {
  if(!text) return false;
  const size_t bytes=strnlen(text,maximum+1);
  if(bytes>maximum) return false;
  if(!bytes) return empty;
  const auto* p=reinterpret_cast<const uint8_t*>(text);
  const auto* end=p+bytes; bool visible=false;
  while(p<end) {
    uint32_t code=*p++; int more=0; uint32_t minimum=0;
    if(code<128) {
      if((code<32 && code!='\n' && code!='\r' && code!='\t') || code==127) return false;
      visible|=code>32; continue;
    }
    if(code>=0xc2 && code<=0xdf) { more=1;minimum=0x80;code&=31; }
    else if(code>=0xe0 && code<=0xef) { more=2;minimum=0x800;code&=15; }
    else if(code>=0xf0 && code<=0xf4) { more=3;minimum=0x10000;code&=7; }
    else return false;
    if(size_t(end-p)<size_t(more)) return false;
    while(more--) { if((*p&0xc0)!=0x80) return false; code=(code<<6)|(*p++&63); }
    if(code<minimum || code>0x10ffff || (code>=0xd800 && code<=0xdfff) || (code>=0x80 && code<=0x9f)) return false;
    visible=true;
  }
  return visible || empty;
}
inline bool validId(const char* id) {
  if(!id || strnlen(id,33)!=32) return false;
  for(int i=0;i<32;++i) if(!((id[i]>='0'&&id[i]<='9')||(id[i]>='a'&&id[i]<='f'))) return false;
  return true;
}
inline bool valid(const Request& request) {
  return validId(request.id) && validText(request.title,kTitleBytes) &&
      validText(request.description,kDescriptionBytes,true) && request.dueAt>0;
}
inline bool same(const Request& a,const Request& b) {
  return a.dueAt==b.dueAt && !strcmp(a.id,b.id) && !strcmp(a.title,b.title) && !strcmp(a.description,b.description);
}
inline bool resolve(const char* title,const char* description,int64_t delay,const char* local,
                    int64_t now,bool trusted,Request& out,char* error,size_t capacity) {
  out=Request{};
  auto fail=[&](const char* text){ if(error&&capacity) snprintf(error,capacity,"%s",text); return false; };
  if(!validText(title,kTitleBytes) || !validText(description,kDescriptionBytes,true)) return fail("Give a short reminder title and description.");
  if(!trusted || now<1704067200 || now>4102444800LL) return fail("Wait for the clock, then repeat the reminder time.");
  if(!local || delay<0 || (delay>0 && *local) || (delay==0 && !*local)) return fail("When should I remind you? Say an exact time or a delay.");
  int64_t due=0;
  if(delay>0) {
    if(delay>kHorizon) return fail("Reminders must be within 366 days.");
    due=now+delay;
  } else {
    if(strlen(local)!=19 || local[10]!='T' || local[13]!=':' || local[16]!=':') return fail("Specify the reminder date and time.");
    char date[11];memcpy(date,local,10);date[10]=0;int days=0;
    if(!Weather::dateNumber(date,days)) return fail("Give a valid reminder date.");
    for(int i:{11,12,14,15,17,18}) if(local[i]<'0'||local[i]>'9') return fail("Specify the reminder time.");
    const int h=(local[11]-'0')*10+local[12]-'0',m=(local[14]-'0')*10+local[15]-'0',s=(local[17]-'0')*10+local[18]-'0';
    if(h>23 || m>59 || s>59) return fail("Specify the reminder time.");
    due=int64_t(days)*86400+h*3600+m*60+s-kTimezoneSeconds;
  }
  if(due<=now || due-now>kHorizon) return fail("Choose a future time within 366 days.");
  strcpy(out.title,title);strcpy(out.description,description);out.dueAt=due;return true;
}
inline bool localClock(int64_t epoch,bool trusted,char (&out)[20]) {
  out[0]=0;if(!trusted || epoch<1704067200 || epoch>4102444800LL) return false;
  const time_t shifted=time_t(epoch+kTimezoneSeconds);tm local{};
  return gmtime_r(&shifted,&local) && strftime(out,sizeof out,"%Y-%m-%dT%H:%M:%S",&local)==19;
}
inline uint32_t crc(const uint8_t* data,size_t size) {
  uint32_t value=~uint32_t(0);
  for(size_t i=0;i<size;++i) { value^=data[i];for(int bit=0;bit<8;++bit) value=(value>>1)^(0xedb88320u&uint32_t(-int32_t(value&1))); }
  return ~value;
}
enum class Load { Missing,Ok,Error };
inline void* recordMemory(size_t bytes) {
#ifdef ARDUINO
  return heap_caps_malloc(bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
#else
  return malloc(bytes);
#endif
}
template<class T> class Scratch {
 public:
  Scratch() {void* memory=recordMemory(sizeof(T));if(memory) pointer_=new(memory) T{};}
  ~Scratch() {if(pointer_) {pointer_->~T();free(pointer_);}}
  Scratch(const Scratch&)=delete;Scratch& operator=(const Scratch&)=delete;
  explicit operator bool() const {return pointer_!=nullptr;}
  T& operator*() {return *pointer_;}
  T* operator->() {return pointer_;}
 private:T* pointer_=nullptr;
};
template<class T> inline Load readRecord(const char* path,T& value) {
  FILE* file=fopen(path,"rb");if(!file) return errno==ENOENT?Load::Missing:Load::Error;
  struct Header { char magic[4];uint32_t bytes,checksum; } header{};
  auto* candidate=static_cast<T*>(recordMemory(sizeof(T)));
  if(!candidate) {fclose(file);return Load::Error;}
  const bool ok=fread(&header,1,sizeof header,file)==sizeof header && !memcmp(header.magic,"KRF1",4) && header.bytes==sizeof(T) &&
      fread(candidate,1,sizeof(T),file)==sizeof(T) && fgetc(file)==EOF && !ferror(file) && header.checksum==crc(reinterpret_cast<const uint8_t*>(candidate),sizeof(T));
  fclose(file);if(ok) memcpy(&value,candidate,sizeof value);free(candidate);return ok?Load::Ok:Load::Error;
}
template<class T> inline bool writeRecord(const char* path,const T& value) {
  char part[256];if(snprintf(part,sizeof part,"%s.part",path)>=int(sizeof part)) return false;
  struct Header { char magic[4];uint32_t bytes,checksum; } header{{'K','R','F','1'},uint32_t(sizeof(T)),crc(reinterpret_cast<const uint8_t*>(&value),sizeof value)};
  FILE* file=fopen(part,"wb");if(!file) return false;
  bool ok=fwrite(&header,1,sizeof header,file)==sizeof header && fwrite(&value,1,sizeof value,file)==sizeof value;
  ok=(fflush(file)==0)&&ok;ok=(fsync(fileno(file))==0)&&ok;ok=(fclose(file)==0)&&ok;
  auto* verify=static_cast<T*>(recordMemory(sizeof(T)));if(!verify) return false;
  ok=ok && readRecord(part,*verify)==Load::Ok && !memcmp(verify,&value,sizeof value);
  if(ok) ok=rename(part,path)==0;
  if(ok) ok=readRecord(path,*verify)==Load::Ok && !memcmp(verify,&value,sizeof value);
  free(verify);return ok;
}
inline bool field(JsonVariantConst value,const char* key,char* out,size_t capacity,bool empty=false) {
  if(!value[key].is<const char*>()) return false;
  const JsonString text=value[key].as<JsonString>();
  if(text.size()>=capacity || strnlen(text.c_str(),capacity)!=text.size() || !validText(text.c_str(),capacity-1,empty)) return false;
  memcpy(out,text.c_str(),text.size()+1);return true;
}
inline void encode(const Request& request,const char* device,JsonDocument& out) {
  out.clear();out["device_id"]=device;out["title"]=request.title;out["description"]=request.description;out["due_at"]=request.dueAt;
}
class Outbox {
 public:
  bool begin(const char* directory) {
    healthy_=false;
    if(!directory || strnlen(directory,sizeof directory_)>=sizeof directory_) return false;
    strcpy(directory_,directory);
    if(mkdir(directory_,0777) && errno!=EEXIST) return false;
    DIR* dir=opendir(directory_);if(!dir) return false;
    healthy_=true;size_t count=0;Request value;
    while(const auto* entry=readdir(dir)) if(isEntry(entry->d_name)) {
      char path[256];filename(entry->d_name,path);
      if(++count>kOutboxCapacity || readRecord(path,value)!=Load::Ok || !valid(value) || strncmp(entry->d_name,value.id,32)) { healthy_=false;break; }
    }
    closedir(dir);return healthy_;
  }
  bool stage(const Request& request,const char* source=nullptr) {
    if(!healthy_ || !valid(request)) return false;
    Scratch<Request> previous;if(!previous) return false;
    if(source) {
      char claim[256];if(!AudioFile::sidecarPath(source,".reminder",claim)) return false;
      const auto state=readRecord(claim,*previous);
      if(state==Load::Error || (state==Load::Ok && !same(*previous,request))) return false;
      if(state==Load::Missing && !writeRecord(claim,request)) return false;
    }
    char path[256];recordPath(request.id,path);
    const auto state=readRecord(path,*previous);
    if(state==Load::Ok) return valid(*previous)&&same(*previous,request);
    if(state==Load::Error) { healthy_=false;return false; }
    DIR* dir=opendir(directory_);if(!dir) return false;size_t count=0;
    while(const auto* entry=readdir(dir)) if(isEntry(entry->d_name)) ++count;
    closedir(dir);return count<kOutboxCapacity && writeRecord(path,request);
  }
  // A claim belongs to the current WAV. Recorder::begin removes stale claims
  // before creating a new recording; crash recovery never extracts a second ID.
  int recoverClaim(const char* source) {
    char path[256];if(!AudioFile::sidecarPath(source,".reminder",path)) return -1;
    Scratch<Request> request;if(!request) return -1;
    const auto state=readRecord(path,*request);
    if(state==Load::Missing) return 0;
    return state==Load::Ok && valid(*request) && stage(*request)?1:-1;
  }
  bool next(Request& out) {
    if(!healthy_) return false;
    DIR* dir=opendir(directory_);if(!dir) return false;
    char selected[37]{};
    while(const auto* entry=readdir(dir)) if(isEntry(entry->d_name) && (!*selected || strcmp(entry->d_name,selected)<0)) strcpy(selected,entry->d_name);
    closedir(dir);if(!*selected) return false;char path[256];filename(selected,path);
    if(readRecord(path,out)!=Load::Ok || !valid(out)) { healthy_=false;return false; }return true;
  }
  bool submitted(const char* id) {
    if(!healthy_ || !validId(id)) return false;char path[256];recordPath(id,path);
    return remove(path)==0 || errno==ENOENT;
  }
 private:
  char directory_[160]{};bool healthy_=false;
  static bool isEntry(const char* name) { return strlen(name)==36 && !strcmp(name+32,".bin"); }
  void filename(const char* name,char (&path)[256]) const { snprintf(path,sizeof path,"%s/%s",directory_,name); }
  void recordPath(const char* id,char (&path)[256]) const { snprintf(path,sizeof path,"%s/%s.bin",directory_,id); }
};
} // namespace Tamagotchi::Reminders
