#pragma once
#include "app_view.h"

// Editable application extension. Keep state/visual decisions portable so the
// hardware adapter and native preview can call these same hooks. Add hardware
// services through reviewed adapters; never embed credentials in this file.
namespace KibiApp::Feature {
inline void begin(Model& model,View::Context&){normalize(model);}
inline bool tick(Model&,View::Context&,uint32_t){return false;}
inline void input(Model&,const Input&,Action){}
} // namespace KibiApp::Feature
